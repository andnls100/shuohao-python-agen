# novel · 美术设定集

## 场景清单

| ID | 场景 | 类型 | 出现集 | 锚点 | 光照 | 变体 |
| --- | --- | --- | --- | --- | --- | --- |
| S01 | 江底封印·仙府与桃林 | 主场景 | 1、2、3、4 | 5 | 祭火夜、珠光常明、天光透水、月华透水 | — |
| S02 | 封印边界·水幕结界 | 主场景 | 1、4、5 | 4 | 夜·远岸祭火、昼·沉水天光、破封·裂光 | — |
| S03 | 江面·破封出水处 | 主场景 | 5、6 | 5 | 破封水雾蔽日、晨雾平波 | — |
| S04 | 江边祭坛 | 变体 ← S03 | 1、3 | 5 | 祭夜火光、水患阴雨 | 母场景的开阔江面在本景收拢为岸边祭坛湾：叠加粗石祭台、入水滑道、黑石火塘与焦顶木桩，岸线压低并添芦苇泥滩；江水体、对岸轮廓与江雾资产直接复用。时段不随母场景——按「祭夜火光」「水患阴雨」两个光照状态另出；村民群像属角色层，由镜头合成，不进环境资产。 |
| S05 | 人间市井与洞府 | 变体 ← S01 | 6 | 5 | 洞府·静昼、茶肆·晌午、茶肆·掌灯黄昏 | 洞府半场复用 S01（江底封印·仙府与桃林）：整体抽干水景——去掉水幕、水波光效与水底色偏，中央石池改为干涸无水，桃林收拢为洞口两三株野桃，建筑与陈设资产沿用母场景；茶肆半场为新增景——宋代市井一角的茶肆门脸加堂内条桌茶座，昼夜两用（见光照「茶肆·晌午」「茶肆·掌灯黄昏」）；街上人群群像属角色层，由角色管线另行生成，本环境资产保持空街空场。 |

---

## S01 江底封印·仙府与桃林

设计意图：一座拿温柔当刑具的牢笼。封印者舍不得她受苦，于是江底压着的不是水牢，而是一座恒温常明、遍植桃林的仙府——华美本身就是刑期，越像天堂，『你出不去』就越狠。空间要同时读出两层信息：远看是供人静养的仙境，近看满地摇篮小被、石缝里的米糊渍，是一间被上百个婴儿攻陷的育婴堂。大殿中央开阔无遮，留给第1集一掌震倒两名金丹修士的对峙与推搡；东侧桃林承担第3集花瓣飘落、哑口无言的静场；西侧摇篮阵是第2集喂饭洗衣哄睡的战场。气质要与江边祭坛的粗粝火光、人间市井的烟火气拉开差距：这里是冰冷的江水里捂出来的一团暖，也是全剧最贵的一个谎言。

### 一致性锚点

1. **倒悬水穹顶** — 殿顶无梁无瓦，整片是江水的底面：青绿水体悬在头顶，光波在穹面随水波流动。凡本场景镜头仰拍必须见到这片会动的水；穹面碎裂、变成石顶或瓦顶即为漂移。
2. **殿东桃林** — 沿大殿东侧缓坡植一大片桃林，明式曲干虬枝、常年盛花，粉白花瓣不断飘落，在青石地面缝隙里积出浅浅一层。『江底长出桃林』的荒谬感是本场景第一识别点。
3. **正北白玉狐榻** — 大殿正北三层汉白玉高台，台上一张阔得出奇的白玉大榻，尺寸足以卧下一头大兽；榻沿被磨出一圈温润包浆，台基四周立素面石栏。对峙、翻旧账、静场都围着这座台。
4. **百崽摇篮阵** — 殿西侧一排排明式矮围栏竹木摇篮，配锦缎小被与虎头小枕，行列一直排进柱影里；摇篮脚下青石上留着擦不净的淡米色饭渍。数量要多到一眼读出『上百个孩子住在这里』。
5. **鲛珠莲灯** — 殿柱之间隔一座白玉莲座，座上供拳头大的夜明珠，是殿内常明的暖光源；珠光暖黄与穹顶冷绿水光对撞，是校色时的冷暖参照点。

### 光照与时段

- **祭火夜**：`Night: the inverted water-dome ceiling glows with refracted orange bonfire light from the altar on the river surface far above, the firelight wavering and tearing into caustic ribbons; the hall sinks into deep teal shadow, pearl lamps on their jade lotus stands dimmed low; cold blue-green dominates with one trembling pool of warm orange overhead; heavy volumetric haze beneath the dome, long soft shadows across the swept stone floor`
- **珠光常明**：`Interior night with no daylight: the hall lit only by large glowing pearls resting on white jade lotus stands between the columns, warm ivory light pooling around the cradle rows; the water dome overhead nearly black with faint moving glints; gentle wraparound glow, low contrast, soft haze drifting at floor level`
- **天光透水**：`Daytime: green-gold sunlight filters down through the river surface, laying moving caustic ribbons across the jade terrace and the peach trunks; pink petals drifting through bright volumetric shafts; the grove half-lit and crisp, warm gold meeting cool green water tones`
- **月华透水**：`Deep night: pale silver-blue moonlight pierces the water dome in slow-shifting columns, laying cold bright patches on the stone floor; pearl lamps turned low so the hall reads almost monochrome; the peach grove reduced to soft dark silhouettes; still air, faint haze inside each moonlight shaft`

### 出图提示词包

**主视角 EN**

```text
Empty scene, no people, no animals: a vast immortal palace hall built inside an underwater cavern, Ming-style Chinese architecture — vermilion lacquered columns with dougong bracket sets, white jade three-tier terrace with plain balustrades; the entire ceiling is the inverted underside of a river, a suspended dome of clear green water with rippling caustic light; an impossible peach grove in full bloom spreads across the eastern slope, fallen petals gathering in the seams of the grey stone floor; rows of small Ming-style cradles with silk quilts lined along the western wall, faint pale rice-paste stains on the stone at their feet; a broad white jade daybed on the northern terrace, its rim polished smooth by use; large glowing pearls resting on white jade lotus stands between the columns; the interior is dry air beneath the water, nothing flooded. Well-kept, actively maintained materials: sound lacquer with an even sheen, swept stone and timber, polished metal fittings, tight joinery, no peeling paint and no water staining; wear confined to the traffic a space like this really takes — thresholds, handrails, the stone directly inside a doorway. Atmospheric depth with haze or volumetric light where the space allows. Wide establishing composition, deep perspective, cool green water light above meeting warm pearl glow below
```

**反向提示词**

```text
people, human figures, characters, children, babies, crowds, silhouettes of people, fox, giant beasts, animals indoors, oversaturated colours, sterile showroom cleanliness, warped perspective, melted geometry, floating objects, text, watermark, signature, flooded interior, submerged ruins, sunken shipwreck, rubble, collapsed ceiling
```

**设定图 EN**

```text
Full-page environment design sheet, empty scene with no people and no animals in any panel: an underwater immortal palace hall in Ming-style Chinese architecture beneath an inverted dome of river water. Layout: one large central wide establishing view showing the northern white jade terrace and daybed, the eastern blooming peach grove, the western rows of Ming-style cradles and the suspended water ceiling; three smaller detail panels — close view of the broad jade daybed with its polished rim, close view of the cradle rows with silk quilts and pale rice-paste stains on the stone at their feet, close view of the grove edge where petals gather in the floor seams; one inset plan diagram marking north terrace, east grove, west cradle rows and the south water-curtain gateway; a material swatch strip of vermilion lacquer, white jade, peach wood, grey river stone and glowing pearl. Well-kept, actively maintained materials: sound lacquer with an even sheen, swept stone and timber, polished metal fittings, tight joinery, no peeling paint and no water staining; wear confined to the traffic a space like this really takes — thresholds, handrails, the stone directly inside a doorway. Atmospheric depth with haze or volumetric light where the space allows. No text labels in any panel.
```

`environment sheet`, `well-kept materials`, `underwater cavern`, `Ming-style Chinese architecture`, `inverted water dome`, `peach grove`, `pearl lamp glow`, `caustic light`, `teal and pink palette`, `cinematic`

---

## S02 封印边界·水幕结界

设计意图：这是全剧的「笼门」——一层只进不出的单向水膜，把桃林仙府和外面的大江隔开。它要同时演两件事：封印者的温柔与囚笼的牢不可破，所以膜面要美得近乎体贴，阵眼、符链、石柱却处处是锁具的逻辑。EP1 两个不速之客从膜外坠进来，落点就在这张膜下——打脸戏的擂台；EP4「扔出去的东西被弹回」把救孩子就等于放走邪神的选择题钉死在这道边界上——阳谋与悬念的讲台；EP5 阵眼碎裂、天光倒灌，是反杀与出走的闸口。画面永远保持「里亮外暗」：膜内是暖融的府域光，膜外是压着一层泥沙帘的墨绿大江，一眼读出「进得来，出不去」。

### 一致性锚点

1. **倒扣水碗** — 罩住整个边界的水膜穹顶，像一只倒扣的巨碗：膜面是一层缓缓流动的半透明水皮，微微泛虹；从内侧看，膜外的墨绿江水贴着一层不散的泥沙帘——百年被弹回的东西都停在这条线上，「只进不出」一眼可读。
2. **十二环活眼** — 悬在水膜穹顶最高点正下方的环形阵眼，整环均分十二格扇面，每格刻一组云篆符文，随水流缓缓转动换格；受光的格亮青白色，转暗的格沉成墨绿，是画面正中最亮的定点。
3. **缠符石柱** — 沿水膜底边等距环立八根封印石柱，唐风石作、莲瓣纹柱础，柱身通刻锁链状连缀的符文带，常年透着不灭的青白微光；迎水面被水流磨得发亮，背水面挂薄泥。
4. **悬空符链** — 从阵眼外缘垂向八根柱顶的符文锁链：链环是一节节刻字的玉色短节，松松垂成弧线随水流轻摆，有一线光沿弧缓缓游走，是穹顶下最亮的动线。

### 光照与时段

- **夜·远岸祭火**：`Empty scene, no people. Night at the seal boundary: the riverbed lies in deep blue-black, and the translucent water-membrane dome is the brightest thing in view, its talisman script and jade script links glowing pale teal-white. Far above, beyond the film and the dark water, the wavering orange glow of shore bonfires reaches down and slides across the outer face of the membrane in restless warm patches. The twelve-segment formation eye turns slowly at the crown, each newly lit wedge casting a faint moving beam along the hanging script chains to the eight Tang-style pillars. A silt veil pressed against the outside of the film, volumetric haze in the water. Well-kept, actively maintained materials: sound lacquer with an even sheen, swept stone and timber, polished metal fittings, tight joinery, no peeling paint and no water staining; wear confined to the traffic a space like this really takes — thresholds, handrails, the stone directly inside a doorway. Atmospheric depth with haze or volumetric light where the space allows.`
- **昼·沉水天光**：`Empty scene, no people. Daytime at the seal boundary: grey-green daylight sinks through the river in soft slanted shafts, catching the drifting silt; the water-membrane dome reads as a shimmering second surface, its teal talisman glow subdued under the daylight, jade script links glinting as they sway. The twelve-segment formation eye at the crown turns with the current, its wedges paling and deepening as they rotate. Beyond the film the open river presses in dark, a thin silt veil clinging to the outer face; eight Tang-style carved pillars ring the base, their lotus-petal plinths half-lost in soft haze. Well-kept, actively maintained materials: sound lacquer with an even sheen, swept stone and timber, polished metal fittings, tight joinery, no peeling paint and no water staining; wear confined to the traffic a space like this really takes — thresholds, handrails, the stone directly inside a doorway. Atmospheric depth with haze or volumetric light where the space allows.`
- **破封·裂光**：`Empty scene, no people. The instant the seal breaks: hairline cracks of searing white-gold light spider across the whole water-membrane dome, talisman script flaring bright then guttering dark; the jade script links snap taut and burst into drifting motes of light, and the twelve-segment formation eye spins wildly at the crown, its wedge segments splitting apart one by one. Through the widening breach bright open water floods the dim riverbed, rings of shockwave bubbles rolling outward along the eight Tang-style carved pillars, silt whipping off the outer veil. Well-kept, actively maintained materials: sound lacquer with an even sheen, swept stone and timber, polished metal fittings, tight joinery, no peeling paint and no water staining; wear confined to the traffic a space like this really takes — thresholds, handrails, the stone directly inside a doorway. Atmospheric depth with haze or volumetric light where the space allows.`

### 出图提示词包

**主视角 EN**

```text
Empty scene, no people. A one-way seal boundary on a riverbed: a vast translucent water-membrane dome arches over the bottom like an inverted bowl, its film a skin of slow-flowing water with a faint iridescence; beyond the film the open river lies dark blue-green, a thin veil of silt pressed against the outer face where everything bounced back over a century has come to rest. At the crown floats the formation eye, a ring divided into twelve wedge segments engraved with cloud-seal talisman script, turning slowly with the current, lit wedges glowing pale teal-white. Eight Tang-style stone pillars with lotus-petal plinths ring the base of the membrane, their shafts carved with linked talisman chains holding an unbroken soft glow; jade-colored script links hang in slack arcs from the eye down to the pillar tops, swaying, a thread of light travelling along them. Deep blue-green water, soft slanting daylight shafts sinking from far above. Well-kept, actively maintained materials: sound lacquer with an even sheen, swept stone and timber, polished metal fittings, tight joinery, no peeling paint and no water staining; wear confined to the traffic a space like this really takes — thresholds, handrails, the stone directly inside a doorway. Atmospheric depth with haze or volumetric light where the space allows. Here that care reads as razor-sharp script grooves and a flawless film; wear lands only where the current scours — the upstream faces of the pillars and the silt line at the base ring.
```

**反向提示词**

```text
people, human figures, characters, crowds, silhouettes of people, faces, hands, fingers, fish, jellyfish, turtles, dry land, beach, above-water view, sky, buildings, oversaturated colours, sterile showroom cleanliness, warped perspective, melted geometry, text, watermark, signature
```

**设定图 EN**

```text
Environment reference sheet for a one-way water-membrane seal boundary on a riverbed, four panels arranged on a neutral dark-grey background, empty scene, no people, no text labels. Panel 1: wide establishing view from the inner side, the translucent dome arching overhead like an inverted bowl, the twelve-segment formation eye at the crown, eight Tang-style seal pillars ringing the base, jade script links hanging in slack arcs from eye to pillar tops. Panel 2: reverse view from the dark open river outside, the silt veil pressed against the outer face of the film, teal glow bleeding through. Panel 3: close detail of the rotating formation eye, twelve wedge segments of cloud-seal script with a teal-white glow, each segment a different talisman group. Panel 4: close detail of a pillar base, lotus-petal stone plinth, linked talisman chain carved into the shaft, current-polished upstream face and a thin silt line at the foot. All four panels share the same landmarks and palette: deep blue-green water, pale teal talisman glow, warm-grey stone. Well-kept, actively maintained materials: sound lacquer with an even sheen, swept stone and timber, polished metal fittings, tight joinery, no peeling paint and no water staining; wear confined to the traffic a space like this really takes — thresholds, handrails, the stone directly inside a doorway. Atmospheric depth with haze or volumetric light where the space allows. For this underwater shrine the care shows as razor-sharp script grooves and a flawless film, while wear lands only where the current scours, on the upstream pillar faces and the silt line at the base ring.
```

`environment sheet`, `well-maintained materials`, `underwater boundary`, `glowing talisman formation`, `teal and jade palette`, `volumetric light`, `cinematic`

---

## S03 江面·破封出水处

设计意图：全剧的泄洪口——百年囚禁在一个白昼从水下轰然掀开的露天舞台。它要同时撑住两场戏：遮天蔽日的爆发（水柱、漩涡、阵纹碎石、桃瓣一起冲出水面，给『反杀』『反转』的高光留足整条天际线）与爆发后的温柔收束（雾气未散的江面上，一只只安顿幼崽）。作为主场景，它被刻意做成全剧最空的一块画布：没有墙、没有顶，只有大江、天空和远岸，让全剧最大的动作有地方施展。观众认它不靠建筑靠遗物——环形漩涡、发光碎石、浮水桃瓣、未散雾柱，这几件『破封现场』的痕迹就是它的脸。气质上与江底仙府的幽闭梦感、水幕结界的膜感、江边祭坛的石质仪式感全部拉开：开阔、动荡、然后归于平静。

### 一致性锚点

1. **环形漩涡水痕** — 破封点正中一圈巨型环形波纹，环内水面仍在缓慢旋转成未散尽的漩涡，环外涟漪一圈圈向外推去；大远景和近景里都是第一眼定位的标志
2. **阵纹碎石浮水** — 封印崩碎后浮上江面的青灰石片，断口参差，刻纹缝隙里透着将熄未熄的淡金色微光，散布在漩涡环四周的水面上
3. **桃瓣浮水** — 随破封从江底桃林带上来的淡粉桃花瓣，星星点点漂在石片之间的水面，随漩涡缓缓打转
4. **未散水雾柱** — 出水口正上方一根高耸的白色雾水柱，正缓慢坍塌消散，顶端被风拉斜；破封后不久的镜头里始终都在
5. **远岸祭坛剪影** — 画面一侧远处江岸林木线上，石砌祭坛的模糊剪影探出树梢，与『江边祭坛』场景同一体量，只作远景轮廓

### 光照与时段

- **破封水雾蔽日**：`Overcast daylight dimmed by a towering column of white spray and mist rising from the center of a broad river, the plume blotting out the sun so the whole surface sits in shadowed grey-blue light; harsh white backlit edges where sunlight pierces gaps in the spray as broken god rays; a giant ring-shaped ripple with a slowly settling whirlpool at the center, broken grey-green stone shards with faint glowing golden array lines and pale pink peach petals scattered on the dark blue-green water; heavy atmospheric haze, volumetric light shafts through the mist column, muted palette of grey, blue-green and pale gold; low forested banks far in the distance; empty scene, no people`
- **晨雾平波**：`Early morning after the upheaval: thin white river fog hugging the calm water surface, soft diffuse grey-gold dawn light, gentle leftover ripples still radiating in slow circles from the center; the once-tall mist column dissolved into a low haze band above the water; a few remaining broken seal-stone shards with dimming golden array glow and scattered pale pink peach petals drifting on the glassy blue-green surface; distant banks and a weathered stone altar silhouette softened by fog; quiet, melancholic atmosphere, muted blue-green and grey palette with a warm gold horizon; empty scene, no people`

### 出图提示词包

**主视角 EN**

```text
Empty scene, no people. Wide cinematic view over a broad river at the exact spot where an ancient seal has just shattered from below: a giant ring-shaped ripple spreading outward, the water inside the ring still slowly turning as a settling whirlpool; broken grey-green stone shards with faint glowing golden array lines drifting on the surface; pale pink peach petals scattered among the shards, carried up from a drowned grove below; a tall column of white mist and spray hanging above the center, slowly collapsing, its top bent by wind; grey overcast daylight diffused through the lingering spray, broken god rays where light pierces the plume; low forested riverbanks far in the distance with the vague silhouette of a weathered stone altar on one shore; muted blue-green water, grey-white sky, accents of pale gold and soft pink; water-stained, weathered stone and waterlogged wood, nothing looks factory-new; atmospheric depth with haze and volumetric light through the mist column
```

**反向提示词**

```text
people, human figures, characters, crowds, silhouettes of people, faces in the water, human shapes formed by spray, creatures, giant fish, dragon, serpent, boats, ships, rafts, docks, fishing nets, oversaturated colours, sterile showroom cleanliness, warped perspective, melted geometry, text, watermark, signature
```

**设定图 EN**

```text
Environment design sheet for a single location, several views arranged on one clean page, no text labels: A) wide establishing view of the river surface at the seal-breaking point with the giant ring-shaped ripple and collapsing mist column; B) top-down diagram view of the slowly settling whirlpool ring, showing the arrangement of floating seal-stone shards and peach petals; C) close-up detail studies of broken stone shards with faint glowing golden array lines and waterlogged pale pink peach petals on the water; D) small lighting study comparing the towering spray plume under overcast daylight and the calm morning-fog aftermath. Empty scene, no people, no boats, no creatures. Weathered, lived-in materials: chipped paint, water stains, patina on metal, worn wood grain, dust in corners and light shafts; fabric and paper props show creases and age; nothing looks factory-new. Atmospheric depth with haze or volumetric light where the space allows. Muted blue-green and grey palette with pale gold array-light accents and soft pink petal accents.
```

`environment sheet`, `weathered materials`, `cinematic`, `river surface`, `water`, `mist`, `whirlpool ripple`, `glowing array fragments`, `peach petals`, `overcast light`, `muted blue-green palette`

---

## S04 江边祭坛

设计意图：一座被恐惧和习惯养了一百年的土造祭坛——没有官修规制，只有粗石、绳槽和层层压积的烟灰。它要讲的是「罪在岸上，不在江底」：台面被麻绳磨出平行深槽、火塘的灰一层压一层，说明往江里沉人不是一次恐慌，而是代代相传的例行公事；第1集开场冲天大火在这里送走一对婚服修士，第3集闪回里同一道滑道推下去的换成了孩子。气质与同批场景拉开：江底仙府幽深华美、水幕结界隔世寂静，岸上这一侧只有粗粝、泥泞和烟熏火燎。做江面场景的变体，复用水体与雾资产，只叠石台、火塘与夜色。

### 一致性锚点

1. **平行绳槽** — 祭台台面正中偏江一侧，四道平行的浅槽被麻绳磨进石面，槽底积着黑灰，一直延伸到台沿
2. **入水滑道** — 祭台朝江一侧用一整块长石板铺成的斜坡，末端没入水中；坡面被磨得发亮，水线以下长着暗绿滑苔
3. **黑石火塘** — 祭台后方一圈烧裂发黑的河卵石围成的火塘，塘内灰烬厚积、分出深浅几层
4. **焦顶木桩** — 环祭台半圈插着六根松木桩，顶端全被火燎焦，高低歪斜，桩身上还系着风化的旧绳头
5. **缺耳石炉** — 台角一只粗凿的石香炉，炉身一道裂缝，左耳齐根断掉，炉腹里插着烧剩的香脚

### 光照与时段

- **祭夜火光**：`Night at a Ming-dynasty style rural Chinese riverside stone altar during a famine year, completely empty scene, no people: the fire pit behind the rough stone platform blazes with towering bonfire flames, the six charred pine posts burn like torches, fierce orange firelight climbs into a deep blue-black night sky, thick smoke haze drifts low across the platform, the four rope grooves and the stone slipway glint wet in the firelight, broken red reflections ripple on the black river surface, sparks and ash flecks spiral upward, dark reed silhouettes at the bank edge. Weathered, lived-in materials: chipped paint, water stains, patina on metal, worn wood grain, dust in corners and light shafts; fabric and paper props show creases and age; nothing looks factory-new. Atmospheric depth with haze or volumetric light where the space allows`
- **水患阴雨**：`Overcast stormy day during a river flood at a Ming-dynasty style rural Chinese riverside stone altar, completely empty scene, no people: the river swollen and murky brown, surging against the trampled mud bank; heavy grey rain falls in slanted sheets, water sheets across the rough stone platform and streams down the polished slipway into the current, the fire pit ash turned to black paste, the charred pine posts dark and dripping, mist and spray hanging over the water, cold desaturated grey-green palette, dim diffuse light. Weathered, lived-in materials: chipped paint, water stains, patina on metal, worn wood grain, dust in corners and light shafts; fabric and paper props show creases and age; nothing looks factory-new. Atmospheric depth with haze or volumetric light where the space allows`

> 变体来源：S03　改动：母场景的开阔江面在本景收拢为岸边祭坛湾：叠加粗石祭台、入水滑道、黑石火塘与焦顶木桩，岸线压低并添芦苇泥滩；江水体、对岸轮廓与江雾资产直接复用。时段不随母场景——按「祭夜火光」「水患阴雨」两个光照状态另出；村民群像属角色层，由镜头合成，不进环境资产。

### 出图提示词包

**主视角 EN**

```text
Ming-dynasty style rural Chinese riverside sacrificial altar on a muddy reed bank, completely empty scene, no people. A raised platform of rough-hewn grey stone blocks at the water's edge, its top surface worn with four parallel rope grooves filled with dark ash; on the river side one long stone slab forms a polished slipway sloping down into the dark water. Behind the platform a fire pit ringed with cracked smoke-blackened cobbles, thick layered ash inside. Half a ring of six crooked pine posts with charred tops around the platform, weathered old rope stubs tied to them. A crudely carved stone censer with a cracked body and one broken ear in the platform corner, burnt incense stubs in its bowl. Withered reed clumps, trampled mud paths, low grey overcast sky, thin mist drifting over the river. Weathered, lived-in materials: chipped paint, water stains, patina on metal, worn wood grain, dust in corners and light shafts; fabric and paper props show creases and age; nothing looks factory-new. Atmospheric depth with haze or volumetric light where the space allows
```

**反向提示词**

```text
people, human figures, characters, crowds, silhouettes of people, villagers, livestock, oversaturated colours, sterile showroom cleanliness, warped perspective, melted geometry, floating objects, text, watermark, signature
```

**设定图 EN**

```text
Environment design sheet, Ming-dynasty style rural Chinese riverside sacrificial altar, completely empty scene, no people. Layout: one large main three-quarter view of the whole altar on the muddy reed bank under flat overcast light; a row of close-up detail panels showing the four parallel rope grooves in the platform top, the polished stone slipway sliding into the water, the smoke-blackened fire pit with layered ash, one charred pine post with its old rope stub, and the cracked one-eared stone censer; a small side elevation diagram of the platform and slipway showing the slope into the river. Neutral grey palette for material reading. Weathered, lived-in materials: chipped paint, water stains, patina on metal, worn wood grain, dust in corners and light shafts; fabric and paper props show creases and age; nothing looks factory-new. Atmospheric depth with haze or volumetric light where the space allows
```

`environment sheet`, `weathered materials`, `cinematic`, `Ming-dynasty rural China`, `stone sacrificial altar`, `rope grooves`, `soot and ash`, `reed riverbank`, `grey overcast palette`

---

## S05 人间市井与洞府

设计意图：第6集尾声的两连拍——先递自由，再让自由听见坏消息。洞府半场是她百年来第一处自己选的容身处：复用江底仙府的建筑骨架但抽干全部水，干涸的池底、洞口的野桃和斜进洞口的第一束天光都在说『这里不再是囚笼』，一镜带过，越松弛越好。茶肆半场把这份松弛按进最寻常的人间烟火，茶渍条桌、铜壶蒸汽、门外的市声越日常越好，直到正墙那幅白衣面目被墨晕糊开的剑宗群像进入视线，满堂暖调瞬间塌成收束全剧的阴影。本批其余场景全部浸在水里，这里是唯一干燥的人间，干湿对比本身就是『出水之后』的注脚；街上与堂内的人群属角色层另行合成，环境资产永远空场。

### 一致性锚点

1. **干涸石池** — 洞府正中一方浅方形石池，池内无水，池底只余一圈白色水垢线和薄沙——『仙府抽掉了水』的最直读记号，每次生成洞府都必须在画面正中。
2. **洞口野桃** — 洞府洞口外斜生两三株瘦桃树，枝条探进洞内半尺，零星花瓣落在门槛石上；与江底仙府的桃林同源，但根扎在崖上旱土里。
3. **白衣画像轴** — 茶肆正墙一幅竖长剑宗群像立轴，画中人物皆背身或侧影、不刻画面容，唯最高处一道白衣身影面目被一团墨晕糊开、无法辨认；终场反转的视觉落点，QC 重点核对项。
4. **茶渍条桌** — 堂内成排榆木长条桌（靠窗两列、靠山墙一列），桌面留着经年茶汤烙出的深色圆痕，桌沿磨白；桌椅方位固定，是堂内构图的基准线。
5. **白壶茶旗** — 门楣斜挑一面褪色靛蓝布幌，旗面只绘一把白色茶壶图样、不着一字，是茶肆门脸的认记。

### 光照与时段

- **洞府·静昼**：`Empty scene, no people. A dry grotto dwelling hollowed into a mountainside, converted from an older water-filled mansion and now completely waterless: a wide low chamber of rough worked stone with reused carved pillar bases, a shallow square stone basin at the centre holding only a pale mineral waterline ring and fine sand, a plain timber couch and low shelves against the rock wall, thin bright daylight slanting in one wide shaft through the cave mouth, drifting dust motes in the beam, two scraggly peach trees at the entrance, a few loose petals on the threshold stone, cool grey-blue ambient in the deep recesses against warm gold near the mouth, calm, airy, unhurried — a shelter chosen freely. Weathered, lived-in materials: chipped paint, water stains, patina on metal, worn wood grain, dust in corners and light shafts; fabric and paper props show creases and age; nothing looks factory-new. Atmospheric depth with haze or volumetric light where the space allows. Environment asset only, completely uninhabited.`
- **茶肆·晌午**：`Empty scene, no people. A Song-dynasty street teahouse interior at midday: strong warm-white daylight flooding through open lattice windows and the wide street door, crisp sun patches on worn plank flooring, thin steam rising from a big copper kettle on a clay stove, the empty market lane outside bright with grey-tiled shopfronts and hanging cloth banners, rows of tea-stained elmwood long tables, the tall vertical scroll on the main wall — a sword sect group portrait of back-turned figures, the white-robed one at the top with its face smeared into an unreadable ink bloom — evenly and harmlessly lit, everything ordinary and welcoming, dust motes in the light shafts. Weathered, lived-in materials: chipped paint, water stains, patina on metal, worn wood grain, dust in corners and light shafts; fabric and paper props show creases and age; nothing looks factory-new. Atmospheric depth with haze or volumetric light where the space allows. Environment asset only, completely uninhabited.`
- **茶肆·掌灯黄昏**：`Empty scene, no people. The same Song-dynasty teahouse interior at early night: blue dusk dimming the empty market street beyond the open door, a row of oil lamps and paper lanterns lit along the ceiling beams, amber pools of light on the long tables, deep soft shadow gathering in the corners, the stove gone cold, the main-wall group portrait half in shadow with the face-smudged white-robed figure picked out by a single lamp flame, reading as a quiet watching presence over the empty benches, long shadows across the worn threshold. Weathered, lived-in materials: chipped paint, water stains, patina on metal, worn wood grain, dust in corners and light shafts; fabric and paper props show creases and age; nothing looks factory-new. Atmospheric depth with haze or volumetric light where the space allows. Environment asset only, completely uninhabited.`

> 变体来源：S01　改动：洞府半场复用 S01（江底封印·仙府与桃林）：整体抽干水景——去掉水幕、水波光效与水底色偏，中央石池改为干涸无水，桃林收拢为洞口两三株野桃，建筑与陈设资产沿用母场景；茶肆半场为新增景——宋代市井一角的茶肆门脸加堂内条桌茶座，昼夜两用（见光照「茶肆·晌午」「茶肆·掌灯黄昏」）；街上人群群像属角色层，由角色管线另行生成，本环境资产保持空街空场。

### 出图提示词包

**主视角 EN**

```text
Empty scene, no people. Interior of a Song-dynasty street teahouse seen from just inside the open street door: rows of long elmwood tables and benches, edges worn pale and tabletops ringed with dark old tea stains, a clay stove with a big copper kettle against the back wall, thin steam in the air; through the door and open lattice windows a quiet empty market lane of grey-tiled shopfronts and hanging cloth banners. On the main wall hangs one tall vertical ink scroll, a sword sect group portrait of back-turned and profiled figures without detailed faces, the highest figure in white robes smeared into an unreadable ink bloom, flanked by two smaller landscape scrolls; a faded indigo cloth banner painted with a simple white teapot emblem hangs at the door, no lettering anywhere. Weathered, lived-in materials: chipped paint, water stains, patina on metal, worn wood grain, dust in corners and light shafts; fabric and paper props show creases and age; nothing looks factory-new. Atmospheric depth with haze or volumetric light where the space allows. Environment asset only, completely uninhabited, empty street.
```

**反向提示词**

```text
people, human figures, characters, crowds, pedestrians, real people in the street, detailed human faces, oversaturated colours, sterile showroom cleanliness, warped perspective, melted geometry, floating objects, text, watermark, signature
```

**设定图 EN**

```text
Environment reference sheet, empty scene, no people, one layout: a Song-dynasty street teahouse and a dry mountainside grotto dwelling. Views: (1) teahouse interior three-quarter view from the street door with rows of tea-stained elmwood long tables, clay stove and copper kettle, and the main-wall vertical scroll — a sword sect group portrait of back-turned figures, the white-robed one at top with its face smeared into an unreadable ink bloom; (2) teahouse street facade with faded indigo banner painted with a white teapot emblem, open lattice windows onto an empty market lane of grey-tiled shopfronts; (3) dry grotto chamber with central waterless square stone basin and pale mineral waterline ring, plain timber couch and low shelves, reused carved pillar bases; (4) cave mouth with two scraggly peach trees and a petal-dusted threshold. Detail callouts: the face-smudged white-robed figure on the scroll, the dry basin rim, a tea-ringed tabletop, the teapot banner. Neutral soft daylight base state for asset review. Weathered, lived-in materials: chipped paint, water stains, patina on metal, worn wood grain, dust in corners and light shafts; fabric and paper props show creases and age; nothing looks factory-new. Atmospheric depth with haze or volumetric light where the space allows. No people in any view.
```

`environment sheet`, `weathered materials`, `cinematic`, `song dynasty`, `street teahouse`, `empty market lane`, `dry grotto dwelling`, `waterless stone basin`, `ink scroll portrait wall`, `tea-stained wood`, `warm daylight`, `amber lamplight`, `dust motes`, `empty scene`

---

## 道具清单

| ID | 道具 | 尺度 | 状态 | 关联场景 | 出现集 | 锚点 |
| --- | --- | --- | --- | --- | --- | --- |
| P01 | 婚服 | 家具级 | 整洁初着、湿透沉江、下摆糊满米糊 | S04、S01、S02 | 1、2 | 5 |
| P02 | 封印阵眼 | 桌面级 | 完整封印、灵力灌注过载、破封碎裂 | S01、S03 | 4、5 | 5 |
| P03 | 桃花 | 手持级 | 枝头盛放、单瓣离枝、落附绒毛 | S01 | 3、4 | 4 |

---

## P01 婚服

开场乌龙的核心标识：凡人不知她男女喜好，把一对金丹修士当祭品新人送下来；婚服从杀妖现场穿到带娃现场，是第1集钩子与全剧笑点的视觉名片

### 一致性锚点

1. **凤穿牡丹盘金绣** — 胸前肩头以盘金绣凤穿牡丹，金线氧化发暗，只有火光下才泛一点暗金，是整套婚服唯一亮的地方
2. **磨白的旧缎袖口** — 袖口与肘部缎面磨得起毛泛白——灾年村里传了几代的旧嫁衣，红得发沉
3. **麻绳勒痕** — 腰背处被祭坛麻绳勒出的深褶与抽丝，褶痕斜向交叉，正好压在金绣上
4. **缺珠凤冠** — 女款凤冠缀红绒花与珍珠垂旒，珠串缺了两颗，用红线草草补系过
5. **歪扭同心结腰绦** — 腰间一条红绸同心结绦，结打得歪歪扭扭，是村民匆忙现学的手艺

### 状态变体

- **整洁初着**：`pristine Ming dynasty red wedding garments at furniture scale, a groom's crimson round-collar satin robe and a bride's phoenix-crowned aoqun standing on invisible headless dress forms against a pure white background, gold couched embroidery bright and intact with only inherited pale wear on the cuffs, even soft studio lighting, no people, no hands`
- **湿透沉江**：`the same pair of Ming dynasty red wedding garments soaked and dripping at furniture scale, wet crimson silk darkened and clinging to the invisible dress forms, water beads sliding off the gold embroidery, pearl tassels strung with tiny droplets, pure white background, even soft studio lighting, no people, no hands`
- **下摆糊满米糊**：`the same pair of Ming dynasty red wedding garments at furniture scale with hems and sleeves splattered and smeared with dried white rice porridge, crusty paste streaks dripping down the skirts, loose grains stuck in the gold embroidery, pure white background, even soft studio lighting, no people, no hands`

### 出图提示词包

**主视角 EN**

```text
furniture scale, life-size pair of Ming dynasty red wedding garments displayed on invisible headless dress forms, pure white background: a groom's crimson round-collar satin robe with a black gauze cap beside a bride's red aoqun skirt with a pale-cloud cape and a phoenix crown; gold couched embroidery of phoenixes flying through peonies across chest and shoulders, cuffs and elbows worn pale and fuzzy, deep diagonal rope creases across the back panels, the bride's crown strung with pearl tassels missing two pearls re-tied with red thread, a loosely knotted red silk concentric-knot sash at the waist; even soft studio lighting, faint contact shadows, full-length centered view, prop reference photography, no people, no hands, no visible mannequin
```

**反向提示词**

```text
people, person, human, figure, hands, fingers, skin, face, mannequin with skin, colored background, gradient background, stage, clutter, text, watermark, logo, blurry, low detail
```

**设定图 EN**

```text
Prop reference sheet, furniture scale, life-size: a matched pair of Ming dynasty red wedding garments on pure white background. Grid layout — top row: front full-length views of the groom's crimson round-collar satin robe with black gauze cap and the bride's red aoqun with pale-cloud cape and phoenix crown, each on an invisible headless dress form; middle row: four detail close-ups of the gold couched phoenix-and-peony embroidery, the pale fuzzy worn cuffs, the diagonal rope creases on the back panels, and the phoenix-crown pearl tassel with two missing pearls re-tied in red thread; bottom row: back views of both garments plus a flat lay of the loosely knotted red silk concentric-knot sash. Surface treatment: aged crimson silk satin with a soft muted sheen, gold thread gently oxidized to dark amber, all wear kept subtle, even and consistent across every view; faint contact shadows only, no people, no hands, no text.
```

---

## P02 封印阵眼

全剧核心麦高芬：既是困她的牢笼，也是阳谋给出的唯一出路，更是第5集破封瞬间第二重封印反落她身上的反转实体载体

### 一致性锚点

1. **十二时辰刻环** — 球体外圈环刻十二枚篆文时辰位，当值的一枚透出青白光，按一日十二时辰轮转点亮，是「一日十二变」的实体
2. **竖瞳光核** — 球心悬一枚竖瞳状光核，瞳面映着流转水光，凝视片刻像在缓缓收缩，被灵力触碰时骤然睁大
3. **剑纹封链** — 三匝银亮符链绕球缠锁，每节链环内铸一柄小剑纹，链头收进球底一枚云雷纹环扣
4. **螺旋导水槽** — 球面刻三道螺旋水槽，江水贴槽昼夜流转不息，槽棱被水流磨出温润包浆
5. **青黑阵盘** — 眼球半嵌在青黑色石阵盘中央凹槽里，盘面布满细密符线，凹槽边缘挂着一层百年水藻的暗绿

### 状态变体

- **完整封印**：`tabletop scale prop state, isolated on a pure white background: the sealing array eye intact and active — a translucent pale-cyan jade sphere the size of a large washbasin locked by three turns of silver rune chains with tiny sword-motif links, twelve seal-script hour glyphs around its band with the active glyph glowing steady cyan-white, a vertical-pupil light core calmly floating at the center like a living eye, clear water flowing along three spiral channels, dark blue-black stone array disc below with fine glyph lines and thin algae tint in the recesses, cool cyan-white glow with soft bloom, clean studio product lighting, centered composition, no characters, no hands`
- **灵力灌注过载**：`tabletop scale prop state, isolated on a pure white background: the sealing array eye overloaded by poured-in spiritual power — blinding cyan-white light spiraling into the vertical-pupil core like a bottomless vortex, all twelve seal-script hour glyphs racing bright, silver sword-motif rune chains straining taut with hairline cracks of light spreading across the jade sphere, water channels boiling with streaks of glow, fine glyph lines on the dark stone disc flaring, high-contrast dramatic lighting, no characters, no hands`
- **破封碎裂**：`tabletop scale prop state, isolated on a pure white background: the sealing array eye shattered at the moment of breaking — the pale-cyan jade sphere split by a jagged luminous crack with halves slightly drifted apart, snapped silver rune chains drifting loose, the twelve hour glyphs dimming to dying embers, the vertical-pupil core winking out, spiral water channels running dry with leftover ripples of light and rising glowing motes, dark stone disc with burnt-dark glyph lines, fading cool glow, no characters, no hands`

### 出图提示词包

**主视角 EN**

```text
single fantasy prop reference, tabletop scale, isolated on a pure white background: the eye of a great sealing formation — a translucent pale-cyan jade sphere the size of a large washbasin, half-seated in the central socket of a dark blue-black stone array disc, a band of twelve seal-script hour glyphs around the sphere with the active glyph lit steady cyan-white, a vertical-pupil-shaped light core floating at the center like a living eye, three turns of silver rune chains with tiny sword-motif links wrapping and locking the sphere with chain ends anchored into a cloud-thunder pattern ring on the disc, three spiral water channels carved around the sphere with clear water flowing along them, fine engraved glyph lines covering the stone disc with thin dark-green algae tinting its recesses, cool cyan-white glow with soft bloom, clean studio product lighting, centered composition, ultra-detailed, no characters, no hands
```

**反向提示词**

```text
people, person, human, figure, character, silhouette, face, hands, fingers, arms, body parts, hair, underwater scenery, background environment, rocks, water surface, text, letters, watermark, logo, frame, blur, lowres, deformed, extra limbs
```

**设定图 EN**

```text
prop design sheet of the sealing array eye on a pure white background, isolated asset for compositing into shots, no environment, no characters; layout: one large centered hero view at tabletop scale, flanked by three-quarter and top views, a row of close-up callout panels showing the twelve seal-script hour glyphs, the vertical-pupil light core, the silver sword-motif rune chains and the spiral water channels, plus three small state thumbnails (sealed, power overload, shattered); surface treatment: a formation core aged a century underwater yet kept alive by sustained power — cool-toned patina on the silver chain links polished smooth by the current, faint water-wear on raised carved edges, thin dark-green algae staining only in the stone disc's recesses, jade surface clear and lustrous, no rust, no mud, no crumbling decay; even studio lighting, soft contact shadow, no text labels, no annotations
```

---

## P03 桃花

牢笼里的温柔物证：囚禁她的封印内遍植她最爱的桃林，花瓣落在她原形的毛上——支撑第3集封印者舍不得她受苦的推断，喂养应明霄悬念线

### 一致性锚点

1. **五瓣粉晕** — 五枚卵圆花瓣，瓣尖桃红、向瓣心渐淡至近白，薄绢质地隐约透光
2. **深红花萼** — 花瓣根部一圈深绯色花萼，花心细密短花丝顶着米黄色花药
3. **绛紫枝皮** — 细枝绛紫褐色，布浅色横向细小皮孔，节间短促，折口处木质泛白
4. **瓣面水珠** — 花瓣背面凝着针尖大小的水珠，映光成亮点——江底潮气留下的痕迹

### 状态变体

- **枝头盛放**：`handheld scale, close view of a short peach blossom branch segment in full bloom, dense clusters of five-petaled pale pink flowers with rosy pink tips fading to near-white base, deep crimson calyxes, fine stamens with pale yellow anthers, dark purplish-brown bark dotted with light lenticels, needle-sized dew droplets on the petals, isolated on a pure white seamless background, soft studio lighting, no people, no hands`
- **单瓣离枝**：`handheld scale, a single detached peach blossom petal suspended in mid-air at a slight tilt, ovate petal with rosy pink edge fading to near-white center, fine translucent veins, one needle-sized dew droplet at the petal tip, isolated on a pure white seamless background, soft studio lighting, no people, no hands`
- **落附绒毛**：`handheld scale, extreme macro shot, a single peach blossom petal resting on a tuft of long soft silvery-white fur, petal with rosy pink edge fading to near-white, fine translucent veins visible, two needle-sized dew droplets caught among the fur strands, pure white seamless background, soft studio lighting, no people, no hands`

### 出图提示词包

**主视角 EN**

```text
handheld scale, a slender peach blossom sprig about 25 centimeters long, dense clusters of five-petaled pale pink flowers fading from rosy pink petal tips to near-white base, deep crimson calyxes and fine stamens with pale yellow anthers, dark purplish-brown bark dotted with small light lenticels, needle-sized dew droplets clinging to the petals, two loose petals resting beside the sprig, centered product shot, isolated on a pure white seamless background, soft even studio lighting, no people, no hands
```

**反向提示词**

```text
people, person, human, hands, fingers, face, body, fox, creature, text, letters, watermark, logo, colored background, gradient background, outdoor scenery, trees, forest, vase, blurry, deformed petals, extra petals, oversaturated
```

**设定图 EN**

```text
Prop reference sheet of a handheld scale peach blossom sprig, multiple views arranged in a tidy grid on a pure white background: full view of the blooming sprig, top macro of a single five-petaled flower showing the gradient from rosy pink tips to near-white base, side macro exposing the deep crimson calyx and pale yellow anthers, macro of dark purplish-brown bark with light lenticel dots at a node, one detached petal seen from front and back with fine translucent veins, and a macro of needle-sized dew droplets on the petal underside; identical flower design across all panels, soft even studio lighting with subtle contact shadows, no text, no labels, no people, no hands, no background scenery. All surfaces are clean and well tended: petals fresh and dewy with no wilt or bruise, bark smooth and unblemished, the whole sprig looking freshly bloomed and carefully cared for.
```

