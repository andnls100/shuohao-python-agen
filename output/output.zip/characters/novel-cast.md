# novel — 角色表

共 10 位角色：徐今朝、燕溪山、应明霄、九尾狐妖、李长青、小悠、小华、奶娃们、市井修士、江边村民

## 故事摘要

故事发生在架空的修真世界：一条大江沿岸的村镇世代相信江底盘踞着索童的邪神，逢灾病之年便将幼童沉江献祭，江边常见焚香叩首的凡人，也有抱着空襁褓垂泪的母亲。可江底真正的住客，是一只被误当邪神、又被一道温柔封印困了百年的九尾狐——她自身脱身不得，却始终默默捞起被丢进江里的孩子，小悠、小华和那个约莫三岁的奶娃，都是她在水底拉扯大的崽。直到徐今朝与燕溪山这两个身披婚服的修士阴差阳错落入江中，送上门成了她的“苦力”，狐妖才动了借这对外来之客破封、卷崽出水的心思。与此同时，李长青与应明霄两位修士的身影，也出现在这片被献祭异闻笼罩的水域，凡人、幼崽、修士与江底的妖，就此被同一条大江牵到了一处。而这祭童旧俗究竟从何而起、当年又是谁因何封印了她，都还沉在水面之下。

---

## 徐今朝（小姑娘、师妹）

> 主角 · 剑宗的阵法天才小师妹，胆气会缩、追问不停，没两日就啃出了封印的阵眼。

![徐今朝 左：半身像　右：全身三视图](../images/characters/徐今朝-C03-portrait.png)

### 画像

- **性别**：女
- **年龄**：约二十岁上下（推断）；原文只说她与师兄『看起来还很年轻』
- **身份**：剑宗金丹期女弟子、燕溪山的师妹，宗门年轻一辈的天之骄子，阵法上的天才
- 好学 / 单纯 / 较真 / 强撑的胆气 / 痴迷阵法

**外貌**　原文可考的只有两条：年纪很轻（『看起来还很年轻』）；初登场穿红嫁衣——凡人不知狐妖性别喜好，把她和师兄配成一夫一妻、当祭品沉了江。眉眼身量原文未写（缺失）。日常应为剑宗弟子装束：束袖劲装、束腰、佩剑、高马尾，指尖常沾墨迹（以上装束均为推断）。

**性情**　胆气有限却硬撑——被问想不想死时眼神瑟缩了一下，还是强撑着道『我才不怕死』；可一坐进书房就日夜不歇，咬着笔头也要把封印阵法啃穿，问题一个接一个问到底。

**动机**　把封印的原理弄明白、把它解开，把被献祭的孩子送回垂泪的母亲身边；想不通的事，非问到底不可。

**人物弧光**　从我才不怕死的强撑，到看清凡人真面目，再到以阵法天赋主导破封——天真变清醒的行动者

**关系**

- 燕溪山 — 同门师兄，一路同行；总把她挡在身前护着，替她向前辈致歉
- 九尾狐妖 — 初见持剑讨伐的『妖女』，后成并肩破封的前辈；被她的追问逗得哼笑，破阵时还抽过她一尾巴
- 应明霄 — 她挂在嘴边的小师叔——『若是小师叔在就好了』
- 奶娃们 — 被献祭沉江的孩子们；她坚持要把他们送回整日在江边垂泪的母亲身边

**原文依据**

> 我才不怕死！

> 前辈，晚辈还有一事不明。此处的献祭从百年前便开始了，为何那些孩子都没有长大？

> 晚辈觉得……封印前辈之人，似乎舍不得您忍受太久的寂寥。

> 若是小师叔在就好了，他肯定能解这个封印。

> 前辈，此处封印的阵法会变幻，一日之内变幻十二次，每个时辰变一次，我们必须抓紧时间。

> 我们来之前，看到有母亲整日在江边垂泪，盼幼儿归家。我们得把孩子送回去。

### 形象

`young Chinese swordswoman`, `ancient Chinese fantasy`, `Ming-inspired sect wear`, `high ponytail`, `sword at left hip`, `ink-stained fingertips`, `dark teal and white palette`, `soft directional key light`

**出图提示词 · 喂出图模型用这条**

```text
A young Chinese swordswoman of an ancient mountain sect, early twenties, three-quarter view half-body portrait on a grey studio background. Fitted Ming-inspired cross-collared narrow-sleeved jacket in dark-teal weave, white inner collar, dark bound trim, over tapered trousers, wide woven sash with tassel ends. Slender straight sword sheathed at her left hip, left hand on its cord-wrapped hilt. High ponytail bound with a plain cord, worn bamboo brush behind her right ear, fingertips faintly ink-stained from copying array diagrams. Roundish oval face, neat straight brows, bright alert eyes, lively catchlights, small straight nose, full lips, head tilted as if mid-question, eager half-smile, upright easy stance. Soft key light from upper left, cool fill from the right, shallow focus, face tack-sharp.
```

照片级写实真人短剧电影感：真实演员质感，自然的皮肤纹理与符合年龄的毛孔，真实发丝与织物纤维，物理合理的光照，电影镜头成像。单张人物表现性插画，四分之三视角半身像，素净中性灰背景：古代山门剑派的中国年轻女子，二十岁出头，明制样式的交领窄袖合身短衫，细密深青织料，白领口、深色镶边，下着收口长裤，宽织腰带上垂着流苏穗头；左腰佩细直长剑，左手搭在缠绳剑柄上；高马尾以素绳束起，右耳后别一支磨旧的竹毛笔，指尖留着连日抄录阵图的淡淡墨迹。鹅蛋脸，眉形平直，眼神明亮灵动、有高光，鼻梁小巧，唇形饱满自然；头微微偏着像正要发问，唇边带一丝跃跃欲试的笑，腰背挺直，有年轻剑修的利落劲儿。左上方柔和方向主光，右侧冷调补光，浅景深，面部最实。

**反向提示词**

```text
illustration, anime, cartoon outlines, plastic skin, game-render aesthetics, childlike oversized eyes, over-smoothed poreless skin, same face across different characters, perfectly symmetrical face, dead eyes without catchlights, helmet hair with no loose strands, stiff mannequin pose, extra fingers, fused fingers, malformed limbs, blurry distorted face
```

**角色设定图提示词 EN**

```text
ONE 16:9 landscape canvas, pure white background, even margins, three zones divided by hairline rules. LEFT ZONE, about 34% of the canvas width: one bust portrait, head and shoulders, front view, centered like an ID photo, both shoulders complete, bottom edge cut flat, facial features finely drawn as facial design reference. LIGHTING IN THE LEFT ZONE ONLY: soft key light from upper left, ambient occlusion under the jaw, in eye sockets, at collar-neck junction. RIGHT-TOP ZONE: three FULL-BODY views of the same Chinese swordswoman of an ancient mountain sect, early twenties, front, side and back, side by side on one ground line; fitted Ming-inspired cross-collared narrow-sleeved dark-teal jacket, white inner collar, dark bound trim, tapered ankle-bound trousers, wide woven waist sash with tassels, slender straight sword sheathed at left hip, high ponytail, bamboo brush behind right ear, plain cloth boots. LIGHTING IN THE RIGHT ZONES: flat, even, shadowless orthographic lighting for cutout and proportion measurement. RIGHT-BOTTOM ZONE: four to five isolated close-ups in one row, each smaller than the figures: cord-wrapped sword hilt and scabbard throat, ink-stained fingertips pinching a writing brush, the brush behind the ear, woven sash knot with tassel ends, trouser ankle bindings, cloth boots. PROPORTIONS ARE CRITICAL: three equal-height figures, one head-to-body ratio, correct limbs, feet on one ground line, headroom above, margin below; detail studies give way to the figures. ONE face only in the sheet: the three views carry the bust portrait's facial features, hairstyle, eager expression; the left zone is the reference.
```

### 声音

- **音色**：清亮干净的年轻女声，嗓音有锋、尾音利落，微微偏甜
- **音高**：中高音区
- **语速**：偏快，追问起来一气连问，气口都来不及换
- **口音**：标准官话，字正腔圆，带宗门教养出来的清晰吐字
- **情绪**：明亮急切、好奇旺盛；强撑胆气时声音有一瞬发紧
- **类比**：像一个白天练剑、夜里啃阵图，遇到想不通的事就非问出答案不可的年轻剑修

**音色提示词 · 喂 TTS 引擎用这条**

```text
Early-twenties female, bright clear young voice, mid-to-high pitch, forward head-mask resonance, light chest support, moderate dynamic range. Medium-fast pace, eager breath between questions, lively inflection with rising phrase ends. Standard Mandarin, precise articulate diction, no regional accent. Default emotion: earnest bright curiosity, warmly insistent, quick to brighten.
```

---

## 燕溪山

> 主角 · 嘴上喊着要杀要剐决不求饶的剑宗少年天骄，第一个软下来求情的却总是他——先为师妹，后为满洞的孩子。

![燕溪山 左：半身像　右：全身三视图](../images/characters/燕溪山-C02-portrait.png)

### 画像

- **性别**：男
- **年龄**：很年轻，约二十岁上下（推断）
- **身份**：剑宗弟子，金丹期男修，徐今朝的师兄（大师兄），人族里拔尖的天之骄子
- 嘴硬好胜 / 重情护短 / 意气风发 / 勇于认错 / 有担当

**外貌**　原文几乎没写长相：只知他很年轻，与师妹一道被称「看起来还很年轻」，是个「意气风发的少年郎」，替师妹带了一阵孩子后「憔悴了不少」；初登场与师妹同穿婚服、手持利剑。（推断）身量挺拔精干，是常年练剑的肩背；剑眉略不对称，眼睛黑亮锐利，鼻梁高，下颌线利落，惯常挂一丝自负的浅笑；黑发束高髻，鬓边一绺压不平的碎发，眼下有淡淡倦色。常服为深靛蓝窄袖圆领剑袍、白领内衬、黑革带黑靴，佩直刃长剑、白剑穗。

**性情**　话赶话地冲，硬话张口就来：被擒了先喊决不求饶；可硬气撑不过三句，一提到师妹就矮半截，先问对方要怎样才肯放人。做错了事不硬撑到底，认错认得又快又诚恳，责任往自己身上揽。年轻气盛、意气风发，但重情护短永远排在意气前面。

**动机**　起初为除妖卫道下山；被狐妖拿捏后，头一件求的是师妹平安；后来是替封印里那群孩子奔一条回家的路——他们好些家人尚在，盼着孩子归家。

**人物弧光**　从要杀要剐决不求饶的莽劲天骄，到开口只求放过师妹、再到为全群孩子的归途奔走——担当弧

**关系**

- 徐今朝 — 同门师妹、下山除妖的搭档。他处处把她挡在身后，被拿捏时头一个求的是放过她
- 九尾狐妖 — 初见面喊打喊杀讨伐的「妖女」，被擒后改口尊称「前辈」，也是他连声认错揽责的对象
- 李长青 — 师尊、剑宗宗主。师兄弟俩提起他齐刷刷后退一步，敬畏得很
- 小悠、小华、奶娃们 — 师妹研究阵法期间全由他照看的孩子们；破封前匆匆安顿，一心送他们回家

**原文依据**

> 妖女，拿命来！

> 呸！妖女，要杀要剐随你，我决不求饶！

> 你要怎样才肯放过我师妹？

> 晚辈燕溪山，乃剑宗弟子。这是我师妹徐今朝。不知前辈如何称呼？

> 抱歉前辈，我师妹精神憔悴，她比较好学。

> 前辈，我师妹无意冒犯您。

> 不可！我们原是为除害而来。前辈既没有残害幼童性命，他们好些家人尚在，盼着孩子归家。

> 前、前辈恕罪，是我的主意，与师妹无关。

### 形象

`young Chinese swordsman`, `xianxia sect disciple`, `ancient Chinese costume`, `indigo black palette`, `jian sword with white tassel`, `soft directional key light`

**出图提示词 · 喂出图模型用这条**

```text
A young Chinese man around twenty, sword-cultivator disciple of an ancient mountain sect, three-quarter half-body portrait, plain neutral background, upright athletic build, confident bearing. Sword-straight brows, left slightly higher; intense dark eyes, clear catchlights, slightly asymmetric eyelids; high nose bridge, firm jaw, faint proud smirk, under-eye shadow of sleepless nights. Black hair in a high topknot with dark cord, one stubborn lock escaping the right temple. Deep indigo narrow-sleeved round-collar robe with fine dark trim, white inner collar, black leather belt with plain jade clasp, black boots; straight double-edged jian sheathed at his left hip, dark scabbard lacquer worn matte along one draw-line, white silk tassel, right hand on the hilt. Soft directional key light from upper left, gentle cool fill, shallow depth of field, face sharpest.
```

写实真人短剧电影感摄影：真实人类演员、自然皮肤纹理与符合年龄的毛孔、真实发丝与织物纤维、电影镜头质感。单幅表现力人物肖像：约二十岁的中国青年男子，四分之三视角，半身，纯中性背景。古代中国山门的剑修弟子：身姿挺拔、体格精干、意气轩昂。剑眉锋利、左眉略高于右眉；黑亮的眼睛目光锐利、有清晰眼神光、上下眼睑略不对称；鼻梁高挺，下颌线硬朗，嘴角挂着一丝自负的浅笑；二十出头的皮肤毛孔自然，眼下有一片近来缺觉的淡淡青影。黑发以深色发带束成高髻，右侧鬓角翘出一绺压不平的碎发。窄袖圆领剑袍，深靛蓝底、细深色滚边、白领内衬，系黑色革带配素玉带扣，足蹬黑靴；左腰佩一柄直刃双面长剑，深色剑鞘因常年拔剑在出剑一线磨得发哑，白色剑穗。右手搭在剑柄上。左上方柔和方向主光加冷调补光，浅景深，面部最实。

**反向提示词**

```text
illustration, anime, cartoon outlines, plastic skin, game-render aesthetics, waxy airbrushed skin, overly symmetrical face, dead eyes without catchlights, oversized chibi eyes, helmet hair with no stray strands, stiff mannequin pose, extra fingers, fused fingers, deformed hands, mutated limbs, inconsistent likeness between views, modern clothing, watermark, text
```

**角色设定图提示词 EN**

```text
Single character model sheet, ONE 16:9 landscape canvas, pure white background, even margins, hairline rules between zones. Chinese man around twenty, sword-cultivator disciple; sword-straight brows, left slightly higher; dark eyes, slightly asymmetric eyelids; high nose bridge, firm jaw, faint smirk, under-eye shadow; black high topknot, dark cord, one escaping lock, right temple; deep indigo narrow-sleeved round-collar robe, white inner collar, black belt with plain jade clasp, black boots, straight double-edged jian at left hip, white silk tassel, scabbard worn matte along one draw-line. LEFT ZONE, about 34% of canvas width: one large head-and-shoulders bust, front-facing, ID-photo centered, both shoulders visible, flat straight bottom edge, facial design reference. LIGHTING, LEFT ZONE ONLY: soft directional key light from upper left, natural falloff, ambient occlusion under chin, at eye sockets, collar-neck junction. RIGHT-TOP ZONE: three FULL-BODY views in a row, front, side, back, one horizon line, equal height, identical outfit, right hand on the hilt. RIGHT-BOTTOM ZONE: four to five small isolated close-up studies, one even row, smaller than the figures: escaping hair lock, right eye with catchlight, sword hilt with white tassel and worn scabbard line, belt with jade clasp, wrapped black boot; if space runs short, details yield before the figures. PROPORTIONS ARE CRITICAL: three full-body figures, equal height, one head-to-body ratio, correct limb lengths, feet on one ground line, clear margins above heads and below feet, undistorted. LIGHTING, RIGHT ZONES: flat even orthographic light, shadowless, uniform tones. ONE likeness only: full-body views share the bust's face, hairstyle, expression.
```

### 声音

- **音色**：清亮明快的青年男声，偏亮的男高音底子，带一点没褪尽的少年气；气息足、声音结实，冲起来有穿透力
- **音高**：中高
- **语速**：快，字字往前赶，认错求情时才放缓
- **口音**：标准官话，咬字干脆利落（推断）
- **情绪**：明亮自信、少年意气，认错时放软放低
- **类比**：选一个二十岁上下、音色亮、语速快、咬字脆的青年男声参考——像刚下山行事、天不怕地不怕的剑宗大弟子

**音色提示词 · 喂 TTS 引擎用这条**

```text
Young male voice around twenty, bright ringing tenor, clear forward placement, solid breath support, mid-to-high pitch, medium dynamic range. Confident carrying volume, quick brisk pace, clipped decisive phrasing with crisp phrase endings. Standard Mandarin, clean articulate consonants, no regional accent. Default mood: high-spirited, bold, youthful.
```

---

## 应明霄（小师叔）

> 主角 · 剑宗「千年难遇」的阵法天才，百年前受伤闭关的小师叔——全篇只闻其名，片尾一声「应明霄出关了」，就是留给下季的钩子。

![应明霄 左：半身像　右：全身三视图](../images/characters/应明霄-C04-portrait.png)

### 画像

- **性别**：男
- **年龄**：原文无描写；按「百年前受伤闭关」与宗门辈分，设计为出关时约二十七八岁的容貌（推断）
- **身份**：剑宗小师叔、精通各类阵法的旷世天才；多条线索指向他就是百年前封印狐妖之人（推断）
- 惊才绝艳 / 心思缜密（推断） / 外冷内细（推断） / 恩怨分明（推断）

**外貌**　原文对他的外貌只字未提，以下整段为改编设计（推断）：出关时看上去二十七八岁，因长年闭关养伤，肤色是近乎病态的苍白；黑发半束，簪一支素白玉簪，鬓边散落几缕；眉眼清隽，左眉梢比右眉略高一线，眼神冷而专注，眼下带一点倦意。惯常一身墨黑交领道袍，细密哑光丝料，宽袖与下摆以暗银线绣星图纹收边——阵法师的身份记号；左腰佩一柄细剑，素色深鞘；右手指尖常沾干涸的朱砂阵墨，抬手便爱在空中虚划阵纹。

**性情**　全篇未登场，性情只能从那座封印反推（推断）：能布出「一日之内变幻十二次」的阵，是把细致刻进骨子里的人；封印改了时间流逝、却不禁锢其身，居所美如仙境、吃食齐备——把周到做尽，却不求人领情，任由被封的人恨了他一百年。冷面、缜密、深情不外露，是这版设计给他的底色（推断）。

**动机**　本季不正面行动，出关本身即是宣言（推断）：旧封、旧人、旧账，都要当面有个交代——至于这交代是清算还是别的什么，留给下季。

**人物弧光**　本季无正面弧，只做钩子：百年前受伤闭关、如今出关——封与被封的恩怨情账留给下季开

**关系**

- 徐今朝 — 唤他「小师叔」的师侄女，把解开封印的指望全押在他身上的同门天才
- 九尾狐妖 — 疑似百年前封印她的人（推断）——被她记恨为「封印我的那个混蛋」，封印的种种设置却又处处替她着想（推断）
- 燕溪山 — 同门晚辈（推断），徐今朝的师兄，同在这位「小师叔」的辈分之下

**原文依据**

> 对啊，小师叔是我剑宗千年难遇的天才，精通各类阵法。可惜他百年前受伤闭关了，若他在，这个封印肯定不在话下。

> 若是小师叔在就好了，他肯定能解这个封印。

> 晚辈觉得……封印前辈之人，似乎舍不得您忍受太久的寂寥。

> 前辈，我小师叔名为应明霄。

> 应明霄出关了。

### 形象

`male cultivator`, `Chinese xianxia`, `Ming-inspired costume`, `ink-black daopao`, `star-map embroidery`, `jade hairpin`, `cool palette`, `neutral background`

**出图提示词 · 喂出图模型用这条**

```text
A young Chinese male xianxia sect cultivator, apparent age twenty-seven, half-body three-quarter portrait. Ming-inspired ink-black cross-collared daopao of fine matte silk, wide sleeves and hem with discreet dark-silver star-map embroidery, plain white jade hairpin fixing a half-bound topknot with loose strands, slender sword in plain dark scabbard at left hip. Pale indoor complexion, refined sharp features, straight nose, thin lips, cold focused dark eyes with natural catchlights, left brow a fraction higher than the right, faint under-eye fatigue shadows. Right hand raised before the chest, index and middle fingers tracing an invisible array sigil, fingertips stained with dried cinnabar-red ink. Pure neutral grey background. Soft upper-left key light, cool ambient fill, gentle falloff, shallow depth of field, tack-sharp face.
```

角色设定图：仙侠世界中一名二十七八岁模样的中国青年男修士，四分之三视角半身像，纯中性灰背景。写实真人短剧电影质感：真实演员的皮肤纹理与自然毛孔、真实发丝与织物纤维、可信的物理光效、电影镜头感；浅景深，面部最实。明式风格的墨黑交领道袍，细密哑光丝料，宽袖与下摆以暗银线绣星图纹收边；黑发半束，簪一支素白玉簪，几缕散发垂落；左腰佩一柄细剑，素色深鞘。肤色是长年不见天日的苍白，五官清隽，鼻梁挺直，唇线偏薄，眼神冷而专注，左眉梢比右眉略高一线，眼下带一点倦意。右手抬在胸前，食指与中指在空中虚划一道阵纹，指尖沾着干涸的朱砂阵墨。左上方柔和方向主光，冷调环境补光，光影过渡自然。

**反向提示词**

```text
illustration, anime, cartoon outlines, plastic skin, game-render aesthetics, waxy poreless skin, airbrushed face, perfectly symmetrical face, dead eyes without catchlights, helmet hair, stiff mannequin pose, extra fingers, malformed hands, fused limbs, warped anatomy, duplicated face, text, watermark, signature
```

**角色设定图提示词 EN**

```text
Single character model sheet, ONE 16:9 landscape canvas, pure white background, even margins, three zones separated by thin hairline rules. LEFT ZONE, about 34% of canvas width: one bust portrait, head and shoulders, front-facing, ID-photo centered, both shoulders fully visible, bottom edge cut flat and straight, the finely detailed facial design reference. LEFT-ZONE LIGHTING ONLY: soft upper-left key light, natural falloff, ambient occlusion under the chin, in eye sockets, at the collar-neck junction. RIGHT-TOP ZONE: three FULL-BODY views side by side, front, side, back, one ground line, equal height, identical head-to-body ratio, correct limb lengths, true proportional scale, clear headroom above, floor space below. RIGHT-ZONES LIGHTING: flat, even, shadowless orthographic lighting. RIGHT-BOTTOM ZONE: four to five isolated close-up studies in one evenly spaced row, clearly smaller than the figures: white jade hairpin with half-bound topknot, dark-silver star-map embroidery on the black cuff, sword hilt and plain dark scabbard, right fingertips stained with dried cinnabar array ink, cross-collar closure and silk weave; short of space, detail studies yield before the figures, extending down the right edge as a column. PROPORTIONS ARE CRITICAL. Subject: Chinese male xianxia sect cultivator, apparent age twenty-seven; Ming-inspired ink-black cross-collared daopao of fine matte silk, wide sleeves and hem with dark-silver star-map embroidery; plain white jade hairpin; slender sword, plain dark scabbard, left hip; pale complexion, refined sharp features, left brow a fraction higher, cold focused eyes. ONE face only across the sheet: three full-body views match the left-zone portrait in features, hairstyle, expression.
```

### 声音

- **音色**：清冽干净的青年男声，冷而不哑，头腔共鸣明显（推断）
- **音高**：中音区偏低（推断）
- **语速**：不疾不徐，吐字清晰，句尾收得干脆（推断）
- **口音**：标准官话，几乎不带乡音（推断）
- **情绪**：平静自持，淡而克制（推断）
- **类比**：像一个百年不怎么开口的人：音量不高、语速不快，却自有一种让人不敢接话的分量（推断；原文无任何语音描写，整条声线为改编设计）

**音色提示词 · 喂 TTS 引擎用这条**

```text
Young male, apparent age around twenty-seven. Cool clean tenor, mid-to-low pitch, bright head resonance with steady breath support, moderate dynamic range. Quiet controlled volume, unhurried pace, clipped phrase endings, flat intonation that seldom rises. Standard Mandarin, no regional accent. Calm, self-possessed, faintly detached.
```

---

## 九尾狐妖（妖女、邪神、前辈、姐姐、娘亲）

> 主角 · 被凡人冤供成「邪神」的九尾狐大妖——嘴上喊着不想养崽，尾巴却一条裹着一个。

![九尾狐妖 左：半身像　右：全身三视图](../images/characters/九尾狐妖-C01-portrait.png)

### 画像

- **性别**：女
- **年龄**：妖龄数百年（推断）；封印内时流缓慢（外界一月，此处才过一日），自感只被关三年多；容貌如二十出头的年轻女子（推断）
- **身份**：被封印于江底百年的九尾狐族大妖；封印压制下仍一掌震倒两名金丹修士并随手捆人，破封后修为恢复大半；凡人误奉为「邪神」，百年来献祭上百童男童女；她分身众多（皆带她的气息），原本就是崽子们的主要照顾者
- 毒舌 / 傲娇 / 口硬心软 / 慵懒 / 护崽

**外貌**　人形：一头青丝（开场被剑意削去一缕），头顶狐耳，身后九条尾巴；惯穿裙，裙摆常被奶娃抓住。原形为狐，毛发柔顺光滑，最爱化作原形睡在封印内桃园的桃花下。原文无五官描写，按狐族大妖设计：鹅蛋脸、下巴微尖、眼梢微挑，笑起来弯成月牙，唇角常噙着冷笑（推断）；尾色取雪白，与桃花相映（推断）；常服设计为交领层叠丝质襦裙、象牙白配桃粉（推断）

**性情**　说话直白带刺，冷笑、阴森森地笑、弯眸笑轮着来；自称被关三年多脾气已经很平和，实际一点就炸——放话「再吵到我，我就吃小孩儿」，转头又把崽子们哄好、喂饱、差事派得头头是道

**动机**　离开江底这个牢笼，把吵死人的崽子「安顿」掉，找个洞府清清静静闭关；至于安顿——她的版本是一条尾巴裹一个全带走

**人物弧光**　从只想甩掉崽子逃离牢笼，到破封而出仍把上百个崽一条尾巴一个全部卷走安顿——傲娇护崽弧完整；对封印者的态度从冷笑到心头一紧，为下季留情感觉醒口

**关系**

- 奶娃们 — 被塞来照看的崽子。她放话「再吵到我，我就吃小孩儿」，实际养得极好，分身原本就是主要照顾者；破封时一条尾巴裹一个全部带走
- 江边村民 — 把她当江底「邪神」供奉、百年来献祭上百童男童女的凡人；她不堪其扰，觉得「那些凡人才像那等丧心病狂之人」
- 剑宗封印者 — 百年前将她封入江底的人；她提起来只有冷笑——「你们师尊当时想杀我来着」——破封时却心头一紧，旧账没算完
- 市井修士 — 上门找茬的金丹修士；封印压制下仍被她一掌震倒两名、随手捆起来

**原文依据**

> 能不能别送了，我不想养崽！

> 这么弱还敢这么狂，你们家大人怎么放心让你们出来的？

> 我有病啊，谁想养这么吵的东西？要孩子我自己不会生吗！

> 去把他们哄好，再吵到我，我就吃小孩儿。

> 小丫头，乱认娘，我的毛啊什么时候才能好？

> 照我看，那些凡人才像那等丧心病狂之人。

> 你们师尊当时想杀我来着。

> 不用怀疑，但凡这个封印出现缺口，我也会跟着出去哦。

> 真以为谁都能封印我啊？

> 安顿好这群小崽子，我走了。

### 形象

`fox spirit`, `nine tails`, `white fox ears`, `ancient China-inspired xianxia`, `peach blossoms`, `ivory and peach-pink palette`, `silk ruqun`, `soft directional key light`

**出图提示词 · 喂出图模型用这条**

```text
A fox spirit in human form, a Chinese woman appearing in her early twenties from a misty river country of an ancient China-inspired immortal-cultivation world, three-quarter-view half-body portrait on a pure neutral light-gray background. Delicate oval face, softly pointed chin, slightly upturned fox-like eyes curving into smiling crescents, thin lips curled into a lazy one-sided cold smirk. Long loose silky jet-black hair, white fox ears at her crown, a few pink peach-blossom petals in the strands, nine fluffy snow-white fox tails fanned behind her. Layered cross-collared silk ruqun, ivory white with a peach-pink sash, wide flowing sleeves, subtle tonal embroidery, fine fabric neatly kept, fine white fox fur on one sleeve. Languid and self-possessed, weight on one hip, chin slightly raised, one hand idly twirling a peach-blossom sprig. Soft directional key light from upper left, subtle cool fill from the right, shallow depth of field, sharpest focus on her face.
```

写实真人短剧电影感，真人演员质感，自然皮肤纹理与符合年龄的细毛孔，真实发丝与织物纤维，物理合理的打光，电影镜头渲染。人物肖像：古代仙侠世界、烟雨江乡出身的二十岁出头模样的中国女子，狐族化形。四分之三侧身半身像，纯中性浅灰背景。鹅蛋脸，下巴微尖，眼梢微挑、笑起来弯成月牙，薄唇噙着一丝慵懒的单侧冷笑。乌黑长发松松披散，头顶一对雪白狐耳，发间沾着几瓣桃花，身后九条蓬松雪白的狐尾展开。身穿古代中国风的交领层叠丝质襦裙，象牙白配桃粉腰带，宽袖垂坠，同色系暗纹绣花，料子细洁平整，一侧袖口沾着几根细白狐毛。体态慵懒从容，重心落在一边胯上，下巴微抬，一只手闲闲捻着一枝桃花。左上方柔和方向主光，右侧淡淡冷调补光，浅景深，面部最实。

**反向提示词**

```text
illustration, anime, cartoon outlines, plastic skin, game render, waxy airbrushed skin, chibi oversized eyes, perfectly symmetrical face, dead eyes without catchlights, helmet hair, stiff mannequin pose, extra fingers, malformed hands, fused or tangled tails, more than nine tails, blurry face, watermark, text
```

**角色设定图提示词 EN**

```text
Character model sheet, ONE 16:9 landscape canvas, pure white background, even margins, three zones separated by hairline rules. LEFT ZONE (about 34% of canvas width): one head-and-shoulders bust portrait, centered like an ID photo, both shoulders fully shown, straight-cut bottom edge; detailed face — Chinese woman in her early twenties, delicate oval face, softly pointed chin, slightly upturned smiling-crescent fox eyes, lazy one-sided cold smirk, long silky jet-black hair, white fox ears on the crown, peach-blossom petals in the strands. RIGHT-TOP ZONE: three FULL-BODY standing views side by side, front, side, back, one ground line, same face and expression; layered cross-collared silk ruqun, ivory white with peach-pink sash, wide flowing sleeves, long skirt, subtle tonal embroidery, fine fabric, white fox ears and nine fluffy snow-white fox tails fanned behind. RIGHT-BOTTOM ZONE: four to five isolated close-up studies in one row, clearly smaller than the figures — white fox ears, nine tails dotted with peach petals, cross collar with peach-pink sash, embroidered sleeve with fine white fox fur, embroidered silk shoe at skirt hem; when space runs short, detail studies yield first; figures keep full size. PROPORTIONS ARE CRITICAL: three equal-height figures, consistent head-to-body ratio, correct limb lengths, one ground line, headroom and foot margins preserved. LEFT ZONE LIGHTING ONLY: soft directional key light from upper left, ambient occlusion under chin, in eye sockets, at collar-neck junction. RIGHT ZONES LIGHTING: flat even orthographic light, clean silhouettes for cutout and measurement. One character, one face; natural skin texture, individual hair and fabric fibers.
```

### 声音

- **音色**：慵懒妩媚的女中音，音色偏润，喉底带一丝若有似无的哑
- **音高**：中音偏低，慵懒时下坠，被激怒时拔高
- **语速**：慢条斯理，句尾拖一点钩子；嫌弃上头时骤然变快
- **口音**：标准官话，尾音微微上挑，带戏谑的拖腔
- **情绪**：懒洋洋的戏谑垫底，笑里藏锋；偶尔漏出一瞬认真
- **类比**：像一位被封在江底百年、刚被吵醒的大妖：笑吟吟地把威胁说成家常，转头又低声哄崽——不是甜腻少女音，也不是播音腔

**音色提示词 · 喂 TTS 引擎用这条**

```text
Adult female voice, apparent mid-twenties. Sultry languid mezzo-soprano, mid-to-low pitch with lazy downward drawls, smooth chest resonance with a faint breathy edge, moderate dynamic range. Medium-soft volume, unhurried pace with drawn-out phrase endings and a taunting lilt, light mocking chuckle in the tone. Standard Mandarin accent. Default mood: lazily amused, teasing, faintly dangerous.
```

---

## 李长青

> 配角 · 全季未登场、只活在台词与一帧剪影里的剑宗宗主——百年前封印现场想杀狐妖的人，一句转述便把师门拉进嫌疑席。

![李长青 左：半身像　右：全身三视图](../images/characters/李长青-C05-portrait.png)

### 画像

- **性别**：男
- **年龄**：原文未写明；百年前已是宗主且至今在位，年岁至少逾百（推断），形貌如五旬上下（推断）
- **身份**：剑宗宗主，燕溪山与徐今朝的师尊；百年前围封江底狐妖时在场、主张杀之，而封印者并非他。本季未正面登场，仅存在于对话与一帧回忆剪影。
- 威严 / 杀伐果决 / 深藏不露（推断）

**外貌**　原文无外貌描写（全季未正面登场）。为拍摄补全（推断）：身量高挺，立姿沉静自律；面容清癯，颧骨偏高，平直剑眉下双目深陷、眼型细长，薄唇平抿，颌下短须间杂灰白，鬓角一线霜白；左眉上一道细长旧剑疤，是百年前围封之役留下的旧痕（推断）。长发束入白玉冠，玄青大袖道袍暗织银线云纹，素玉带钩收束，腰悬深鞘直剑。年岁逾百而形貌停在五旬上下（推断）。

**性情**　无正面言行可依据，形象全部由侧写拼出：弟子提到他时齐刷刷往后退了一步、只敢小声道——威压不靠发怒，靠存在本身。百年前面对江底狐妖的第一反应是杀，下手不留余地（推断：从狐妖转述侧写）。如今的他深浅不知，敌友未定（推断）。

**动机**　百年前围封狐妖时在场、主张杀之；如今仍执掌剑宗，以宗门与门下弟子为先（推断）。本季未登场，动机原文未展开。

**人物弧光**　功能弧：用你们师尊当时想杀我来着一句把宗门拉进嫌疑席，为下季铺敌友未定

**关系**

- 燕溪山 — 徒弟。提到师尊时齐刷刷往后退了一步、小声作答，敬畏极深
- 徐今朝 — 徒弟。曾当面追问封印江底狐妖的是否正是师尊
- 九尾狐妖 — 百年前封印现场的旧敌：狐妖言明封印者不是他，但他当时想杀她
- 应明霄 — 同门师弟（推断：弟子称应明霄为小师叔，两人同辈）

**原文依据**

> 李长青是你们什么人？

> 正是剑宗宗主，也是……家师。

> 原来你们是他教出来的好徒弟啊。

> 前辈，不会是我师尊封印的您吧？

### 形象

`ancient China`, `Ming-inspired robe`, `sword sect master`, `jade hair crown`, `dark indigo silk`, `silver cloud pattern`, `neutral grey background`, `soft directional light`

**出图提示词 · 喂出图模型用这条**

```text
A tall, upright Chinese man in his mid-fifties, a sword-cultivation sect master in a Ming-inspired ancient Chinese world. Lean refined face, high cheekbones, deep-set narrow eyes under straight sword-shaped brows, thin level lips, short grey-streaked dark beard, one frost-white line at the temples, a thin old sword scar through the left eyebrow. Long black hair bound in a white jade crown. Dark indigo wide-sleeved silk daopao with a faint woven silver-cloud pattern, plain jade belt hook, a straight sword in a dark scabbard at the waist. Standing still and settled, hands clasped behind his back, gaze level and unhurried. Three-quarter view half-body portrait on pure neutral grey background, soft directional key light from the left with a cool fill, shallow depth of field, face in sharpest focus.
```

写实真人短剧摄影质感，真实演员，自然肤质与符合年龄的毛孔，真实发丝与织物纤维，物理合理的光照，电影镜头感。一位看似五十五岁上下的中国男子，明代气质的古代中国背景下的一派剑修掌门。身量高挺，仪态沉静自律；面容清癯，颧骨偏高，平直剑眉下双目深陷、眼型细长，薄唇平抿，颌下短须间杂灰白，鬓角一线霜白；左眉上一道细长旧剑疤。长发束入白玉冠；玄青色明代气质大袖道袍，细密丝绸上暗织银线云纹，以素玉带钩收束；腰间悬一柄深鞘直剑。负手而立，重心沉稳，目光平视、不急不缓。四分之三视角半身像，纯中性灰背景，左侧柔和方向主光加冷调补光，浅景深，面部最实。

**反向提示词**

```text
illustration, anime, cartoon outlines, plastic skin, game-render aesthetics, over-smoothed poreless skin, oversized childlike eyes, perfectly symmetrical face, dead eyes without catchlights, helmet hair with no loose strands, stiff mannequin pose, extra fingers, fused fingers, malformed limbs, text, watermark
```

**角色设定图提示词 EN**

```text
Character model sheet, ONE 16:9 landscape canvas, pure white background, even margins, thin hairline rules between zones. LEFT ZONE, about 34% of canvas width: one head-and-shoulders bust portrait, front view, centered like an ID photo, both shoulders fully visible, bottom edge cut flat, face large, fully detailed: Chinese man in his mid-fifties, lean face, high cheekbones, deep-set narrow eyes, sword-shaped brows, thin lips, short grey-streaked dark beard, one frost-white line at the temples, thin old sword scar through left eyebrow, long black hair in white jade crown, dark indigo wide-sleeved silk daopao, faint woven silver-cloud pattern. LIGHTING IN THE LEFT ZONE ONLY: soft directional key light from upper left, natural falloff, ambient occlusion at chin, eye sockets and collar-neck junction. RIGHT-TOP ZONE: three FULL-BODY views, front, side, back, standing side by side on one shared ground line, same face, hairstyle, expression as the left portrait, same robe, plain jade belt hook, straight sword in dark scabbard at waist, hands clasped behind back. RIGHT-BOTTOM ZONE: four to five isolated close-up studies in one evenly spaced row, clearly smaller than the figures: white jade crown, old scar through left eyebrow, woven silver-cloud pattern at collar, plain jade belt hook, sword hilt, dark scabbard. LIGHTING IN THE RIGHT ZONES: flat, even orthographic lighting, uniform and shadowless. PROPORTIONS ARE CRITICAL: three full-body figures equal in height, one consistent head-to-body ratio, correct limb lengths, undistorted figures, feet on one ground line, clear space above heads and below feet, detail studies stay secondary.
```

### 声音

- **音色**：低沉醇厚的男中低音，胸腔共鸣足，音色暗而不哑，有年月压出来的分量
- **音高**：低
- **语速**：缓慢，字与字之间留白长，句尾落得稳
- **口音**：字正腔圆的官话，带古雅书面腔，无地域口音
- **情绪**：平静而威压沉沉，不怒自威
- **类比**：找一个弟子只敢远远听令的中年男声：低、慢、每个字都稳稳落地，不带火气却让人不敢接话

**音色提示词 · 喂 TTS 引擎用这条**

```text
Male, perceived late fifties. Deep bass-baritone, low pitch range, full chest resonance, steady breath support, wide but controlled dynamic range. Moderate-low volume, slow measured pace, long deliberate pauses between phrases, level falling cadence. Standard formal Mandarin, literary register, no regional accent. Calm, stern, quietly authoritative.
```

---

## 小悠

> 配角 · 七岁被献祭丢进江底的村童，被狐妖养到十岁，拉着人袖角认真说「等我长大，我养你」。

![小悠 左：半身像　右：全身三视图](../images/characters/小悠-C06-portrait.png)

### 画像

- **性别**：女
- **年龄**：现十岁，初来时七岁（封印内计龄；人间已过百年）
- **身份**：江边村童出身，第一对被献祭送入江底的幼童之一（与小华一对）；有灵根，破封后随剑宗师兄妹修行
- 乖巧 / 黏人 / 懂事 / 念恩

**外貌**　原文只写到她梳着小辫子（会被狐妖揪）、说话会脸红，年岁之外再无外貌描写。（推断）两条细麻花辫垂在肩前，圆脸，眼睛干净亮堂；被养得很好，粗布衣裳干净齐整，惯于轻轻扯住大人的衣袖。

**性情**　轻声细语，开口先唤「姐姐」；怯生生却恳切，敢把心愿直直说出来，被夸就红脸，答应的事记得牢。

**动机**　破封后随师兄妹去剑宗修行，是她被点名的机缘；她心里更想的，是留在姐姐身边——「等我长大，我养你」。

**人物弧光**　从江底孤童到长大我养你的归属感落点，破封后随剑宗去修行

**关系**

- 九尾狐妖 — 唤作「姐姐」，被她收留养大；想跟她走，放话长大要养她
- 小华 — 同批被送下江底的幼童，初来时结伴的一对
- 奶娃们 — 转达「他们吵着要见你」、帮忙哄带的小崽子（推断，原文明写的是「一个小姑娘」，暂记在小悠名下）

**原文依据**

> 姐姐醒了？

> 姐姐，他们吵着要见你，怎么哄都不听，带过来才终于不哭了。

> 他们在封印边界查看。

> 姐姐，我们不能跟你走吗？

> 姐姐，等我长大，我养你。

### 形象

`ancient Chinese child`, `river-village girl`, `twin braids`, `indigo cotton hanfu`, `cream and indigo palette`, `soft directional lighting`, `neutral background`

**出图提示词 · 喂出图模型用这条**

```text
A single character portrait of a ten-year-old ancient Chinese river-village girl, waist-up three-quarter view against a plain neutral background. Round soft child face with full cheeks, bright dark-brown eyes with natural catchlights, small straight nose, a light rosy flush on the cheeks. Black hair center-parted, two slender braids hanging over the front of her shoulders with plain cloth ties, fine wispy baby hairs along the hairline. She wears a cross-collar narrow-sleeved hanfu jacket in soft indigo cotton over a calf-length undyed hemp skirt, soft flat cloth shoes, fabrics freshly laundered with neatly stitched hems. One small hand half-raised at chest height, fingers curled as if about to tug a sleeve, head tilted slightly upward, a shy hopeful smile. Soft directional key light from the upper left, cool fill from the right, shallow depth of field, focus sharpest on the face.
```

写实真人短剧质感：真实儿童演员、自然的皮肤纹理与符合年龄的毛孔、真实发丝与织物纤维、物理可信的光线、电影级镜头感。单幅人物表现画：十岁的古代中国江边村童女孩，四分之三视角、腰腹以上半身，纯中性背景。圆软的孩童脸庞，脸颊饱满，明亮的深棕色眼睛带自然眼神光，小巧挺直的鼻梁，脸颊一层淡淡红晕。黑发中分，两条细麻花辫垂在肩前，用素色布绳扎起，发际线带着细软碎发。穿交领窄袖短襦，靛蓝软棉布，下身米白粗麻及膝裙，脚踩软底布鞋；衣料朴素但干净、浆洗齐整，衣缘缝线细密。一只小手抬在胸前，手指微卷，像正要轻扯谁的衣袖；头微微上仰，带着羞怯又期待的笑。左上方柔和方向主光，右侧冷调补光，浅景深，焦点落在面部。

**反向提示词**

```text
illustration, anime, cartoon outlines, plastic skin, game-render aesthetics, chibi oversized eyes, adult facial features on a child, mature makeup, over-smoothed poreless skin, perfectly symmetrical face, dead eyes without catchlights, helmet hair, stiff mannequin pose, extra fingers, malformed hands, fused limbs, warped proportions, text, watermark, logo
```

**角色设定图提示词 EN**

```text
Single character model sheet on ONE 16:9 landscape canvas, pure white background, even margins, thin hairline rules dividing the zones. LEFT ZONE, about 34% of the canvas width: one bust portrait, head and shoulders, front-facing, centered like an ID photo, both shoulders fully visible, bottom edge cut flat and straight; the facial design reference — a ten-year-old ancient Chinese river-village girl, round soft face, full cheeks, bright dark-brown eyes with natural catchlights, black hair center-parted into two slender braids over the shoulders with plain cloth ties. LIGHTING IN THE LEFT ZONE ONLY: soft directional key light from the upper left, natural falloff, ambient occlusion under the chin, in the eye sockets and collar-neck junction. RIGHT-TOP ZONE: three FULL-BODY standing views, front, side and back, side by side on one shared ground line, equal heights, identical head-to-body ratio, correct child proportions and limb lengths, clear space above heads and below feet. LIGHTING IN THE RIGHT ZONES: flat even orthographic lighting, diffuse and shadowless. RIGHT-BOTTOM ZONE: four to five small isolated close-up studies in one row, clearly smaller than the full-body figures — the two braids with their cloth ties, the cross-collar closure with cotton weave, a small hand, fingers curled mid sleeve-tug, soft flat cloth shoes, a neatly stitched hem; the detail studies yield first when space runs short, extending down the right edge as a column, while the figures keep full height. ONE FACE ONLY: three full-body views share the left bust portrait's exact facial features, hairstyle and expression. PROPORTIONS ARE CRITICAL.
```

### 声音

- **音色**：清亮软糯的童声，带一点自然的气声，干净不沙哑
- **音高**：高（孩童音区）
- **语速**：中等偏慢，恳切时略快，句尾不拖
- **口音**：标准普通话，咬字偏软，不带地域口音
- **情绪**：乖巧依恋，怯生而恳切
- **类比**：像一个怕被落下、轻轻扯住大人袖角小声喊「姐姐」的小姑娘

**音色提示词 · 喂 TTS 引擎用这条**

```text
10-year-old girl, clear sweet child voice with a light breathy edge, high pitch, thin chest support, small dynamic range. Moderate volume, moderate pace, slight rising inflection at phrase ends. Standard Mandarin, soft precise articulation, no regional accent. Affectionate, earnest, a little shy.
```

---

## 小华

> 配角 · 和小悠同批被献祭进江底的孩子，性子比谁都好强，连给姐姐养老送终的承诺都要抢着说。

![小华 左：半身像　右：全身三视图](../images/characters/小华-C07-portrait.png)

### 画像

- **性别**：男（推断：原文未明写性别；既与小姑娘小悠配成第一对献祭幼童，按童男童女成对献祭的惯例补为男童）
- **年龄**：初来七岁，如今十岁（封印内时间；人间已过百年，父母兄弟早已去世）
- **身份**：百年前被选送江底献祭的幼童之一（与小悠同批），有灵根／修炼资质，封印破除后将随去剑宗
- 活泼 / 要强 / 不服输 / 重情

**外貌**　原文无外貌描写（缺失），以下按十岁男童、活泼要强的性格与江边贫家出身补全（推断）：圆脸晒得微黑，黑亮的眼睛，笑起来门牙缺了一颗；黑色短发，跑得乱糟糟；个头不高但结实，手脚闲不住。常穿江边人家常见的粗布对襟短褂（布结扣）与蓝灰布裤，脚上黑布鞋被跑动磨得起了毛边。时代按『人间已过百年』倒推，约为清末民初（推断）。

**性情**　嗓门大、性子急，话必抢先说；听小悠说要养姐姐，立刻不甘示弱喊出自己的那句。孩子的许诺不掺算计，喊得越响越是当真。

**动机**　快快长大、好好修炼，将来给狐妖姐姐养老送终——这件事上一步也不能让给小悠。

**人物弧光**　同小悠：从被献祭者到主动画饼报恩的孩子，用童真反衬凡人残忍

**关系**

- 九尾狐妖 — 唤作姐姐的收留人，被他抢着承诺养老送终的对象
- 小悠 — 同批被献祭的伙伴，连报恩都要跟她比个先后的好强对象

**原文依据**

> 姐姐，我也会给你养老送终的！

### 形象

`character portrait`, `early twentieth century China`, `river village`, `handwoven cotton clothing`, `earth-tone palette`, `soft directional lighting`

**出图提示词 · 喂出图模型用这条**

```text
A ten-year-old Chinese village boy from an early twentieth century river town, round sun-tanned face, full cheeks, bright black eyes with natural catchlights, a noticeable gap from a missing front baby tooth, short mussed black hair, small sturdy build for his age. He grins wide mid-shout, mouth open, rushing to speak first, leaning eagerly forward with small fists clenched at his chest. He wears a coarse undyed handwoven cotton jacket with a duijin front and cloth knot buttons, loose blue-grey cotton trousers, black cloth shoes scuffed from running along the river bank. Three-quarter half-body view on a plain neutral background, soft directional key light from the upper left with cool fill light, shallow depth of field, face in sharpest focus.
```

写实真人短剧影像风格：真实儿童演员，自然的皮肤质感与符合年龄的毛孔，真实发丝与织物纤维，物理可信的布光，电影镜头质感。角色肖像：二十世纪初江边村镇的十岁中国男孩，圆脸晒得微黑、脸颊饱满，黑亮的眼睛有自然眼神光，门牙缺了一颗，正咧嘴大喊；黑色短发跑得乱糟糟；个头不高但结实。穿粗棉对襟短褂、布结扣，下身蓝灰色粗布裤，脚上黑布鞋在河堤上跑得磨出了毛边。四分之三视角半身构图，攥着小拳头身体前倾，一副抢着要先开口的样子。纯中性背景，柔和方向主光加冷调补光，浅景深，面部最清晰。避免插画、动漫、卡通描边、塑料皮肤和游戏渲染感。

**反向提示词**

```text
illustration, anime, cartoon outlines, plastic skin, game-render aesthetics, smooth poreless skin, waxy complexion, oversized anime eyes, perfectly symmetrical face, dead eyes without catchlights, helmet hair, stiff mannequin pose, extra fingers, fused or malformed hands, adult facial proportions on a child body
```

**角色设定图提示词 EN**

```text
Single character model sheet on one 16:9 landscape canvas, pure white background, even margins, three zones separated by thin hairline rules. LEFT ZONE, about 34% of the canvas width: one head-and-shoulders bust portrait, front view, centered like an ID photo, both shoulders fully visible, bottom edge cut flat and straight; the fully detailed design-reference face — a ten-year-old Chinese boy from an early twentieth century river town, round sun-tanned face, bright black eyes, a noticeable gap from a missing front baby tooth, short black hair, coarse undyed handwoven cotton duijin jacket with cloth knot buttons. LIGHTING IN THE LEFT ZONE ONLY: soft directional key light from the upper left with natural falloff, ambient occlusion under the chin, in the eye sockets, at the collar-neck junction. RIGHT-TOP ZONE: three full-body views side by side — front, side, back — sharing one horizon line, wearing the same undyed cotton duijin jacket, loose blue-grey trousers and black cloth shoes, matching the left portrait's face, hairstyle and expression. RIGHT-BOTTOM ZONE: four to five isolated close-up studies evenly spaced in one row, each clearly smaller than the full-body figures: gap-toothed grin, cloth knot buttons, coarse handwoven cotton weave, a scuffed black cloth shoe, a small clenched fist, the mussed short haircut. PROPORTIONS ARE CRITICAL: the three full-body figures equal in height, consistent head-to-body ratio, correct limb lengths, feet on one ground line, headroom and footroom preserved, naturally proportioned; detail studies yield space, figures keep full size. LIGHTING IN THE RIGHT ZONES: flat, even, shadowless orthographic lighting.
```

### 声音

- **音色**：清亮响亮的男童声，音色薄但结实
- **音高**：高
- **语速**：快，兴头上来字赶字
- **口音**：标准普通话，无明显乡音
- **情绪**：雀跃、好胜、一本正经的认真
- **类比**：像在操场上跟同伴比嗓门、非得压过别人一头的小男孩

**音色提示词 · 喂 TTS 引擎用这条**

```text
Ten-year-old Chinese boy, bright clear child voice, high pitch, light chest support, forward oral resonance, small-to-moderate dynamic range. Lively volume, quick eager pace, slightly tumbling rhythm, bouncing intonation. Standard Mandarin, no regional accent. Default emotion: buoyant, competitive, earnest.
```

---

## 奶娃们

> 龙套 · 被凡人当祭品沉江、又被她捞起来养大的一群幼崽：抓着裙摆喊「娘亲」，哭声如雷——全剧的笑点发动机，也是她没害孩子的活证据。

![奶娃们 左：半身像　右：全身三视图](../images/characters/奶娃们-C08-portrait.png)

### 画像

- **性别**：男女皆有（推断）
- **年龄**：半岁到五六岁不等，以两三岁为多（推断）
- **身份**：被江边村民当祭品沉江、获救后跟着她生活的凡人幼童（群像）
- 黏人 / 爱哭 / 不怕她 / 认准了就不撒手

**外貌**　混龄的一群幼童：最小的还裹在襁褓里咂手指，大的刚过六岁（推断）。被养得极好，个个圆脸蛋、气色红润，穿江边村落的粗布小衫，洗得干净，有的裤膝磨破——是整天爬上爬下磨的（推断）。最扎眼的是那个三岁小丫头（推断）：头顶一撮冲天辫，一只小手总攥着一角布料不撒手，喊「娘亲」的时候嘴张得圆圆的。

**性情**　极端两头的年纪：不哭就笑，中间没有过渡。哭起来声如雷，能把她从睡梦里吵醒；一旦认定了「娘」，就抱住不撒手——抓裙摆、爬到身上、往毛里扎，口水蹭一脸也不觉得。

**动机**　吃饱、睡觉、跟紧「娘」。谁把他们从水里捞起来，谁就是娘。

**人物弧光**　静止中带暖：从江底的祭品变成被养得油光水滑的幼崽；他们越健康活泼，越证明她没害过孩子。全剧不成长、不离开，只负责热闹。

**关系**

- 狐妖 — 被他们乱认成「娘亲」的救命恩人与饲养员
- 江边村民 — 把他们扎成祭品沉江的同乡（推断）

**原文依据**

> 能不能别送了，我不想养崽！

> 去把他们哄好，再吵到我，我就吃小孩儿。

> 小丫头，乱认娘，我的毛啊什么时候才能好？

> 安顿好这群小崽子，我走了。

### 形象

`group of toddlers`, `ancient Chinese river village`, `rescued children`, `coarse hemp clothing`, `undyed grey and faded red`, `soft directional lighting`, `neutral background`

**出图提示词 · 喂出图模型用这条**

```text
Group portrait of five rescued ancient Chinese river-village toddlers, from a swaddled baby to about six, huddled close in half-body three-quarter view on a plain, unmarked neutral grey background. All well-fed and rosy-cheeked, round-faced and bright-eyed, with flyaway baby hair, in clean coarse hemp tunics and padded vests of undyed ecru, grey and one faded madder red, the biggest boy's trousers patched at both knees. At the front a girl of about three with a tufted topknot, flushed cheeks, mouth wide open mid-call, one tiny fist gripping a cloth fold; beside her a thumb-sucking swaddled baby, a boy with an unruly cowlick rubbing his nose with a sleeve, a small girl with two braided loops half-asleep against the biggest boy's shoulder. Soft key light from upper left, cool fill from the right, shallow depth of field, faces tack sharp.
```

真人短剧摄影质感，真实孩童演员，自然的皮肤质感与符合年龄的毛孔，真实的发丝与织物纤维，物理可信的光照，电影镜头感。群像：五名获救的古代江边村落幼童，男女皆有，从裹襁褓的婴儿到六岁上下，紧紧挤作一团，四分之三视角半身构图，纯中性灰背景。个个被养得圆润红润、看得出被照顾得很好：圆脸蛋、眼睛亮，干净的粗布小衫与坎肩，本白、原灰，还有一件褪色的暗红，最大那男孩的裤膝因总往上爬而打着补丁。最前面是约三岁的小丫头，头顶一撮冲天辫，脸蛋通红，喊到一半嘴张得圆圆的，一只小手攥着一角布料死不撒手；旁边是裹在襁褓里咂手指的婴儿；一个头发翘成一撮的男孩用袖子蹭鼻子；一个扎双环髻的小姑娘困倦地靠在大男孩肩上。左上方柔和方向主光，右侧冷调补光，浅景深，面部最实，细软的胎发与清晰的粗布织纹。无文字，无水印。

**反向提示词**

```text
illustration, anime, cartoon outlines, plastic skin, waxy airbrushed skin, game-render aesthetics, perfectly symmetrical faces, identical clone faces among the children, dead eyes without catchlights, doll-like glassy eyes, adult proportions on toddlers, elongated limbs, extra fingers, deformed hands, fused fingers, stiff mannequin poses, helmet hair, blurry faces, text, watermark
```

**角色设定图提示词 EN**

```text
Character model sheet of five toddlers on one 16:9 landscape canvas, pure white background, even margins, hairline rules between zones. LEFT ZONE, about 34% of canvas width: one large head-and-shoulders bust of the lead girl of about three, tufted topknot, flushed cheeks, front-facing, passport-photo centered, both shoulders fully visible, bottom edge cut straight, features in full detail as the group's face baseline; left-zone lighting only: soft directional key from upper left, natural falloff, ambient occlusion under the chin, in the eye sockets and collar-neck junction. RIGHT-TOP ZONE: three full-body views of the lead girl (front, side, back) side by side, beside a front-view height lineup of the other four children, from swaddled baby to six-year-old boy, in coarse hemp tunics and padded vests of undyed ecru, grey and one faded madder red; PROPORTIONS ARE CRITICAL: all figures on one shared ground line, age-accurate toddler proportions, large heads, short limbs, correct head-to-body ratio, limbs at true length, headroom and footroom preserved. RIGHT-BOTTOM ZONE: four to five isolated close-up studies in an evenly spaced row, clearly smaller than the full-body figures: tufted topknot with flyaway strands, tiny fist gripping bunched cloth, double knee patch, coarse hemp weave, bare feet with river-mud stains, swaddling bundle with thumb-sucking hand; if space runs short these yield first, extending as a column along the right edge. Right-zone lighting: flat, even, orthographic light, shadowless. One face only across the sheet: the three views and detail studies match the left bust exactly, same features, same expression.
```

### 声音

- **音色**：奶声奶气的幼童齐声，男女娃混在一起，音色又细又亮，带点鼻音
- **音高**：高
- **语速**：急促，抢着说，字还没咬清就往下赶
- **口音**：江边村落的孩童土腔，吐字含混
- **情绪**：两头跳：要么炸开大哭，要么咯咯傻笑，没有中间态
- **类比**：像一群刚从水里被捞起来、认定了一个娘的孩子，齐声喊娘的时候整条江都听得见

**音色提示词 · 喂 TTS 引擎用这条**

```text
Collective toddler chorus of boys and girls, about two to five years old. Bright piping timbre, high pitch, thin chest support, small resonance, wide dynamic swings. Loud volume, fast tumbling pace, slurred toddler articulation, blunt sentence ends. Rural inland Chinese accent, soft blurred word endings. Default mood: clingy and demanding, quick to wail, quick to giggle.
```

---

## 市井修士

> 龙套 · 茶肆里消息最灵通的市井散修，靠消息和符纸换生计——第6集把「应明霄出关了」这句噩耗说出口的就是他。

![市井修士 左：半身像　右：全身三视图](../images/characters/市井修士-C10-portrait.png)

### 画像

- **性别**：男
- **年龄**：约四十岁上下（推断）
- **身份**：寄居市井的低阶散修，修为拿不出手，靠卖符纸、递消息、替人跑腿在市井里糊口（推断）
- 嘴快 / 消息灵通 / 惜命 / 势利

**外貌**　清瘦，肩背微微前倾，是常年在外跑动晒出来的深肤色；窄脸，眼神活络，左眉比右眉稍高，像总在打听什么；短须稀疏，头发胡乱挽成一个髻，插一根素木簪。穿一件洗得发白的灰青色棉布道袍，袖子偏长，左袖口里掖着一沓黄纸符，手边常有一只缺口的粗陶茶碗。（以上形象细节均为推断）

**性情**　嗓门不高、字却密，凑近了压着嗓子说话，说到紧要处偏要停半拍吊人胃口；一听风声不对，眼睛先往门口瞟。

**动机**　消息就是他在市井立足的本钱。把大新闻第一个说出口，换的是满座侧目和几碗茶的交情——至于消息是福是祸，那是听的人的事。

**人物弧光**　单场功能，无成长弧线：进茶肆、落座、把「应明霄出关了」说出口、看着满座变色，随即缩回人群边上。（改编新增的单场功能角色）

**关系**

- 应明霄 — 他在第6集茶肆间亲口报出「出关了」噩耗的剑宗小师叔；两人素不相识，他只是消息的搬运工

**原文依据**

> 应明霄出关了。

### 形象

`character design`, `ancient Chinese tea house`, `market cultivator`, `grey cotton daopao robe`, `yellow paper talismans`, `wooden hairpin`, `muted earth tones`

**出图提示词 · 喂出图模型用这条**

```text
Half-length three-quarter-view portrait of a lean Chinese man in his early forties, a low-rank itinerant cultivator among commoners in a Ming-inspired immortal-cultivation world. Narrow sun-browned face, sharp restless dark eyes, left brow slightly higher than the right, deepened crow's feet and nasolabial folds, thin patchy beard along the jaw, rough topknot skewered by a plain wooden hairpin. Washed-pale grey-blue cotton daopao robe, slightly overlong sleeves faded at shoulders and elbows, yellow paper talismans tucked into the left cuff, chipped coarse clay teacup in his right hand, left hand raised loosely mid-speech, fingers slightly spread. Pure neutral grey backdrop. Soft directional key light from the upper left with cool fill, shallow depth of field, face and eyes in sharpest focus.
```

半身人物像，四分之三视角：四十岁上下的清瘦男子，混迹市井的低阶散修，古风修仙世界、明代风格的平民装束。窄脸，常年赶路晒出的深肤色，黑眼睛眼神活络，左眉比右眉稍高，眼角与法令纹加深，颌下短须稀疏，头发胡乱挽成髻、插一根素木簪。穿一件洗得发白的灰青色棉布道袍，袖子偏长，肩肘处因常年赶路褪得发白，左袖口里掖着一沓黄纸符，右手端一只缺口的粗陶茶碗，左手抬在半空、手指微张，正说到兴头上。纯中性灰背景，左上方柔和方向主光加冷调补光，浅景深，面部与眼睛最实。写实真人短剧影像质感，真实皮肤纹理与符合年龄的毛孔，真实发丝与织物纤维，物理合理的光照，可信的触感道具，电影镜头感。

**反向提示词**

```text
illustration, anime, cartoon outlines, plastic skin, game render aesthetics, waxy poreless skin, young face, perfectly symmetrical face, dead eyes without catchlights, helmet hair, extra fingers, malformed hands, twisted limbs, stiff mannequin pose, blurry face
```

**角色设定图提示词 EN**

```text
Single character model sheet, 16:9 landscape canvas, plain white background, even margins, three zones divided by hairline rules. A lean Chinese man in his early forties, a low-rank itinerant cultivator among commoners in a Ming-inspired immortal-cultivation world. LEFT ZONE, about 34% canvas width: one bust portrait, front-facing, ID-photo centered, both shoulders visible, bottom edge cut flat; face as design reference — narrow sun-browned face, sharp restless dark eyes, left brow slightly higher than the right, deepened crow's feet and nasolabial folds, thin patchy beard, rough topknot with plain wooden hairpin. LIGHTING IN THE LEFT ZONE ONLY: soft directional key from the upper left, ambient occlusion under the jaw, in eye sockets, at collar-neck junction. RIGHT-TOP ZONE: three FULL-BODY views side by side — front, side, back — sharing one ground line, equal height, correct head-to-body ratio and limb lengths, clear headroom, foot margin; in washed-pale grey-blue cotton daopao robe, overlong sleeves faded at shoulders and elbows, yellow paper talismans at the left cuff, cloth leg wraps, plain straw sandals. RIGHT-BOTTOM ZONE: four to five small isolated close-up studies in one row, clearly smaller than the figures: wooden hairpin and topknot, yellow talisman bundle at the cuff, mended collar stitching, chipped coarse clay teacup, straw sandals and leg wraps; if space runs short, studies yield first, figures intact. LIGHTING IN THE RIGHT ZONES: flat even orthographic lighting, uniform illumination. PROPORTIONS CRITICAL: natural undistorted proportions in every view, consistent with the bust portrait; one face identity across all views, matching the LEFT ZONE portrait exactly.
```

### 声音

- **音色**：偏薄的男中音，带沙哑颗粒和一点鼻音，亮而发紧
- **音高**：中高
- **语速**：快而碎，字密爱连读，尾音上挑
- **口音**：市井口语腔，吐字不太讲究，带点南方小镇的软
- **情绪**：热络、雀跃，带一点卖关子的得意
- **类比**：像茶馆里凑到你桌边、压低嗓子说「你听说了吗」的那个熟客

**音色提示词 · 喂 TTS 引擎用这条**

```text
A man around forty, thin reedy mid-register male voice with a light nasal buzz, modest breath support, narrow dynamic range. Fairly loud, quick clipped pace, words running together, rising inflection at phrase ends. Local market-town accent, loose diction. Default energy: eager, quick, faintly smug.
```

---

## 江边村民

> 龙套 · 灾年把婴孩献进江里、灾停了又磕头谢神的村民群像——第1集开场执祭的手，第3集反转后露出的真凶脸。

![江边村民 左：半身像　右：全身三视图](../images/characters/江边村民-C09-portrait.png)

### 画像

- **性别**：男女皆有；视觉代表取中年男性（推断）
- **年龄**：群像覆盖青年至老年；代表形象约五十五岁（推断）
- **身份**：江边村落的村民，务农打渔为生（推断）；灾年主持把婴孩献祭给江神的凡人群体，合并自原著中执祭的村民与整日在江边垂泪的母亲。
- 迷信 / 随众 / 怯懦 / 自欺

**外貌**　原著未写外貌，以下为合成设计（推断）：代表形象是一名面朝江水讨生活的清瘦农人，皮肤被日头晒得黝黑粗糙，法令纹与眼角纹顺表情纹路而深，花白胡茬，靛蓝布头巾裹住稀疏花白的头发，粗麻短褐、麻裤、绑腿、草鞋，左手攥着一把线香，指腹被经年香灰浸得发黄。人群里也有包着头巾的妇人，眼泡哭肿——整日在江边垂泪、盼幼儿归家的就是她们。

**性情**　人少时说话发虚、眼神躲闪，聚上祭台却敢齐声高呼、声浪盖过江水；谢神磕头最起劲的是他们，提到献出去的娃就闭口摆手的也是他们（推断）。

**动机**　求一条活路。灾压下来，他们需要一个能交出去的东西——江神要娃，便把娃递出去；灾停了，便谢神，谁也不许再问娃去了哪儿。

**人物弧光**　静止的群像，只在第3集被掀开底牌：所谓江神索祭，是灾年扔娃的他们自己——从执祭的手，翻成真凶的脸。

**关系**

- 奶娃们 — 灾年被他们献入江中的婴孩，对外只说是江神索祭
- 徐今朝 — 转述有母亲整日在江边垂泪之事的修士，促成修士们送幼儿归家的决心

**原文依据**

> 我们来之前，看到有母亲整日在江边垂泪，盼幼儿归家。

### 形象

`ancient Chinese river village`, `male villager`, `coarse hemp tunic`, `indigo headwrap`, `joss incense`, `weathered sun-darkened skin`, `soft directional key light`, `neutral background`

**出图提示词 · 喂出图模型用这条**

```text
A lean, weathered ancient Chinese river-village laborer in his mid-fifties, sun-darkened coarse skin with visible pores, deep nasolabial folds and crow's feet, slightly asymmetrical eyelids and brows, grizzled stubble over hollow cheeks, sparse gray-streaked hair tucked under an indigo cotton headwrap knotted at the nape. He wears a hip-length short tunic of coarse hand-woven hemp with side slits over loose hemp trousers, lower legs bound with cloth strips, straw sandals. His left hand grips a bundle of joss incense sticks, fingertips stained dull yellow by years of incense ash. Three-quarter view, waist-up, plain neutral background. Soft directional key light from the left with natural falloff, cool fill from the right, shallow depth of field, focus sharpest on the face.
```

写实真人短剧质感：中国古代江边村落的一名饱经风霜的农人，清瘦男性，五十五岁上下，皮肤被日头晒得黝黑粗糙，法令纹与眼角鱼尾纹顺表情纹路深刻，眼睑与双眉略不对称，凹陷的脸颊上有花白胡茬，稀疏花白的头发拢进脑后打结的靛蓝布头巾里。上身穿及胯、侧开衩的粗麻短褐，下着宽松麻裤，小腿缠布条，脚踩草鞋；左手攥着一把线香，指腹被经年香灰浸染成暗黄。四分之三视角半身像，纯中性背景，左侧柔和方向主光配右侧冷调补光，浅景深，面部对焦最实。

**反向提示词**

```text
illustration, anime, cartoon outlines, 3d render, game-render aesthetics, plastic skin, over-smoothed poreless skin, young face, perfectly symmetrical face, dead eyes without catchlights, helmet hair, stiff mannequin pose, extra fingers, extra limbs, malformed hands, duplicate faces, watermark, text
```

**角色设定图提示词 EN**

```text
Weathered ancient Chinese river-village laborer, lean, mid-fifties, sun-darkened skin, deep nasolabial folds and crow's feet, slightly asymmetrical eyelids and brows, grizzled stubble, sparse gray-streaked hair under an indigo cotton headwrap, hip-length coarse hand-woven hemp short tunic with side slits over loose hemp trousers, cloth-bound lower legs, straw sandals, left hand gripping joss incense sticks, fingertips stained dull yellow by incense ash. ONE 16:9 landscape model-sheet canvas, pure white background, even margins, three zones split by thin hairline rules. LEFT ZONE, about 34% of canvas width: one bust portrait, head and shoulders, front-facing, ID-photo centered, the facial-design baseline rendered fully and finely, both shoulders complete, bottom edge cut flat and straight; LIGHTING HERE ONLY: soft directional key from upper left, natural falloff, ambient occlusion under chin, in eye sockets, at collar-neck junction. RIGHT-TOP ZONE: three FULL-BODY views of the same man — front, side, back — side by side on one shared ground line. RIGHT-BOTTOM ZONE: four to five small isolated close-up studies evenly spaced in a row, clearly smaller than the figures — indigo headwrap knot at the nape, hand-woven hemp weave and side-slit hem, cloth-bound lower legs and straw sandals, joss incense bundle, incense-ash-stained fingertips; size priority belongs to the full-body figures. PROPORTIONS ARE CRITICAL: three figures equal in height, identical head-to-body ratios, correct limb lengths, clear gaps above heads and below feet, one consistent scale. ONE face across the sheet: all views share the bust's exact facial features, hairstyle and expression. RIGHT ZONES: flat, even, directionless orthographic light.
```

### 声音

- **音色**：沙哑发闷的男中低音，喉音重，带常年江风吹出的粗粝沙砾感
- **音高**：中低
- **语速**：偏慢，字间夹着迟疑的小气口
- **口音**：江边村落的土腔，前后鼻音含混，尾音下沉发闷
- **情绪**：怯懦赔笑，底下压着一丝心虚
- **类比**：像一个常年在江边替全村回话的老农——话少声低，说到一半就往回收

**音色提示词 · 喂 TTS 引擎用这条**

```text
Male villager around fifty-five, rough husky mid-low voice, throaty chest resonance, narrow dynamic range. Low-to-mid volume, slow hesitant pace, flat falling phrase endings, slightly slurred articulation. Rural river-village regional accent, indistinct nasals, word tails sinking. Default mood: timid, obsequious, faintly guilty.
```

