# E01-02 · H3 提示词

首帧 = **f1.png**。图片按 Picture 序号挂载：

- Picture 1 = f1.png（**首帧**，钉 0.00 秒）

---

For the target video, at 0.00 seconds into the target video, <Picture 1> (from [Shot 1]) is fully referenced.

integrated_multimodal_description:
[Shot 1] Anchored to the composition of <Picture 1>: inside the sealed water-membrane dome, a Tracking Shot follows two young people in wedding clothes as they plunge head-down through the translucent membrane that curves over them like an upturned bowl, the dark green river pressing against its outer side in a band of drifting silt. Eight rune-carved stone pillars ring the boundary with their carved bands glowing faint blue-white, and a twelve-panel seal ring turns slowly at the highest point. The young swordsman throws his arms back as the membrane tears, water bursting outward in sheets on both sides while iridescent ripples race across the surface; his junior sister trails half an arm behind him, her red bridal dress whipping in the current. The two of them fall smaller and smaller into a deep blue glow, their red robes the only warm colour in the frame.

overall_soundscape:
A muffled underwater roar; the membrane tearing with a heavy thud; sheets of water bursting and bubbling; silt drifting past; a very distant bonfire rumble from far above the surface.

non_diegetic_music:
A slow low synth swell with a single bowed string line sinking downward in pitch.
