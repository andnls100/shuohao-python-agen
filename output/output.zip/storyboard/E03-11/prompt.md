# E03-11 · H3 提示词

首帧 = **f1.png**。图片按 Picture 序号挂载：

- Picture 1 = f1.png（**首帧**，钉 0.00 秒）
- Picture 2 = f2.png（钉 3.00 秒）
- Picture 3 = f3.png（钉 5.00 秒）
- Picture 4 = f4.png（钉 8.00 秒）

---

参考图与目标视频的对齐——图 1（来自镜头 1）对齐目标视频 0.00 秒处；图 2（来自镜头 2）对齐目标视频 3.00 秒处；图 3（来自镜头 3）对齐目标视频 5.00 秒处；图 4（来自镜头 4）对齐目标视频 8.00 秒处。

integrated_multimodal_description:
[Shot 1] Anchored to <Picture 1>: a static shot holds on the young woman as she draws her gaze back from the peach grove and turns toward the platform, breath thinning, fingers clenching her sleeve as she finally asks the question she has carried the whole way; (S1) the very young woman in the plain cross-collared jacket asks, quiet and unblinking: <d>[Chinese]那封印你的，究竟是谁？</d>
[Shot 2] At 00:03.000, the camera cuts to <Picture 2>: a fast zoom in as the fox's head whips around, neck fur bristling, golden eyes going razor-sharp, teeth bared; (S2) the snowy nine-tailed fox spirit snarls, the sentence chopped off mid-air: <d>[Chinese]你配问——</d>
[Shot 3] At 00:05.000, the camera cuts to <Picture 3>: a static shot holds as peach petals drop one after another through the light shaft, piling softly on the tip of the white tail hanging off the platform edge, thicker and thicker; the tail does not dodge and does not move, only rising and falling with a very quiet breath.
[Shot 4] At 00:08.000, the camera cuts to <Picture 4>: a slow pull out from the young woman as she gazes up at the flowering grove, lips parting and closing without a sound, petals sliding off her shoulder, her small silhouette dissolving into the vast pink bloom and drifting daylight.
Visual style for every shot: polished Chinese manhua short-drama animation, stylized 2D/2.5D illustration, coherent character design, expressive cinematic composition, clean intentional linework, illustrative shading and controlled color design — clearly illustrated, never a photograph or live-action footage.

overall_soundscape: Petals landing softly on fur; a sharp intake of breath; the hall hushed under drifting petals; water chiming faintly.

non_diegetic_music: A single guzheng note decaying into silence.
