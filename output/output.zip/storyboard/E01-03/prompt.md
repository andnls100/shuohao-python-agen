# E01-03 · H3 提示词

首帧 = **f1.png**。图片按 Picture 序号挂载：

- Picture 1 = f1.png（**首帧**，钉 0.00 秒）
- Picture 2 = f2.png（钉 4.00 秒）
- Picture 3 = f3.png（钉 8.00 秒）

---

How the reference pictures align with the target video — Picture 1 (from Shot 1) aligns with the 0.00-second mark of the target video; Picture 2 (from Shot 2) aligns with the 4.00-second mark of the target video; Picture 3 (from Shot 3) aligns with the 8.00-second mark of the target video.

integrated_multimodal_description:
[Shot 1] Anchored to the composition of <Picture 1>: a slow Push In from the two standing figures down to the floor of the underwater hall, where pearl lamps on white jade lotus stands pool warm ivory light between the columns and pink peach petals drift down and gather in the cracks of the blue stone. A group of well-fed toddlers in clean coarse village tunics crawls out from behind the peach grove and gathers in a half-circle at the feet of a young swordsman in a red wedding robe and his junior sister in a red bridal dress, both of them holding long swords; the smallest child is still wrapped in a swaddle. (S1) a three-year-old girl with a small topknot, lisping brightly and quickly, says <d>[Chinese] 娘亲！抱抱！</d> The young man draws his sword half a foot back and the young woman turns her body aside, neither of them moving their feet.
[Shot 2] At 00:04.000, the camera cuts to <Picture 2>: a Static Shot close on the pair from the knees down — a toddler grips the flower knot at the end of the white sword tassel with both hands and pulls it taut, the blade shifting against the scabbard, while another toddler clings to the young man's leg and climbs half a step higher. (S2) the junior sister in the red bridal dress, young, sharp and indignant, snaps <d>[Chinese] 别碰我的剑！</d> Her palm slams down on the scabbard and she bends forward to pull the tassel free.
[Shot 3] At 00:08.000, the camera cuts to <Picture 3>: a slow Push In on the north jade terrace, where a nine-tailed fox demon woman in a layered ivory-and-pink robe, fox ears above her hair and nine white tails fanned on the couch, pushes herself upright from the wide white jade couch; her tails gather and settle one after another, one ear twitches, her eyes sweep across the hall below and one corner of her mouth lifts. (S3) the nine-tailed fox demon woman on the couch, low, unhurried and faintly sneering, says <d>[Chinese] 吵死了。</d> She sets one hand on her knee and lets her ivory sleeve hang off the couch edge.

overall_soundscape:
Hollow hall reverb with a faint water shimmer overhead; the soft rustle of drifting petals; small hands and knees scuffing the stone and light chattering from the children; silk thread creaking as the sword tassel is pulled.

non_diegetic_music:
Sparse plucked low strings and light woodwind stabs, slow and slightly absurd.
