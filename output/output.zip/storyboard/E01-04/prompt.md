# E01-04 · H3 提示词

首帧 = **f1.png**。图片按 Picture 序号挂载：

- Picture 1 = f1.png（**首帧**，钉 0.00 秒）
- Picture 2 = f2.png（钉 4.00 秒）
- Picture 3 = f3.png（钉 10.00 秒）

---

How the reference pictures align with the target video — Picture 1 (from Shot 1) aligns with the 0.00-second mark of the target video; Picture 2 (from Shot 2) aligns with the 4.00-second mark of the target video; Picture 3 (from Shot 3) aligns with the 10.00-second mark of the target video.

integrated_multimodal_description:
[Shot 1] Anchored to the composition of <Picture 1>: a Static Shot close on the young swordsman in the red wedding robe standing on the blue stone floor, hair tied high with one loose strand against his cheek, jaw tight and eyes burning; the hall behind him is soft and out of focus, warm pearl light blooming between the columns and a few peach petals crossing the foreground. He steps half a pace forward, shoulders squared, and raises one arm to point at the jade terrace in the north. (S1) the young swordsman in the red wedding robe, clear and furious, forcing each word out, says <d>[Chinese] 妖女！你逼村民献祭幼崽，罪不可赦！</d> His hand tightens on the sword hilt at his side.
[Shot 2] At 00:04.000, the camera cuts to <Picture 2>: a Static Shot at medium range on the two of them side by side on the blue stone; the junior sister in the red bridal dress turns her head toward the terrace. (S2) the junior sister in the red bridal dress, young, shrill and accusing, says <d>[Chinese] 上百个孩子，都被你沉进江里了！</d> Then both of them lift their long swords from their sides and angle the blades toward the north, her white tassel still hanging crooked from being pulled, and they settle side by side with their shoulders squared.
[Shot 3] At 00:10.000, the camera cuts to <Picture 3>: a slow Push In on the fox demon woman seated upright on the edge of the wide white jade couch, fox ears twitching, nine white tails trailing across the couch, a faint sneer at the corner of her mouth. (S3) the nine-tailed fox demon woman, low and unhurried, with a cold smile, says <d>[Chinese] 你们说完了？</d> She lifts one hand and sweeps her right sleeve forward in a light arc that barely shows any effort; the next instant the two young people in wedding clothes drop back onto the blue stone, their long swords spinning out of their hands and clattering down beside them.

overall_soundscape:
Hollow hall reverb; wedding silk rustling with each step; two blades lifting clear of the stone; swords striking the blue stone and sliding half a foot; a faint water shimmer running across the dome overhead.

non_diegetic_music:
A sustained low string with slow rising tension that drops sharply on the fall.
