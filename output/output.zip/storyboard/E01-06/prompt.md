# E01-06 · H3 提示词

首帧 = **f1.png**。图片按 Picture 序号挂载：

- Picture 1 = f1.png（**首帧**，钉 0.00 秒）
- Picture 2 = f2.png（钉 4.60 秒）
- Picture 3 = f3.png（钉 10.20 秒）

---

How the reference pictures align with the target video — Picture 1 (from Shot 1) aligns with the 0.00-second mark of the target video; Picture 2 (from Shot 2) aligns with the 4.60-second mark of the target video; Picture 3 (from Shot 3) aligns with the 10.20-second mark of the target video.

integrated_multimodal_description:
[Shot 1] Anchored to the composition of <Picture 1>: a Static Shot wide on the blue stone floor of the underwater hall, warm pearl light glowing between the columns and rows of cradles receding into shadow behind. Toddlers pour in from both sides, wrap their arms around the young swordsman's legs and hang on his junior sister's arms, her long sword crowded against her side. (S1) a three-year-old girl with a small topknot, bright and demanding, calls out <d>[Chinese] 新来的，陪我们睡！</d> The two of them are dragged half a step apart and stumble back together, their swords rocking against their sides.
[Shot 2] At 00:04.600, the camera cuts to <Picture 2>: a slow Push In on the junior sister in the red bridal dress from the front as a toddler lifts her right arm in both hands and presses its face against her sleeve. (S2) the junior sister in the red bridal dress, young, shrill and exasperated, says <d>[Chinese] 我们是来除妖的，不是陪睡的！</d> The child rubs its face left and right along the red sleeve and leaves a glossy wet streak; she bends her head, pulls her sleeve back and pries the small fingers open while her shoulder shrinks back half an inch.
[Shot 3] At 00:10.200, the camera cuts to <Picture 3>: a Static Shot at medium range on the junior sister in the red bridal dress glaring down at a toddler at her feet, a wet streak still on her cuff; the young swordsman stands blurred to her left, still held around the legs by other children. (S2) the junior sister in the red bridal dress, sharp and flustered, cries <d>[Chinese] 呀！你走开！</d> She jerks her arm up to free the cuff, leans back and shifts half a step backwards on the stone, then another toddler clamps onto her calf and she freezes in place, turning her head to glare down.

overall_soundscape:
Toddlers chattering and slapping the stone floor in waves; wedding silk dragged and twisted; a small wet sound as a face is rubbed against the sleeve; hollow hall reverb with a faint water whisper overhead.

non_diegetic_music:
Light woodwind stabs and plucked strings, bouncy and comic.
