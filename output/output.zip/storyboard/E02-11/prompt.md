# E02-11 · H3 提示词

首帧 = **f1.png**。图片按 Picture 序号挂载：

- Picture 1 = f1.png（**首帧**，钉 0.00 秒）
- Picture 2 = f2.png（钉 2.50 秒）
- Picture 3 = f3.png（钉 6.60 秒）

---

参考图与目标视频的对齐——图 1（来自镜头 1）对齐目标视频 0.00 秒处；图 2（来自镜头 2）对齐目标视频 2.50 秒处；图 3（来自镜头 3）对齐目标视频 6.60 秒处。

integrated_multimodal_description:
[Shot 1] With <Picture 1> anchoring the composition and character states, a Static Shot medium holds as the young man shakes out his numb arms, steps over and crouches down beside the young woman at the threshold; the two of them stare side by side at the golden filaments glowing on the stone sill.
[Shot 2] At 00:02.500, the camera cuts to <Picture 2>: a slow Push In toward the man's hand as he reaches for the golden filaments and freezes mid-air an inch away; a cold female voice says in an off-screen voiceover from behind the two while its lips remain completely closed: <d>[Chinese] 别碰。</d> — the young woman turns to look and presses in a small, puzzled voice: <d>[Chinese] 为什么？</d>
[Shot 3] At 00:06.600, the camera cuts to <Picture 3>: a low-angle Tilt Up from the white fox's lifted head as it strides to the threshold, lays one snow-white tail straight across the sill like a bar, and raises its eyes to the inverted dome of river water overhead, green currents rippling with light across its curved underside.

overall_soundscape: Joints pop faintly as numb arms are shaken out; a tiny gasp when the hand stops mid-air; soft paw-steps cross the stone floor; a deep water-groan rolls overhead as the dome's current shifts.

non_diegetic_music: A low sustained cello drone with a cold shimmer, ending on an unresolved suspended chord.
