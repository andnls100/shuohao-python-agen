# E02-10 · H3 提示词

首帧 = **f1.png**。图片按 Picture 序号挂载：

- Picture 1 = f1.png（**首帧**，钉 0.00 秒）
- Picture 2 = f2.png（钉 2.50 秒）
- Picture 3 = f3.png（钉 5.00 秒）

---

参考图与目标视频的对齐——图 1（来自镜头 1）对齐目标视频 0.00 秒处；图 2（来自镜头 2）对齐目标视频 2.50 秒处；图 3（来自镜头 3）对齐目标视频 5.00 秒处。

integrated_multimodal_description:
[Shot 1] With <Picture 1> anchoring the composition and character states, a Tracking Shot follows the white fox's tail-tip as it curls the last sleeping baby off the young man's neck, carries the baby gently across and lowers it into a small wooden bed; the baby's fingers cling to the tail fur until the tail gives one soft shake and tips it into the quilt.
[Shot 2] At 00:02.500, the camera cuts to <Picture 2>: a Tracking Shot follows the sleepless young woman as she edges alone to the doorway threshold and crouches down, leaning in to stare at the densest cluster of golden seal filaments incised along the stone sill.
[Shot 3] At 00:05.000, the camera cuts to <Picture 3>: a slow Push In toward the golden filaments as the young woman crouched at the threshold speaks in a lowered, thinking-out-loud voice, her eyes sliding along the pattern: <d>[Chinese] 师兄，金纹到边界这儿最密，像锁芯……</d>

overall_soundscape: Two small snores fade behind; footsteps pad softly on stone; the golden filaments give off a faint crystalline shimmer; night water laps somewhere beyond the threshold.

non_diegetic_music: Quiet muted strings with one ticking pulse like a lock mechanism, sparse and low.
