# E01-01 · H3 提示词

首帧 = **f1.png**。图片按 Picture 序号挂载：

- Picture 1 = f1.png（**首帧**，钉 0.00 秒）

---

For the target video, at 0.00 seconds into the target video, <Picture 1> (from [Shot 1]) is fully referenced.

integrated_multimodal_description:
[Shot 1] Anchored to the composition of <Picture 1>: a Static Shot holds on the riverside stone altar at night, a towering orange bonfire flaring behind the platform, sparks drifting up through the smoke, the dark river lying flat beyond. A gaunt, sun-darkened villager in a coarse hemp tunic and an indigo headwrap, together with two other villagers, pushes a young swordsman in a red wedding robe forward onto the wet stone ramp; the young man staggers half a step toward the black water, steadies his weight and glances back over his shoulder, while his junior sister in a red bridal dress grips her skirt and leans forward with him. The four parallel rope grooves worn into the altar stone are visible under their feet.

overall_soundscape:
A roaring bonfire with cracking wood and hissing sparks; straw sandals scraping on wet stone and coarse cloth shifting as the pair are shoved forward; night wind moving over the dark river; quick, strained breathing from the two captives.

non_diegetic_music:
A low sustained string drone with sparse deep drum hits, slow and ominous.
