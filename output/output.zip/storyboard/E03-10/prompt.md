# E03-10 · H3 提示词

首帧 = **f1.png**。图片按 Picture 序号挂载：

- Picture 1 = f1.png（**首帧**，钉 0.00 秒）

---

For the target video, at 0.00 seconds into the target video, <Picture 1> (from [Shot 1]) is fully referenced.

integrated_multimodal_description:
[Shot 1] At 00:00.000, extreme close-up of peach tree roots on the stone floor. Fine cracks appear with a tearing sound as Xu Jinzhao's feet step near the roots.

overall_soundscape: Fine tearing sound, stone friction.

non_diegetic_music: N/A
