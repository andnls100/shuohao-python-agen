# E01-05 · H3 提示词

首帧 = **f1.png**。图片按 Picture 序号挂载：

- Picture 1 = f1.png（**首帧**，钉 0.00 秒）
- Picture 2 = f2.png（钉 4.00 秒）
- Picture 3 = f3.png（钉 9.40 秒）

---

How the reference pictures align with the target video — Picture 1 (from Shot 1) aligns with the 0.00-second mark of the target video; Picture 2 (from Shot 2) aligns with the 4.00-second mark of the target video; Picture 3 (from Shot 3) aligns with the 9.40-second mark of the target video.

integrated_multimodal_description:
[Shot 1] Anchored to the composition of <Picture 1>: a Static Shot looking down at the blue stone floor where the two of them sit among scattered peach petals, their long swords lying an arm's length away. (S1) the young swordsman in the red wedding robe, panting but defiant, says <d>[Chinese] 我燕溪山绝不求饶！</d> Beside him his junior sister in the red bridal dress pushes her upper body up on one hand. (S2) the junior sister in the red bridal dress, breathless and stubborn, says <d>[Chinese] 我才不怕死！</d> Both of them press off the stone and lift their heads toward the jade terrace in the north.
[Shot 2] At 00:04.000, the camera cuts to <Picture 2>: a Static Shot close on the junior sister sitting on the blue stone, one palm pressed to the floor with the knuckles flattened and one knee lifted as she tries to stand; her teeth are set in her lower lip and her hair sticks to her cheek, while the young swordsman blurs behind her shoulder. Her knee slips and she drops back down heavily onto the floor, her bridal skirt caught under her knee; the young swordsman just behind her pushes his upper body upright and turns his shoulder toward her side. (S1) the young swordsman in the red wedding robe, breath driven short, says <d>[Chinese] 要杀就杀我，放过我师妹！</d>
[Shot 3] At 00:09.400, the camera cuts to <Picture 3>: a Pull Out as the young swordsman scrambles up, staggers half a step, plants his feet apart and blocks his seated junior sister with his body, one hand raised back to shield her; the Pull Out widens until the fox demon woman reclining on the white jade couch appears in the upper right distance, looking down at them while the tip of one white tail sweeps across the couch. (S3) the nine-tailed fox demon woman, amused and dismissive, says <d>[Chinese] 这么弱，还敢这么狂？</d>

overall_soundscape:
Silk and coarse cloth dragging over blue stone; a palm slapping down onto the floor; the light scrape of a scabbard shifting on the ground; hollow hall reverb and a faint water whisper overhead.

non_diegetic_music:
Broken low strings with one slow drum hit as the young man rises to his feet.
