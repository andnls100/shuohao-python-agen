# E01-10 · H3 提示词

首帧 = **f1.png**。图片按 Picture 序号挂载：

- Picture 1 = f1.png（**首帧**，钉 0.00 秒）
- Picture 2 = f2.png（钉 4.00 秒）
- Picture 3 = f3.png（钉 8.00 秒）

---

How the reference pictures align with the target video — Picture 1 (from Shot 1) aligns with the 0.00-second mark of the target video; Picture 2 (from Shot 2) aligns with the 4.00-second mark of the target video; Picture 3 (from Shot 3) aligns with the 8.00-second mark of the target video.

integrated_multimodal_description:
[Shot 1] Anchored to the composition of <Picture 1>: a Static Shot close on the nine-tailed fox demon woman on the white jade couch with a toddler in her arms, fox ears up and the collar of her ivory-and-pink robe crumpled in the child's fist. (S1) a three-year-old girl with a small topknot, small and plaintive, whines <d>[Chinese] 娘亲，饿。</d> The child's mouth opens and closes as it looks up at her and it pulls at her collar; the fox demon woman glances down. (S2) the nine-tailed fox demon woman, casual and ordering, says <d>[Chinese] 新来的，去把米糊端来。</d> She tilts her chin toward the side of the hall and points, her other arm still holding the child steady.
[Shot 2] At 00:04.000, the camera cuts to <Picture 2>: a Static Shot at medium range, the junior sister in the red bridal dress angled low in the foreground half turned away from the camera with her face up toward the north terrace, while the fox demon woman sits above on the couch with the toddler still in her arms. (S3) the junior sister in the red bridal dress, sharp and challenging, asks <d>[Chinese] 我们凭什么听你的？</d> Her fist closes at her side. (S2) the nine-tailed fox demon woman, flat and confident, answers <d>[Chinese] 凭你们打不过我。</d> She rocks the child, the tip of one white tail sweeping the couch edge.
[Shot 3] At 00:08.000, the camera cuts to <Picture 3>: a slow Push In on the junior sister's right hand held at her side, her red cuff gathered at the wrist, the fingers clenched white; she stares down at her hand, holds it a moment, then lets the fingers open and drop loose. (S4) behind her shoulder the young swordsman in the red wedding robe, the toddler still in his arms, low and reasoning, says <d>[Chinese] 师妹，先救孩子，再问罪。</d>

overall_soundscape:
A toddler's thin fretful sounds and smacking lips; crumpled silk at the collar; a foot pressing and turning on the blue stone; hollow hall reverb with a faint water whisper.

non_diegetic_music:
Clarinet phrases alternating with low strings, slow and restrained.
