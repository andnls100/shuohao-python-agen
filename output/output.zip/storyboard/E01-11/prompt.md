# E01-11 · H3 提示词

首帧 = **f1.png**。图片按 Picture 序号挂载：

- Picture 1 = f1.png（**首帧**，钉 0.00 秒）
- Picture 2 = f2.png（钉 4.20 秒）
- Picture 3 = f3.png（钉 8.40 秒）

---

How the reference pictures align with the target video — Picture 1 (from Shot 1) aligns with the 0.00-second mark of the target video; Picture 2 (from Shot 2) aligns with the 4.20-second mark of the target video; Picture 3 (from Shot 3) aligns with the 8.40-second mark of the target video.

integrated_multimodal_description:
[Shot 1] Anchored to the composition of <Picture 1>: a Static Shot close on the young swordsman in the red wedding robe looking down at the toddler in his arms; the child looks up at him with both small hands knotted in the front of his robe, pulling the red fabric into a fistful of creases, tiredness clear on his face and one loose strand of hair on his forehead. (S1) the toddler in his arms, small and anxious, says <d>[Chinese] 哥哥，不扔我。</d> The child pulls the lapel higher and he lowers his head, his throat moving, his arms slowly tightening.
[Shot 2] At 00:04.200, the camera cuts to <Picture 2>: a slow Push In as the young swordsman folds the toddler fully against his chest, its small face pressed into the hollow of his shoulder and its legs hanging past his forearm, his jaw resting on the top of the child's head. (S2) the young swordsman in the red wedding robe, low and steady, says <d>[Chinese] 谁也不会扔你。</d> His shoulders rise and fall, he pauses with his jaw against the child's hair, and the child frees one hand and pats his collarbone.
[Shot 3] At 00:08.400, the camera cuts to <Picture 3>: a Tilt Up as the young swordsman turns his head and follows his gaze up across the hall — past the rows of cradles it climbs to the nine-tailed fox demon woman sitting on the white jade couch, her chin lifted toward the ceiling, fox ears standing straight, nine white tails hanging dead still off the couch edge. The whole underside of the river hangs overhead, dark green water turning slowly with light patterns crawling across it. She does not move or blink as she stares up at it.

overall_soundscape:
The toddler's light sniffling and cloth brushing; silk tightening as the child is pressed close; hollow hall reverb with the low rush of moving water and faint bubbles overhead.

non_diegetic_music:
A long low string rising very slowly.
