# novel · 分镜（第 1 集）

## E01

> 12 段 29 切 · 共 132 秒 / 目标 120 秒

### E01-01 · 江边祭坛（夜·火光冲天） · 4 秒 · 1 个分镜

> 走位：江边祭坛朝江一侧：入水滑道口正中，燕溪山在左、徐今朝在右并肩站立，两人同穿婚服、面朝漆黑江面、背对祭台火塘；江边村民围在两人身后呈半圆，最近的一名清瘦农人在燕溪山左后一步、双手抵在他后背，其余村民距两人约两步。

| 切 | 起点 | 秒 | 景别 | 运镜 | 配方 | 画面 | 人物 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| #1 | 0.00s | 4 | 全景 | Static Shot（固定） | — | 火光冲天，村民把穿婚服的燕溪山和徐今朝推上入水滑道。 | 江边村民、燕溪山、徐今朝 |

**H3 视频提示词**

```text
For the target video, at 0.00 seconds into the target video, <Picture 1> (from [Shot 1]) is fully referenced.

integrated_multimodal_description:
[Shot 1] Anchored to the composition of <Picture 1>: a Static Shot holds on the riverside stone altar at night, a towering orange bonfire flaring behind the platform, sparks drifting up through the smoke, the dark river lying flat beyond. A gaunt, sun-darkened villager in a coarse hemp tunic and an indigo headwrap, together with two other villagers, pushes a young swordsman in a red wedding robe forward onto the wet stone ramp; the young man staggers half a step toward the black water, steadies his weight and glances back over his shoulder, while his junior sister in a red bridal dress grips her skirt and leans forward with him. The four parallel rope grooves worn into the altar stone are visible under their feet.

overall_soundscape:
A roaring bonfire with cracking wood and hissing sparks; straw sandals scraping on wet stone and coarse cloth shifting as the pair are shoved forward; night wind moving over the dark river; quick, strained breathing from the two captives.

non_diegetic_music:
A low sustained string drone with sparse deep drum hits, slow and ominous.
```

**Seedance 视频提示词**

```text
@[图片1] = 江边祭坛
@[图片2] = 江边村民
@[图片3] = 燕溪山
@[图片4] = 徐今朝

【人物关系与构图逻辑】
江边祭坛朝江一侧：入水滑道口正中，燕溪山在左、徐今朝在右并肩站立，两人同穿婚服、面朝漆黑江面、背对祭台火塘；江边村民围在两人身后呈半圆，最近的一名清瘦农人在燕溪山左后一步、双手抵在他后背，其余村民距两人约两步。

【镜头1】
焦距：35mm 广角，中深景深
机位：燕溪山与徐今朝 + 平视略仰 15°
构图：三分法
运镜：固定镜头
景别：全景
画面：固定机位，火光在画面上方翻卷；一名清瘦农夫与两名村民从背后把穿婚服的少年男女推向滑道口，少年向前踉跄半步、踩上被磨亮的湿石面又稳住重心，回头看了一眼；红嫁衣的女子攥紧裙摆随之前倾，两人手中的长剑被村民的手臂挤在身侧。
台词：{}
视线落点：燕溪山看向漆黑的江面
焦点：锁定两名婚服修士的上半身与推在燕溪山背上的手掌
稳定性：微晃

<熊熊烈火的爆燃声与木柴炸裂声持续不断；草鞋在湿石面上打滑摩擦、粗麻衣料被推搡的窸窣声；夜风掠过江面的低鸣；被推的两人呼吸急促、胸口起伏声。>
（低音弦乐持续音铺底，配稀疏的深鼓点，速度缓慢压抑。）

【约束】
1. 保持无字幕，避免生成任何文字或字幕
2. 视频全程禁止出现外形、着装、配饰完全一致的人物
```

### E01-02 · 封印边界·水幕结界（沉夜·远火） · 4 秒 · 1 个分镜

> 走位：水幕结界穹顶内侧：燕溪山在画面上方偏左、徐今朝在他斜右下半个身位，两人头朝下、身体呈对角线一起下坠，双臂被水流带得后扬；身后是倒扣水碗般的水膜与环立的八根缠符石柱，下方是幽蓝光，两人相距约半臂。

| 切 | 起点 | 秒 | 景别 | 运镜 | 配方 | 画面 | 人物 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| #1 | 0.00s | 4 | 大远景 | Tracking Shot（跟拍） | — | 两人坠穿水幕，落入一片幽蓝光里。 | 燕溪山、徐今朝 |

**H3 视频提示词**

```text
For the target video, at 0.00 seconds into the target video, <Picture 1> (from [Shot 1]) is fully referenced.

integrated_multimodal_description:
[Shot 1] Anchored to the composition of <Picture 1>: inside the sealed water-membrane dome, a Tracking Shot follows two young people in wedding clothes as they plunge head-down through the translucent membrane that curves over them like an upturned bowl, the dark green river pressing against its outer side in a band of drifting silt. Eight rune-carved stone pillars ring the boundary with their carved bands glowing faint blue-white, and a twelve-panel seal ring turns slowly at the highest point. The young swordsman throws his arms back as the membrane tears, water bursting outward in sheets on both sides while iridescent ripples race across the surface; his junior sister trails half an arm behind him, her red bridal dress whipping in the current. The two of them fall smaller and smaller into a deep blue glow, their red robes the only warm colour in the frame.

overall_soundscape:
A muffled underwater roar; the membrane tearing with a heavy thud; sheets of water bursting and bubbling; silt drifting past; a very distant bonfire rumble from far above the surface.

non_diegetic_music:
A slow low synth swell with a single bowed string line sinking downward in pitch.
```

**Seedance 视频提示词**

```text
@[图片1] = 封印边界·水幕结界
@[图片2] = 燕溪山
@[图片3] = 徐今朝

【人物关系与构图逻辑】
水幕结界穹顶内侧：燕溪山在画面上方偏左、徐今朝在他斜右下半个身位，两人头朝下、身体呈对角线一起下坠，双臂被水流带得后扬；身后是倒扣水碗般的水膜与环立的八根缠符石柱，下方是幽蓝光，两人相距约半臂。

【镜头1】
焦距：28mm 广角，深景深
机位：燕溪山与徐今朝 + 俯视 45°
构图：对角线
运镜：跟拍
景别：大远景
画面：跟拍镜头随两人向下坠：水膜被撞破的瞬间大片水花从两侧炸开、虹彩膜面向外荡开涟漪，少年的手臂被水流掀得向后、指尖划过水面，红嫁衣的女子在他斜后半臂处紧随；两人在幽蓝光里越坠越小，赤色衣袍在深蓝水色中成为唯一暖色，缠符石柱的青白符文光在画面上缘拉成竖线。
台词：{}
视线落点：两人看向下方幽蓝光深处
焦点：锁定两名坠落的婚服身影与破开的水膜
稳定性：微晃

<水下低沉的轰响，水膜被撞破的一声闷响；大片水花向两侧炸开、气泡翻涌；泥沙絮状物漂过；极远处传来闷闷的祭火声。>
（低音合成器缓慢下沉，单声部弓弦旋律随之下行。）

【约束】
1. 保持无字幕，避免生成任何文字或字幕
2. 视频全程禁止出现外形、着装、配饰完全一致的人物
```

### E01-03 · 江底封印·仙府与桃林（珠光常明） · 12 秒 · 3 个分镜

> 走位：大殿中轴偏东：燕溪山在左、徐今朝在右并肩站立，两人同穿婚服、各持长剑，面朝东侧桃林；奶娃们从桃林后爬出，在两人脚前半圆围立、最近不足一步；正北三层白玉高台距两人约十步，九尾狐妖坐在台沿榻上，台面高于两人胸口。

| 切 | 起点 | 秒 | 景别 | 运镜 | 配方 | 画面 | 人物 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| #1 | 0.00s | 4 | 全景 | Push In（推） | — | 一群奶娃从桃林后爬出来，围住两个穿婚服的修士。 奶娃们：「娘亲！抱抱！」 | 燕溪山、徐今朝、奶娃们 |
| #2 | 4.00s | 4 | 特写 | Static Shot（固定） | — | 奶娃抱住燕溪山的腿，抓住徐今朝的剑穗。 徐今朝：「别碰我的剑！」 | 燕溪山、徐今朝、奶娃们 |
| #3 | 8.00s | 4 | 中景 | Push In（推） | — | 九尾狐妖：「吵死了。」 狐妖从白玉榻上坐起。 | 九尾狐妖 |

**H3 视频提示词**

```text
How the reference pictures align with the target video — Picture 1 (from Shot 1) aligns with the 0.00-second mark of the target video; Picture 2 (from Shot 2) aligns with the 4.00-second mark of the target video; Picture 3 (from Shot 3) aligns with the 8.00-second mark of the target video.

integrated_multimodal_description:
[Shot 1] Anchored to the composition of <Picture 1>: a slow Push In from the two standing figures down to the floor of the underwater hall, where pearl lamps on white jade lotus stands pool warm ivory light between the columns and pink peach petals drift down and gather in the cracks of the blue stone. A group of well-fed toddlers in clean coarse village tunics crawls out from behind the peach grove and gathers in a half-circle at the feet of a young swordsman in a red wedding robe and his junior sister in a red bridal dress, both of them holding long swords; the smallest child is still wrapped in a swaddle. (S1) a three-year-old girl with a small topknot, lisping brightly and quickly, says <d>[Chinese] 娘亲！抱抱！</d> The young man draws his sword half a foot back and the young woman turns her body aside, neither of them moving their feet.
[Shot 2] At 00:04.000, the camera cuts to <Picture 2>: a Static Shot close on the pair from the knees down — a toddler grips the flower knot at the end of the white sword tassel with both hands and pulls it taut, the blade shifting against the scabbard, while another toddler clings to the young man's leg and climbs half a step higher. (S2) the junior sister in the red bridal dress, young, sharp and indignant, snaps <d>[Chinese] 别碰我的剑！</d> Her palm slams down on the scabbard and she bends forward to pull the tassel free.
[Shot 3] At 00:08.000, the camera cuts to <Picture 3>: a slow Push In on the north jade terrace, where a nine-tailed fox demon woman in a layered ivory-and-pink robe, fox ears above her hair and nine white tails fanned on the couch, pushes herself upright from the wide white jade couch; her tails gather and settle one after another, one ear twitches, her eyes sweep across the hall below and one corner of her mouth lifts. (S3) the nine-tailed fox demon woman on the couch, low, unhurried and faintly sneering, says <d>[Chinese] 吵死了。</d> She sets one hand on her knee and lets her ivory sleeve hang off the couch edge.

overall_soundscape:
Hollow hall reverb with a faint water shimmer overhead; the soft rustle of drifting petals; small hands and knees scuffing the stone and light chattering from the children; silk thread creaking as the sword tassel is pulled.

non_diegetic_music:
Sparse plucked low strings and light woodwind stabs, slow and slightly absurd.
```

**Seedance 视频提示词**

```text
@[图片1] = 江底封印·仙府与桃林
@[图片2] = 燕溪山
@[图片3] = 徐今朝
@[图片4] = 奶娃们
@[图片5] = 九尾狐妖

【人物关系与构图逻辑】
大殿中轴偏东：燕溪山在左、徐今朝在右并肩站立，两人同穿婚服、各持长剑，面朝东侧桃林；奶娃们从桃林后爬出，在两人脚前半圆围立、最近不足一步；正北三层白玉高台距两人约十步，九尾狐妖坐在台沿榻上，台面高于两人胸口。

【镜头1】
焦距：28mm 广角，深景深
机位：燕溪山与徐今朝 + 平视正面略低
构图：三分法
运镜：推镜
景别：全景
画面：镜头小幅缓推，从两人的全身推向他们脚边；一群幼儿从桃林后手脚并用地爬出来，围到两人脚前仰头张望、伸手去够衣摆；穿婚服的少年下意识把剑往后撤了半尺，身旁的红嫁衣女子也侧了侧身，两人都还站着没动。
台词：{娘亲！抱抱！}
视线落点：燕溪山与徐今朝低头看向脚边的奶娃
焦点：锁定两人与围在脚边的奶娃
稳定性：稳定

【镜头2】
焦距：50mm 标准，浅景深
机位：徐今朝 + 平视正面近前
构图：中心构图
运镜：固定镜头
景别：特写
画面：镜头固定：幼儿的两只小手攥住剑穗花结往怀里拽，白色穗线被拉成一条直线，红嫁衣的女子手掌立刻按在剑鞘上、微微俯身想抽回；抱腿的那个奶娃顺势往上爬了半步，把圆脸贴在少年膝上，少年的手臂往后撤了半寸又停住。
台词：{别碰我的剑！}
视线落点：徐今朝低头盯着攥住剑穗的小手
焦点：锁定被攥直的白色剑穗与幼儿的小手
稳定性：微晃

【镜头3】
焦距：50mm 标准，中浅景深
机位：九尾狐妖 + 平视略仰
构图：中心构图
运镜：推镜
景别：中景
画面：镜头小幅缓推：狐妖撑住榻沿坐起身，九条白尾在身后依次收拢、尾尖轻扫过榻面，狐耳微动；她抬眼看了一圈台下，唇角提起，一只手随意搭在膝上，象牙白袖口垂在榻沿外。
台词：{吵死了。}
视线落点：九尾狐妖扫视台下殿中
焦点：锁定九尾狐妖上半身、狐耳与收拢的白尾
稳定性：稳定

<空旷殿内的回声与珠光下的细小水波声；桃瓣落地的极轻簌响；幼儿手脚爬行的衣料摩擦与此起彼伏的咿呀声；剑穗被拽动的丝线绷紧声。>
（木管短音符轻快点缀，配零星拨弦，节奏舒缓，略带荒诞感。）

【约束】
1. 保持无字幕，避免生成任何文字或字幕
2. 视频全程禁止出现外形、着装、配饰完全一致的人物
```

### E01-04 · 江底封印·仙府与桃林（珠光常明） · 14 秒 · 3 个分镜

> 走位：大殿中轴：燕溪山与徐今朝并肩站在青石地中央偏南，徐今朝在左、燕溪山在右，两人面朝正北，距白玉高台约十步；九尾狐妖坐在高台榻沿、居高面向两人；摔落后两人仍停在原处地面上，长剑各落在身侧一臂内。

| 切 | 起点 | 秒 | 景别 | 运镜 | 配方 | 画面 | 人物 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| #1 | 0.00s | 4 | 特写 | Static Shot（固定） | — | 燕溪山：「妖女！你逼村民献祭幼崽，罪不可赦！」 | 燕溪山 |
| #2 | 4.00s | 6 | 中景 | Static Shot（固定） | — | 徐今朝：「上百个孩子，都被你沉进江里了！」 两人举起长剑，指向狐妖。 | 燕溪山、徐今朝、九尾狐妖 |
| #3 | 10.00s | 4 | 中景 | Push In（推） | — | 九尾狐妖：「你们说完了？」 狐妖随手一挥，两人摔倒，长剑落地。 | 九尾狐妖、燕溪山、徐今朝 |

**H3 视频提示词**

```text
How the reference pictures align with the target video — Picture 1 (from Shot 1) aligns with the 0.00-second mark of the target video; Picture 2 (from Shot 2) aligns with the 4.00-second mark of the target video; Picture 3 (from Shot 3) aligns with the 10.00-second mark of the target video.

integrated_multimodal_description:
[Shot 1] Anchored to the composition of <Picture 1>: a Static Shot close on the young swordsman in the red wedding robe standing on the blue stone floor, hair tied high with one loose strand against his cheek, jaw tight and eyes burning; the hall behind him is soft and out of focus, warm pearl light blooming between the columns and a few peach petals crossing the foreground. He steps half a pace forward, shoulders squared, and raises one arm to point at the jade terrace in the north. (S1) the young swordsman in the red wedding robe, clear and furious, forcing each word out, says <d>[Chinese] 妖女！你逼村民献祭幼崽，罪不可赦！</d> His hand tightens on the sword hilt at his side.
[Shot 2] At 00:04.000, the camera cuts to <Picture 2>: a Static Shot at medium range on the two of them side by side on the blue stone; the junior sister in the red bridal dress turns her head toward the terrace. (S2) the junior sister in the red bridal dress, young, shrill and accusing, says <d>[Chinese] 上百个孩子，都被你沉进江里了！</d> Then both of them lift their long swords from their sides and angle the blades toward the north, her white tassel still hanging crooked from being pulled, and they settle side by side with their shoulders squared.
[Shot 3] At 00:10.000, the camera cuts to <Picture 3>: a slow Push In on the fox demon woman seated upright on the edge of the wide white jade couch, fox ears twitching, nine white tails trailing across the couch, a faint sneer at the corner of her mouth. (S3) the nine-tailed fox demon woman, low and unhurried, with a cold smile, says <d>[Chinese] 你们说完了？</d> She lifts one hand and sweeps her right sleeve forward in a light arc that barely shows any effort; the next instant the two young people in wedding clothes drop back onto the blue stone, their long swords spinning out of their hands and clattering down beside them.

overall_soundscape:
Hollow hall reverb; wedding silk rustling with each step; two blades lifting clear of the stone; swords striking the blue stone and sliding half a foot; a faint water shimmer running across the dome overhead.

non_diegetic_music:
A sustained low string with slow rising tension that drops sharply on the fall.
```

**Seedance 视频提示词**

```text
@[图片1] = 江底封印·仙府与桃林
@[图片2] = 燕溪山
@[图片3] = 徐今朝
@[图片4] = 九尾狐妖

【人物关系与构图逻辑】
大殿中轴：燕溪山与徐今朝并肩站在青石地中央偏南，徐今朝在左、燕溪山在右，两人面朝正北，距白玉高台约十步；九尾狐妖坐在高台榻沿、居高面向两人；摔落后两人仍停在原处地面上，长剑各落在身侧一臂内。

【镜头1】
焦距：85mm 长焦，极浅景深
机位：燕溪山 + 平视正面
构图：三分法
运镜：固定镜头
景别：特写
画面：镜头固定：少年上前半步、肩背绷直，抬手指向正北高台方向，说完最后几个字时下颌一紧、胸口起伏；持剑的手垂在身侧、握紧剑柄，剑尖点着青石地面。
台词：{妖女！你逼村民献祭幼崽，罪不可赦！}
视线落点：燕溪山看向白玉榻上的九尾狐妖
焦点：锁定燕溪山的面部与绷紧的下颌
稳定性：稳定

【镜头2】
焦距：35mm 广角，中深景深
机位：徐今朝与燕溪山 + 平视正面（含右上高台）
构图：对称
运镜：固定镜头
景别：中景
画面：镜头固定：红嫁衣的女子先转头朝台上开口，她右侧的少年随之上前半步；两人同时把长剑从身侧举起、剑尖斜指向正北高台，衣摆随动作一沉，随后并肩稳住、肩膀绷紧，脚边的奶娃被震退半步又聚回来。
台词：{上百个孩子，都被你沉进江里了！}
视线落点：两人看向白玉高台上的九尾狐妖
焦点：锁定两把举起的长剑与两人上半身
稳定性：稳定

【镜头3】
焦距：50mm 标准，中浅景深
机位：九尾狐妖 + 平视略仰
构图：三分法
运镜：推镜
景别：中景
画面：镜头小幅缓推：狐妖坐在榻沿抬手，先看了一眼台下举剑的两人，右袖随手向前挥出一道几乎不见用力的弧线；下一瞬，两名穿婚服的修士向后摔坐在青石地上，长剑脱手飞出、落在各自身侧并磕出一声脆响，狐妖的袖口落回膝上。
台词：{你们说完了？}
视线落点：九尾狐妖看向台下举剑的两人
焦点：锁定九尾狐妖的上半身与挥袖的手
稳定性：稳定

<空旷殿内的回声；婚服衣料摩擦与脚步落地的钝响；长剑离地举起时的轻响；长剑脱手砸在青石上的脆响并滑出半尺；殿顶水波的细微流动。>
（低音弦乐拉长、速度缓慢，张力渐升后随摔落的一击骤然下落。）

【约束】
1. 保持无字幕，避免生成任何文字或字幕
2. 视频全程禁止出现外形、着装、配饰完全一致的人物
```

### E01-05 · 江底封印·仙府与桃林（珠光常明） · 14.4 秒 · 3 个分镜

> 走位：大殿青石地中央偏南：燕溪山与徐今朝摔坐在地，徐今朝在左后、燕溪山在右前，两人相距约半步，均面朝正北白玉高台；两把长剑分别落在各自身侧一臂远；九尾狐妖在台上榻沿居高俯视，两处相距约十步。

| 切 | 起点 | 秒 | 景别 | 运镜 | 配方 | 画面 | 人物 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| #1 | 0.00s | 4 | 中景 | Static Shot（固定） | — | 燕溪山：「我燕溪山绝不求饶！」 徐今朝：「我才不怕死！」 | 燕溪山、徐今朝 |
| #2 | 4.00s | 5.4 | 特写 | Static Shot（固定） | — | 徐今朝撑地想站起，又跌坐回去。 燕溪山：「要杀就杀我，放过我师妹！」 | 燕溪山、徐今朝 |
| #3 | 9.40s | 5 | 全景 | Pull Out（拉） | — | 燕溪山爬起来，挡在徐今朝身前。 九尾狐妖：「这么弱，还敢这么狂？」 | 燕溪山、徐今朝、九尾狐妖 |

**H3 视频提示词**

```text
How the reference pictures align with the target video — Picture 1 (from Shot 1) aligns with the 0.00-second mark of the target video; Picture 2 (from Shot 2) aligns with the 4.00-second mark of the target video; Picture 3 (from Shot 3) aligns with the 9.40-second mark of the target video.

integrated_multimodal_description:
[Shot 1] Anchored to the composition of <Picture 1>: a Static Shot looking down at the blue stone floor where the two of them sit among scattered peach petals, their long swords lying an arm's length away. (S1) the young swordsman in the red wedding robe, panting but defiant, says <d>[Chinese] 我燕溪山绝不求饶！</d> Beside him his junior sister in the red bridal dress pushes her upper body up on one hand. (S2) the junior sister in the red bridal dress, breathless and stubborn, says <d>[Chinese] 我才不怕死！</d> Both of them press off the stone and lift their heads toward the jade terrace in the north.
[Shot 2] At 00:04.000, the camera cuts to <Picture 2>: a Static Shot close on the junior sister sitting on the blue stone, one palm pressed to the floor with the knuckles flattened and one knee lifted as she tries to stand; her teeth are set in her lower lip and her hair sticks to her cheek, while the young swordsman blurs behind her shoulder. Her knee slips and she drops back down heavily onto the floor, her bridal skirt caught under her knee; the young swordsman just behind her pushes his upper body upright and turns his shoulder toward her side. (S1) the young swordsman in the red wedding robe, breath driven short, says <d>[Chinese] 要杀就杀我，放过我师妹！</d>
[Shot 3] At 00:09.400, the camera cuts to <Picture 3>: a Pull Out as the young swordsman scrambles up, staggers half a step, plants his feet apart and blocks his seated junior sister with his body, one hand raised back to shield her; the Pull Out widens until the fox demon woman reclining on the white jade couch appears in the upper right distance, looking down at them while the tip of one white tail sweeps across the couch. (S3) the nine-tailed fox demon woman, amused and dismissive, says <d>[Chinese] 这么弱，还敢这么狂？</d>

overall_soundscape:
Silk and coarse cloth dragging over blue stone; a palm slapping down onto the floor; the light scrape of a scabbard shifting on the ground; hollow hall reverb and a faint water whisper overhead.

non_diegetic_music:
Broken low strings with one slow drum hit as the young man rises to his feet.
```

**Seedance 视频提示词**

```text
@[图片1] = 江底封印·仙府与桃林
@[图片2] = 燕溪山
@[图片3] = 徐今朝
@[图片4] = 九尾狐妖

【人物关系与构图逻辑】
大殿青石地中央偏南：燕溪山与徐今朝摔坐在地，徐今朝在左后、燕溪山在右前，两人相距约半步，均面朝正北白玉高台；两把长剑分别落在各自身侧一臂远；九尾狐妖在台上榻沿居高俯视，两处相距约十步。

【镜头1】
焦距：35mm 广角，中景深
机位：双人 + 俯视 20°
构图：对角线
运镜：固定镜头
景别：中景
画面：镜头微晃：两名穿婚服的修士先后从石面上撑起上身，少年撑着地扭过头朝正北喊出声、手掌在石面上蹭出半寸；女子一手撑地、另一只手抬起指向台上方向，两人的长剑都还躺在身侧地上。
台词：{我燕溪山绝不求饶！} {我才不怕死！}
视线落点：两人看向正北白玉高台方向
焦点：锁定地面上两人的上半身与撑地的手掌
稳定性：微晃

【镜头2】
焦距：85mm 长焦，极浅景深
机位：徐今朝 + 平视略低
构图：中心构图
运镜：固定镜头
景别：特写
画面：镜头固定：红嫁衣的女子一手撑地、屈腿想要站起，膝盖刚离地又滑回去、重重跌坐在地上；她右后侧的少年撑直上身、把肩膀侧挡向她那一侧，抬头朝台上开口，说完时胸口又起伏了一下。
台词：{要杀就杀我，放过我师妹！}
视线落点：徐今朝低头盯着自己撑地的手
焦点：锁定撑在石面上的手掌与屈起的膝盖
稳定性：微晃

【镜头3】
焦距：35mm 广角，中深景深
机位：双人 + 平视略低（含右上高台）
构图：三分法
运镜：拉镜
景别：全景
画面：镜头小幅后拉：少年从跪坐撑起、踉跄半步站稳，横身挡到坐地的女子身前，一只手向后虚护住她；画面随之后拉，退到远景里靠在白玉榻沿的狐妖，她垂眼看下来、尾尖轻扫过榻面，台下两人一立一坐停在原地。
台词：{这么弱，还敢这么狂？}
视线落点：燕溪山看向白玉榻上的九尾狐妖
焦点：锁定挡在师妹身前站立的燕溪山
稳定性：稳定

<衣料摩擦青石地面与手掌撑地的钝响；剑鞘与剑身在地上被拖动半寸的轻响；殿内空旷回声；远处水波细响。>
（低音弦乐断续，少年站起时加入一记缓慢鼓点。）

【约束】
1. 保持无字幕，避免生成任何文字或字幕
2. 视频全程禁止出现外形、着装、配饰完全一致的人物
```

### E01-06 · 江底封印·仙府与桃林（珠光常明） · 14.2 秒 · 3 个分镜

> 走位：大殿青石地中央：燕溪山站起横挡在徐今朝身前，燕溪山偏右前、徐今朝坐地偏左后，两人相距不足一步，均面向正北；奶娃们从四面涌上，抱住两人的腿和手臂，最密处在两人脚前半步；九尾狐妖在正北高台榻沿俯视，相距约十步。

| 切 | 起点 | 秒 | 景别 | 运镜 | 配方 | 画面 | 人物 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| #1 | 0.00s | 4.6 | 全景 | Static Shot（固定） | — | 奶娃们涌上来，抱住两人的腿和手臂。 奶娃们：「新来的，陪我们睡！」 | 燕溪山、徐今朝、奶娃们 |
| #2 | 4.60s | 5.6 | 特写 | Push In（推） | — | 徐今朝：「我们是来除妖的，不是陪睡的！」 一个奶娃把口水蹭到徐今朝袖子上。 | 徐今朝、奶娃们 |
| #3 | 10.20s | 4 | 中景 | Static Shot（固定） | — | 徐今朝：「呀！你走开！」 | 燕溪山、徐今朝、奶娃们 |

**H3 视频提示词**

```text
How the reference pictures align with the target video — Picture 1 (from Shot 1) aligns with the 0.00-second mark of the target video; Picture 2 (from Shot 2) aligns with the 4.60-second mark of the target video; Picture 3 (from Shot 3) aligns with the 10.20-second mark of the target video.

integrated_multimodal_description:
[Shot 1] Anchored to the composition of <Picture 1>: a Static Shot wide on the blue stone floor of the underwater hall, warm pearl light glowing between the columns and rows of cradles receding into shadow behind. Toddlers pour in from both sides, wrap their arms around the young swordsman's legs and hang on his junior sister's arms, her long sword crowded against her side. (S1) a three-year-old girl with a small topknot, bright and demanding, calls out <d>[Chinese] 新来的，陪我们睡！</d> The two of them are dragged half a step apart and stumble back together, their swords rocking against their sides.
[Shot 2] At 00:04.600, the camera cuts to <Picture 2>: a slow Push In on the junior sister in the red bridal dress from the front as a toddler lifts her right arm in both hands and presses its face against her sleeve. (S2) the junior sister in the red bridal dress, young, shrill and exasperated, says <d>[Chinese] 我们是来除妖的，不是陪睡的！</d> The child rubs its face left and right along the red sleeve and leaves a glossy wet streak; she bends her head, pulls her sleeve back and pries the small fingers open while her shoulder shrinks back half an inch.
[Shot 3] At 00:10.200, the camera cuts to <Picture 3>: a Static Shot at medium range on the junior sister in the red bridal dress glaring down at a toddler at her feet, a wet streak still on her cuff; the young swordsman stands blurred to her left, still held around the legs by other children. (S2) the junior sister in the red bridal dress, sharp and flustered, cries <d>[Chinese] 呀！你走开！</d> She jerks her arm up to free the cuff, leans back and shifts half a step backwards on the stone, then another toddler clamps onto her calf and she freezes in place, turning her head to glare down.

overall_soundscape:
Toddlers chattering and slapping the stone floor in waves; wedding silk dragged and twisted; a small wet sound as a face is rubbed against the sleeve; hollow hall reverb with a faint water whisper overhead.

non_diegetic_music:
Light woodwind stabs and plucked strings, bouncy and comic.
```

**Seedance 视频提示词**

```text
@[图片1] = 江底封印·仙府与桃林
@[图片2] = 燕溪山
@[图片3] = 徐今朝
@[图片4] = 奶娃们

【人物关系与构图逻辑】
大殿青石地中央：燕溪山站起横挡在徐今朝身前，燕溪山偏右前、徐今朝坐地偏左后，两人相距不足一步，均面向正北；奶娃们从四面涌上，抱住两人的腿和手臂，最密处在两人脚前半步；九尾狐妖在正北高台榻沿俯视，相距约十步。

【镜头1】
焦距：28mm 广角，深景深
机位：双人 + 平视正面略低
构图：三分法
运镜：固定镜头
景别：全景
画面：镜头固定：一群幼儿从左右两侧涌上来，抱住少年的腿往上爬、扯住女子的袖口往后拽，两人被拽得各退半步、又相互靠拢；最前的三岁小丫头仰起脸、张圆嘴喊了一声，随后抱紧少年的膝，长剑被挤得在两人身侧晃了两下。
台词：{新来的，陪我们睡！}
视线落点：燕溪山与徐今朝低头看向围上来的奶娃
焦点：锁定两人与被奶娃抱住的手臂、腿
稳定性：微晃

【镜头2】
焦距：85mm 长焦，极浅景深
机位：徐今朝 + 平视正面近前
构图：中心构图
运镜：推镜
景别：特写
画面：镜头小幅缓推：抱袖的小娃把脸整个埋到红色袖面上、左右蹭了两下，留下一条亮晶晶的口水痕；女子低着头把袖子往回抽、另一只手扒开孩子的手指，肩膀往后缩了半寸，脚没动。
台词：{我们是来除妖的，不是陪睡的！}
视线落点：徐今朝低头盯着自己袖口
焦点：锁定被蹭上口水的红色袖面与孩子的小脸
稳定性：微晃

【镜头3】
焦距：50mm 标准，中浅景深
机位：徐今朝 + 平视正面
构图：三分法
运镜：固定镜头
景别：中景
画面：镜头固定：女子把手臂猛地往上一提，袖口从孩子手里脱出，同时上身后仰、踩着青石往后挪了半步，脚边另一个娃立刻抱住她的小腿，她只能僵在原地转头瞪下去；她左侧的少年被奶娃缠着、没能挪步。
台词：{呀！你走开！}
视线落点：徐今朝看向脚边的奶娃
焦点：锁定徐今朝的面部与被抱住的小腿
稳定性：微晃

<幼儿们此起彼伏的咿呀与脚步拍地声；婚服衣料被拉扯的摩擦声；脸蹭上袖面时的一点湿响；殿内空旷回声与远处水波细响。>
（木管轻快断音与拨弦点缀，节奏跳跃，滑稽感。）

【约束】
1. 保持无字幕，避免生成任何文字或字幕
2. 视频全程禁止出现外形、着装、配饰完全一致的人物
```

### E01-07 · 江底封印·仙府与桃林（珠光常明） · 10 秒 · 2 个分镜

> 走位：大殿中轴：九尾狐妖侧坐在正北白玉高台榻沿、面朝台下；燕溪山站在台下青石地上、面朝正北仰头，两人相距约十步、高差过胸；燕溪山脚边缠着两三个奶娃；被推下的摇篮停在燕溪山靴前不足半步处。

| 切 | 起点 | 秒 | 景别 | 运镜 | 配方 | 画面 | 人物 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| #1 | 0.00s | 5.8 | 中景 | Static Shot（固定） | — | 九尾狐妖：「既然来了，就别想闲着。」 燕溪山：「我们是剑宗弟子，不是你的佣人！」 | 九尾狐妖、燕溪山 |
| #2 | 5.80s | 4.2 | 特写 | Tilt Down（俯摇） | — | 九尾狐妖：「现在你们是了。」 狐妖把一个小摇篮推到燕溪山脚边。 | 九尾狐妖、燕溪山 |

**H3 视频提示词**

```text
How the reference pictures align with the target video — Picture 1 (from Shot 1) aligns with the 0.00-second mark of the target video; Picture 2 (from Shot 2) aligns with the 5.80-second mark of the target video.

integrated_multimodal_description:
[Shot 1] Anchored to the composition of <Picture 1>: a Static Shot at medium range inside the underwater hall — the nine-tailed fox demon woman in her layered ivory-and-pink robe sits on the edge of the white jade couch above, fox ears up and nine white tails laid out across the couch, while the young swordsman in the red wedding robe stands below with toddlers still clinging to his legs and two long swords lying on the floor beside him. (S1) the nine-tailed fox demon woman on the couch, slow and commanding, says <d>[Chinese] 既然来了，就别想闲着。</d> She sets one hand on her knee and lifts her chin toward the hall below, the tip of one tail sweeping the couch. (S2) the young swordsman in the red wedding robe, hot and resentful, answers <d>[Chinese] 我们是剑宗弟子，不是你的佣人！</d> He plants his shoulders forward and his hand closes at his side.
[Shot 2] At 00:05.800, the camera cuts to <Picture 2>: a Tilt Down from the terrace edge to the floor — (S1) the nine-tailed fox demon woman, flat and final, says <d>[Chinese] 现在你们是了。</d> She reaches out and pushes a small bamboo cradle over the terrace lip; it slides down, knocks twice on the blue stone and rocks to a stop at the young swordsman's boot, its brocade quilt and tiger-head pillow tumbling inside. He looks down at it while the toddler hugging his leg leans over to look too.

overall_soundscape:
Hollow hall reverb; toddlers' light padding steps and small voices around the young man's legs; a bamboo cradle knocking twice on the blue stone and creaking as it rocks still; a faint water whisper overhead.

non_diegetic_music:
Plucked single notes alternating with short woodwind phrases, slow and light.
```

**Seedance 视频提示词**

```text
@[图片1] = 江底封印·仙府与桃林
@[图片2] = 九尾狐妖
@[图片3] = 燕溪山

【人物关系与构图逻辑】
大殿中轴：九尾狐妖侧坐在正北白玉高台榻沿、面朝台下；燕溪山站在台下青石地上、面朝正北仰头，两人相距约十步、高差过胸；燕溪山脚边缠着两三个奶娃；被推下的摇篮停在燕溪山靴前不足半步处。

【镜头1】
焦距：35mm 广角，中深景深
机位：九尾狐妖与燕溪山 + 平视略仰
构图：三分法
运镜：固定镜头
景别：中景
画面：镜头固定：台上的狐妖一只手搭在膝上、抬起下巴朝台下开口，尾尖轻扫榻面；台下被幼儿抱着腿的少年仰头反驳、肩膀往前一顶、身侧的手握紧又松开，脚边的孩子被带得晃了半步又抱回来。
台词：{既然来了，就别想闲着。} {我们是剑宗弟子，不是你的佣人！}
视线落点：燕溪山仰头看向台上的九尾狐妖
焦点：锁定台上九尾狐妖的上半身与台下仰头的燕溪山
稳定性：稳定

【镜头2】
焦距：50mm 标准，浅景深
机位：摇篮与燕溪山靴前 + 俯视 40°
构图：中心构图
运镜：俯摇
景别：特写
画面：镜头自上而下俯摇：狐妖坐在榻沿伸手一推，一只竹木摇篮顺着台沿滑下、在青石地上磕出两声，晃了两下停在被幼儿抱腿的少年靴前；少年低头看下去，抱着他腿的孩子也跟着探头。
台词：{现在你们是了。}
视线落点：燕溪山低头看向脚边的摇篮
焦点：锁定停下的竹木摇篮与其中的锦缎小被
稳定性：稳定

<空旷殿内回声；幼儿缠在腿边的细碎脚步声与小声嘟囔；竹木摇篮磕在青石上的两声钝响与随之摇晃的吱呀；殿顶水波细响。>
（拨弦单音与木管短句交替，节奏轻缓。）

【约束】
1. 保持无字幕，避免生成任何文字或字幕
2. 视频全程禁止出现外形、着装、配饰完全一致的人物
```

### E01-08 · 江底封印·仙府与桃林（珠光常明） · 13.2 秒 · 3 个分镜

> 走位：大殿青石地上：燕溪山站在中偏右、怀里抱着奶娃，徐今朝站在他左侧一步外、面朝他与正北；摇篮停在燕溪山脚边半步内，脚边另有两三个奶娃；九尾狐妖在正北高台榻沿，距两人约十步。

| 切 | 起点 | 秒 | 景别 | 运镜 | 配方 | 画面 | 人物 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| #1 | 0.00s | 4 | 中景 | Push In（推） | — | 奶娃们：「哥哥，抱抱！」 燕溪山弯腰抱起奶娃。 | 燕溪山、奶娃们 |
| #2 | 4.00s | 4 | 特写 | Static Shot（固定） | — | 燕溪山：「你先别哭。」 奶娃搂住燕溪山的脖子。 | 燕溪山、奶娃们 |
| #3 | 8.00s | 5.2 | 中景 | Static Shot（固定） | — | 徐今朝：「师兄，你怎么先投降了？」 燕溪山：「我没投降，我先稳住敌情。」 | 燕溪山、徐今朝、奶娃们 |

**H3 视频提示词**

```text
How the reference pictures align with the target video — Picture 1 (from Shot 1) aligns with the 0.00-second mark of the target video; Picture 2 (from Shot 2) aligns with the 4.00-second mark of the target video; Picture 3 (from Shot 3) aligns with the 8.00-second mark of the target video.

integrated_multimodal_description:
[Shot 1] Anchored to the composition of <Picture 1>: a slow Push In on the young swordsman in the red wedding robe as he bends down on the blue stone floor and lifts a round-faced toddler out of the cradle by both armpits; the child's arms are already up, the brocade quilt and tiger-head pillow still inside the cradle behind him, peach petals falling past his shoulders. (S1) a three-year-old girl with a small topknot, clinging and cheerful, calls <d>[Chinese] 哥哥，抱抱！</d> The child's legs kick twice in the air and one hand catches the collar of his wedding robe.
[Shot 2] At 00:04.000, the camera cuts to <Picture 2>: a Static Shot close on the young swordsman standing with the toddler in his arms; the child's arms come up around his neck and its face presses into his shoulder while one small hand knots itself in his lapel. (S2) the young swordsman in the red wedding robe, low and coaxing, says <d>[Chinese] 你先别哭。</d> He looks down at the child, his shoulders slowly loosening, and rocks it twice from side to side.
[Shot 3] At 00:08.000, the camera cuts to <Picture 3>: a Static Shot at medium range on the two of them standing on the blue stone with several toddlers still around their feet. (S3) the junior sister in the red bridal dress, half mocking and half accusing, says <d>[Chinese] 师兄，你怎么先投降了？</d> She turns her head toward him and points at the child in his arms, then purses her mouth. (S2) the young swordsman in the red wedding robe, still holding the child steady, answers without looking down <d>[Chinese] 我没投降，我先稳住敌情。</d>

overall_soundscape:
Small hiccups and grunts from the children; silk and coarse cloth brushing as the toddler is lifted; tiny feet shifting on stone; hollow hall reverb with a pale water shimmer overhead.

non_diegetic_music:
A sustained low string with a single light pluck in the middle.
```

**Seedance 视频提示词**

```text
@[图片1] = 江底封印·仙府与桃林
@[图片2] = 燕溪山
@[图片3] = 奶娃们
@[图片4] = 徐今朝

【人物关系与构图逻辑】
大殿青石地上：燕溪山站在中偏右、怀里抱着奶娃，徐今朝站在他左侧一步外、面朝他与正北；摇篮停在燕溪山脚边半步内，脚边另有两三个奶娃；九尾狐妖在正北高台榻沿，距两人约十步。

【镜头1】
焦距：50mm 标准，中浅景深
机位：燕溪山与奶娃 + 平视略低
构图：中心构图
运镜：推镜
景别：中景
画面：镜头小幅缓推：少年屈膝弯腰、双手从幼儿腋下稳稳把人抱起来，孩子被举高时两条小腿在空里蹬了两下、随手抓住他的婚服领口；少年抱着孩子站定，姿势有点僵，脚边的娃还抱着他的裤腿。
台词：{哥哥，抱抱！}
视线落点：燕溪山低头看向被抱起的奶娃
焦点：锁定燕溪山弯腰抱起孩子的双手
稳定性：微晃

【镜头2】
焦距：85mm 长焦，极浅景深
机位：燕溪山与奶娃 + 平视正面
构图：中心构图
运镜：固定镜头
景别：特写
画面：镜头固定：孩子两条手臂搂上少年的脖颈、小脸埋进肩窝，另一只手抓着他的衣襟不松；少年低头看了一眼，肩背慢慢松下来，把手臂往上托了托、轻轻左右晃了两下，脚边奶娃的脚步声仍在。
台词：{你先别哭。}
视线落点：燕溪山低头看着怀里的奶娃
焦点：锁定搂住少年脖颈的小手与贴在他肩窝的小脸
稳定性：微晃

【镜头3】
焦距：50mm 标准，中浅景深
机位：徐今朝与燕溪山 + 平视正面
构图：三分法
运镜：固定镜头
景别：中景
画面：镜头固定：红嫁衣的女子侧头转向师兄、抬手指了指他怀里，随后撇了下嘴；抱着孩子的少年没有低头看她，只把孩子往上托了托、侧过脸回话，肩膀仍保持抱稳的姿势，脚边的娃扯着他的衣摆。
台词：{师兄，你怎么先投降了？} {我没投降，我先稳住敌情。}
视线落点：徐今朝看向抱着奶娃的燕溪山
焦点：锁定抱着奶娃的燕溪山与侧头质问的徐今朝
稳定性：稳定

<幼儿的短促哼声与被抱起时的衣料摩擦；丝质婚服在托举中轻响；脚边幼儿的脚步声；殿内空旷回声与上方水波细响。>
（低音弦乐拉长、速度缓慢，中段加入一记轻拨弦。）

【约束】
1. 保持无字幕，避免生成任何文字或字幕
2. 视频全程禁止出现外形、着装、配饰完全一致的人物
```

### E01-09 · 江底封印·仙府与桃林（珠光常明） · 11.4 秒 · 2 个分镜

> 走位：大殿西侧摇篮阵前：徐今朝站在摇篮阵边缘、半侧身面朝殿西，摇篮阵由近及远排入柱影，最前一排距她不足一步；燕溪山抱着奶娃站在她右后侧一步外；九尾狐妖在正北白玉高台榻沿，与摇篮阵相距约十步。

| 切 | 起点 | 秒 | 景别 | 运镜 | 配方 | 画面 | 人物 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| #1 | 0.00s | 5.7 | 全景 | Pan Left（左摇） | — | 徐今朝回头，看见一排排摇篮里全是孩子。 徐今朝：「这些孩子，都是村民扔下来的？」 | 徐今朝、奶娃们 |
| #2 | 5.70s | 5.7 | 中景 | Push In（推） | — | 九尾狐妖：「不然呢？我还能自己生一百个？」 狐妖抱起一个哭闹的奶娃，轻轻晃。 | 九尾狐妖、奶娃们 |

**H3 视频提示词**

```text
How the reference pictures align with the target video — Picture 1 (from Shot 1) aligns with the 0.00-second mark of the target video; Picture 2 (from Shot 2) aligns with the 5.70-second mark of the target video.

integrated_multimodal_description:
[Shot 1] Anchored to the composition of <Picture 1>: a slow Pan Left across the west side of the hall, where rows of low bamboo cradles with brocade quilts and tiger-head pillows recede between the columns, pale rice stains on the blue stone beneath them and babies lying in many of the cradles. The junior sister in the red bridal dress stands at the edge of the rows and turns to look across them, one hand still on her scabbard; the camera pans with her gaze, her hand comes off the scabbard and her foot starts half a step forward and stops. (S1) the junior sister in the red bridal dress, quiet and shaken, asks <d>[Chinese] 这些孩子，都是村民扔下来的？</d>
[Shot 2] At 00:05.700, the camera cuts to <Picture 2>: a slow Push In on the nine-tailed fox demon woman sitting on the edge of the white jade couch with a crying toddler lifted into her arms, the edge of its brocade blanket draped over her ivory-and-pink sleeve; she cradles the back of its head in one hand and rocks her arms twice, her nine tails spread across the couch, one ear twitching. (S2) the nine-tailed fox demon woman, dry and offhand, says <d>[Chinese] 不然呢？我还能自己生一百个？</d> Her eyes go past the child to the hall below, and the tip of one tail sweeps the couch.

overall_soundscape:
Babies' thin fretful sounds and sniffles from the cradle rows; bamboo cradles creaking when brushed; brocade blankets rustling; hollow hall reverb and a faint water whisper overhead.

non_diegetic_music:
A sustained low string held long, tempo easing.
```

**Seedance 视频提示词**

```text
@[图片1] = 江底封印·仙府与桃林
@[图片2] = 徐今朝
@[图片3] = 奶娃们
@[图片4] = 九尾狐妖

【人物关系与构图逻辑】
大殿西侧摇篮阵前：徐今朝站在摇篮阵边缘、半侧身面朝殿西，摇篮阵由近及远排入柱影，最前一排距她不足一步；燕溪山抱着奶娃站在她右后侧一步外；九尾狐妖在正北白玉高台榻沿，与摇篮阵相距约十步。

【镜头1】
焦距：28mm 广角，深景深
机位：徐今朝 + 平视斜侧（随她视线扫向摇篮阵）
构图：三分法
运镜：左摇
景别：全景
画面：镜头由右向左缓摇：红嫁衣的女子回过头，视线扫过一排排摇篮，镜头随她的视线横向移过，逐一露出摇篮里裹着锦缎小被的孩子；她搭在剑鞘上的手慢慢松开，脚向前迈了半步又停住。
台词：{这些孩子，都是村民扔下来的？}
视线落点：徐今朝看向西侧的一排排摇篮
焦点：锁定一排排摇篮与摇篮里躺着的奶娃
稳定性：稳定

【镜头2】
焦距：50mm 标准，中浅景深
机位：九尾狐妖 + 平视略仰
构图：中心构图
运镜：推镜
景别：中景
画面：镜头小幅缓推：狐妖把哭闹的幼儿抱起来搂在臂弯、一手托住后背，肩臂轻轻左右晃动两下；孩子的哭声渐弱，她的视线越过孩子落到台下、朝那边说了一句，尾尖在榻面上扫了一下。
台词：{不然呢？我还能自己生一百个？}
视线落点：九尾狐妖低头看向怀里的奶娃
焦点：锁定狐妖臂弯里哭闹的奶娃与托背的手掌
稳定性：微晃

<摇篮里婴儿的细碎哼声与抽噎；竹木摇篮被轻碰的吱呀声；襁褓锦缎摩擦；殿内空旷回声与上方水波轻响。>
（低音弦乐持续长音，速度放缓。）

【约束】
1. 保持无字幕，避免生成任何文字或字幕
2. 视频全程禁止出现外形、着装、配饰完全一致的人物
```

### E01-10 · 江底封印·仙府与桃林（珠光常明） · 13.4 秒 · 3 个分镜

> 走位：大殿中轴：九尾狐妖坐在正北白玉高台榻沿、怀里抱着奶娃、面朝台下；徐今朝站在台下青石地上仰头、面朝正北，两人相距约十步、高差过胸；燕溪山抱着奶娃站在徐今朝右后侧一步外。

| 切 | 起点 | 秒 | 景别 | 运镜 | 配方 | 画面 | 人物 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| #1 | 0.00s | 4 | 特写 | Static Shot（固定） | — | 奶娃们：「娘亲，饿。」 九尾狐妖：「新来的，去把米糊端来。」 | 九尾狐妖、奶娃们 |
| #2 | 4.00s | 4 | 中景 | Static Shot（固定） | — | 徐今朝：「我们凭什么听你的？」 九尾狐妖：「凭你们打不过我。」 | 徐今朝、九尾狐妖 |
| #3 | 8.00s | 5.4 | 特写 | Push In（推） | — | 徐今朝握紧拳头，又松开。 燕溪山：「师妹，先救孩子，再问罪。」 | 燕溪山、徐今朝、奶娃们 |

**H3 视频提示词**

```text
How the reference pictures align with the target video — Picture 1 (from Shot 1) aligns with the 0.00-second mark of the target video; Picture 2 (from Shot 2) aligns with the 4.00-second mark of the target video; Picture 3 (from Shot 3) aligns with the 8.00-second mark of the target video.

integrated_multimodal_description:
[Shot 1] Anchored to the composition of <Picture 1>: a Static Shot close on the nine-tailed fox demon woman on the white jade couch with a toddler in her arms, fox ears up and the collar of her ivory-and-pink robe crumpled in the child's fist. (S1) a three-year-old girl with a small topknot, small and plaintive, whines <d>[Chinese] 娘亲，饿。</d> The child's mouth opens and closes as it looks up at her and it pulls at her collar; the fox demon woman glances down. (S2) the nine-tailed fox demon woman, casual and ordering, says <d>[Chinese] 新来的，去把米糊端来。</d> She tilts her chin toward the side of the hall and points, her other arm still holding the child steady.
[Shot 2] At 00:04.000, the camera cuts to <Picture 2>: a Static Shot at medium range, the junior sister in the red bridal dress angled low in the foreground half turned away from the camera with her face up toward the north terrace, while the fox demon woman sits above on the couch with the toddler still in her arms. (S3) the junior sister in the red bridal dress, sharp and challenging, asks <d>[Chinese] 我们凭什么听你的？</d> Her fist closes at her side. (S2) the nine-tailed fox demon woman, flat and confident, answers <d>[Chinese] 凭你们打不过我。</d> She rocks the child, the tip of one white tail sweeping the couch edge.
[Shot 3] At 00:08.000, the camera cuts to <Picture 3>: a slow Push In on the junior sister's right hand held at her side, her red cuff gathered at the wrist, the fingers clenched white; she stares down at her hand, holds it a moment, then lets the fingers open and drop loose. (S4) behind her shoulder the young swordsman in the red wedding robe, the toddler still in his arms, low and reasoning, says <d>[Chinese] 师妹，先救孩子，再问罪。</d>

overall_soundscape:
A toddler's thin fretful sounds and smacking lips; crumpled silk at the collar; a foot pressing and turning on the blue stone; hollow hall reverb with a faint water whisper.

non_diegetic_music:
Clarinet phrases alternating with low strings, slow and restrained.
```

**Seedance 视频提示词**

```text
@[图片1] = 江底封印·仙府与桃林
@[图片2] = 九尾狐妖
@[图片3] = 奶娃们
@[图片4] = 徐今朝
@[图片5] = 燕溪山

【人物关系与构图逻辑】
大殿中轴：九尾狐妖坐在正北白玉高台榻沿、怀里抱着奶娃、面朝台下；徐今朝站在台下青石地上仰头、面朝正北，两人相距约十步、高差过胸；燕溪山抱着奶娃站在徐今朝右后侧一步外。

【镜头1】
焦距：85mm 长焦，极浅景深
机位：九尾狐妖与怀里奶娃 + 平视略仰
构图：中心构图
运镜：固定镜头
景别：特写
画面：镜头固定：怀里的幼儿仰起脸、嘴一张一合地对着抱他的人出声，小手攥住襦裙领口往上拽；狐妖低头看了一眼，随即抬眼朝台下偏了偏头、抬手指向殿侧方向，另一条手臂仍稳稳托着孩子。
台词：{娘亲，饿。} {新来的，去把米糊端来。}
视线落点：九尾狐妖低头看向怀里的奶娃
焦点：锁定仰起小脸的奶娃与攥住领口的小手
稳定性：稳定

【镜头2】
焦距：35mm 广角，中深景深
机位：九尾狐妖 + 平视略仰（前侧含徐今朝背影）
构图：三分法
运镜：固定镜头
景别：中景
画面：镜头固定：前景的红嫁衣女子仰头质问、拳头在身侧攥紧；台上的狐妖低头听她说完，抬了抬下巴回了一句，怀里的奶娃被她轻轻晃着，尾尖扫过榻沿。
台词：{我们凭什么听你的？} {凭你们打不过我。}
视线落点：徐今朝仰头看向台上的九尾狐妖
焦点：锁定台上九尾狐妖的面部
稳定性：稳定

【镜头3】
焦距：85mm 长焦，极浅景深
机位：徐今朝 + 平视略低（含右后侧燕溪山）
构图：中心构图
运镜：推镜
景别：特写
画面：镜头小幅缓推：红嫁衣女子的右拳在身侧攥紧、指节绷起，停了一瞬后慢慢松开、手指摊平垂下；她右后侧抱着孩子的少年偏头看她，低声说完一句，肩膀轻轻侧向她那一侧，怀里的奶娃伸手抓住他的衣襟。
台词：{师妹，先救孩子，再问罪。}
视线落点：徐今朝低头盯着自己握紧的手
焦点：锁定握紧又松开的拳头
稳定性：微晃

<怀里幼儿的短促哼声与咂嘴声；襦裙领口被攥紧的布料声；青石地上脚掌轻碾；殿内空旷回声。>
（单簧管与低音弦乐交替，速度缓慢，落点克制。）

【约束】
1. 保持无字幕，避免生成任何文字或字幕
2. 视频全程禁止出现外形、着装、配饰完全一致的人物
```

### E01-11 · 江底封印·仙府与桃林（珠光常明） · 12.4 秒 · 3 个分镜

> 走位：大殿青石地上：燕溪山抱着奶娃站在偏左前方、面朝徐今朝一侧；徐今朝站在他右侧一步外；正北白玉高台上九尾狐妖坐在榻沿，与他相距约十步，殿顶整片江水面悬在所有人上方。

| 切 | 起点 | 秒 | 景别 | 运镜 | 配方 | 画面 | 人物 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| #1 | 0.00s | 4.2 | 特写 | Static Shot（固定） | — | 燕溪山低头看怀里奶娃，奶娃抓住他的衣襟。 奶娃们：「哥哥，不扔我。」 | 燕溪山、奶娃们 |
| #2 | 4.20s | 4.2 | 中景 | Push In（推） | — | 燕溪山抱紧奶娃。 燕溪山：「谁也不会扔你。」 | 燕溪山、奶娃们 |
| #3 | 8.40s | 4 | 全景 | Tilt Up（仰摇） | — | 燕溪山回头，看见狐妖盯着头顶的水面。 | 燕溪山、奶娃们、九尾狐妖 |

**H3 视频提示词**

```text
How the reference pictures align with the target video — Picture 1 (from Shot 1) aligns with the 0.00-second mark of the target video; Picture 2 (from Shot 2) aligns with the 4.20-second mark of the target video; Picture 3 (from Shot 3) aligns with the 8.40-second mark of the target video.

integrated_multimodal_description:
[Shot 1] Anchored to the composition of <Picture 1>: a Static Shot close on the young swordsman in the red wedding robe looking down at the toddler in his arms; the child looks up at him with both small hands knotted in the front of his robe, pulling the red fabric into a fistful of creases, tiredness clear on his face and one loose strand of hair on his forehead. (S1) the toddler in his arms, small and anxious, says <d>[Chinese] 哥哥，不扔我。</d> The child pulls the lapel higher and he lowers his head, his throat moving, his arms slowly tightening.
[Shot 2] At 00:04.200, the camera cuts to <Picture 2>: a slow Push In as the young swordsman folds the toddler fully against his chest, its small face pressed into the hollow of his shoulder and its legs hanging past his forearm, his jaw resting on the top of the child's head. (S2) the young swordsman in the red wedding robe, low and steady, says <d>[Chinese] 谁也不会扔你。</d> His shoulders rise and fall, he pauses with his jaw against the child's hair, and the child frees one hand and pats his collarbone.
[Shot 3] At 00:08.400, the camera cuts to <Picture 3>: a Tilt Up as the young swordsman turns his head and follows his gaze up across the hall — past the rows of cradles it climbs to the nine-tailed fox demon woman sitting on the white jade couch, her chin lifted toward the ceiling, fox ears standing straight, nine white tails hanging dead still off the couch edge. The whole underside of the river hangs overhead, dark green water turning slowly with light patterns crawling across it. She does not move or blink as she stares up at it.

overall_soundscape:
The toddler's light sniffling and cloth brushing; silk tightening as the child is pressed close; hollow hall reverb with the low rush of moving water and faint bubbles overhead.

non_diegetic_music:
A long low string rising very slowly.
```

**Seedance 视频提示词**

```text
@[图片1] = 江底封印·仙府与桃林
@[图片2] = 燕溪山
@[图片3] = 奶娃们
@[图片4] = 九尾狐妖

【人物关系与构图逻辑】
大殿青石地上：燕溪山抱着奶娃站在偏左前方、面朝徐今朝一侧；徐今朝站在他右侧一步外；正北白玉高台上九尾狐妖坐在榻沿，与他相距约十步，殿顶整片江水面悬在所有人上方。

【镜头1】
焦距：85mm 长焦，极浅景深
机位：燕溪山与怀里奶娃 + 平视正面
构图：中心构图
运镜：固定镜头
景别：特写
画面：镜头固定：怀里的幼儿仰着头、两只小手攥住少年的衣襟往上扯；少年低下头看了很久，喉结动了一下，手臂慢慢收紧，把孩子往胸口贴了半寸，脚边青石上还有几片桃瓣。
台词：{哥哥，不扔我。}
视线落点：燕溪山低头看着怀里的奶娃
焦点：锁定抓住衣襟的小手与燕溪山的眼睛
稳定性：稳定

【镜头2】
焦距：50mm 标准，中浅景深
机位：燕溪山与奶娃 + 平视略低
构图：三分法
运镜：推镜
景别：中景
画面：镜头小幅缓推：少年把怀里的幼儿整个收紧到胸口、下颌抵住孩子的发顶，肩膀微微起伏，说完低头在孩子的发顶停了一下；怀里的孩子松开一只抓衣襟的手、拍了拍他的锁骨。
台词：{谁也不会扔你。}
视线落点：燕溪山低头贴近怀里的奶娃
焦点：锁定贴在少年胸口的奶娃
稳定性：微晃

【镜头3】
焦距：35mm 广角，中深景深
机位：燕溪山与九尾狐妖 + 平视转仰视
构图：对角线
运镜：仰摇
景别：全景
画面：镜头自下而上缓摇：少年抱着孩子回过头，视线越过青石地上的一排排摇篮一直抬到殿顶；镜头随之上仰，停在高台上仰头看水的狐妖身上——她一动不动地盯着悬在头顶的江水面，尾尖悬着没有落下。
台词：{}
视线落点：燕溪山顺着九尾狐妖的目光看向殿顶水面
焦点：锁定仰头看水面的九尾狐妖
稳定性：稳定

<怀里幼儿的轻声抽噎与布料摩擦；婚服收紧时的丝质轻响；殿内空旷回声，头顶江水流动的低频水声与细小气泡声。>
（低音弦乐长音缓缓上行，速度极慢。）

【约束】
1. 保持无字幕，避免生成任何文字或字幕
2. 视频全程禁止出现外形、着装、配饰完全一致的人物
```

### E01-12 · 江底封印·仙府与桃林（珠光常明） · 9 秒 · 2 个分镜

> 走位：大殿中轴：燕溪山抱着奶娃站在台下青石地上偏左前、仰头面朝正北；九尾狐妖坐在正北白玉高台榻沿、侧身朝殿顶，两人相距约十步、高差过胸；殿顶整片江水面悬在画面上方，波纹从正中漾开。

| 切 | 起点 | 秒 | 景别 | 运镜 | 配方 | 画面 | 人物 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| #1 | 0.00s | 4.5 | 中景 | Static Shot（固定） | — | 燕溪山：「你在看什么？」 九尾狐妖：「村民又送东西下来了。」 | 九尾狐妖、燕溪山、奶娃们 |
| #2 | 4.50s | 4.5 | 大远景 | Push In（推） | — | 头顶的水面漾开一圈波纹，传来婴儿啼哭。 |  |

**H3 视频提示词**

```text
How the reference pictures align with the target video — Picture 1 (from Shot 1) aligns with the 0.00-second mark of the target video; Picture 2 (from Shot 2) aligns with the 4.50-second mark of the target video.

integrated_multimodal_description:
[Shot 1] Anchored to the composition of <Picture 1>: a Static Shot at medium range — the young swordsman in the red wedding robe stands low in the left foreground, the toddler still held against his chest, his head tipped back; the nine-tailed fox demon woman sits on the edge of the white jade couch above right, chin still lifted toward the ceiling and fox ears up, nine white tails hanging off the couch edge while water light crawls across her face. (S1) the young swordsman in the red wedding robe, quiet and wary, asks <d>[Chinese] 你在看什么？</d> The fox demon woman takes a beat before lowering her chin and looking down at him. (S2) the nine-tailed fox demon woman, matter-of-fact, says <d>[Chinese] 村民又送东西下来了。</d> She lifts one hand and points up at the water surface above the hall.
[Shot 2] At 00:04.500, the camera cuts to <Picture 2>: a slow Push In tilted up at the inverted water surface that forms the whole ceiling, dark green water turning slowly with pale light patterns crawling across it; a ring of ripples opens at the centre and spreads outward one circle after another, breaking the light into rings, then the surface settles back, rocking only faintly. No people, no figures, only the moving water overhead.

overall_soundscape:
The hall almost silent, just the low rush of water moving overhead; fine, close water sounds as a ring of ripples opens; then, muffled through the water, a single baby's cry from somewhere above the surface; an almost inaudible hum around the pearl light.

non_diegetic_music:
One long low string tone hanging and fading out.
```

**Seedance 视频提示词**

```text
@[图片1] = 江底封印·仙府与桃林
@[图片2] = 九尾狐妖
@[图片3] = 燕溪山
@[图片4] = 奶娃们

【人物关系与构图逻辑】
大殿中轴：燕溪山抱着奶娃站在台下青石地上偏左前、仰头面朝正北；九尾狐妖坐在正北白玉高台榻沿、侧身朝殿顶，两人相距约十步、高差过胸；殿顶整片江水面悬在画面上方，波纹从正中漾开。

【镜头1】
焦距：35mm 广角，中深景深
机位：九尾狐妖与燕溪山 + 平视略仰
构图：三分法
运镜：固定镜头
景别：中景
画面：镜头固定：抱着孩子的少年仰头朝台上问了一句，臂膀仍护着怀里的奶娃；台上的狐妖慢了一拍才把下巴收回来、低头看向他，抬手指了指殿顶那片水面，尾尖扫过榻沿。
台词：{你在看什么？} {村民又送东西下来了。}
视线落点：燕溪山仰头看向台上的九尾狐妖
焦点：锁定仰头的燕溪山与台上抬手指向殿顶的九尾狐妖
稳定性：稳定

【镜头2】
焦距：50mm 标准，中浅景深
机位：殿顶江水面 + 仰视 60°
构图：中心构图
运镜：推镜
景别：大远景
画面：镜头对着殿顶缓推：一圈波纹从水面正中向外漾开，一圈接一圈推向四周，把水面上的光纹搅散又聚回；穹面下的水膜随波轻颤，随后水面渐渐平静，只剩细小的涟漪。
台词：{}
视线落点：无人物，视线随水波指向水面中心
焦点：锁定水面波纹扩散的中心
稳定性：微晃

<殿内极静，只有头顶江水流动的低频水声；水波漾开时的细密水响；随后隔着水层传来一声发闷的婴儿啼哭；殿柱珠光处极轻的嗡鸣。>
（低音弦乐单音悬停，尾音拉长渐弱。）

【约束】
1. 保持无字幕，避免生成任何文字或字幕
2. 视频全程禁止出现外形、着装、配饰完全一致的人物
```

## 生成批次单

| 场景 | 光照 | 段 | 需要的角色 | 道具 |
| --- | --- | --- | --- | --- |
| S04 江边祭坛 | 夜·火光冲天 | E01-01 | 江边村民、燕溪山、徐今朝 |  |
| S02 封印边界·水幕结界 | 沉夜·远火 | E01-02 | 燕溪山、徐今朝 |  |
| S01 江底封印·仙府与桃林 | 珠光常明 | E01-03、E01-04、E01-05、E01-06、E01-07、E01-08、E01-09、E01-10、E01-11、E01-12 | 燕溪山、徐今朝、奶娃们、九尾狐妖 |  |

## 配音对齐单

| 段 · 切 | 说话人 | 台词 | 台词秒数 |
| --- | --- | --- | --- |
| E01-03#1 | 奶娃们 | 娘亲！抱抱！ | 1.3 |
| E01-03#2 | 徐今朝 | 别碰我的剑！ | 1.3 |
| E01-03#3 | 九尾狐妖 | 吵死了。 | 0.9 |
| E01-04#1 | 燕溪山 | 妖女！你逼村民献祭幼崽，罪不可赦！ | 3.8 |
| E01-04#2 | 徐今朝 | 上百个孩子，都被你沉进江里了！ | 3.3 |
| E01-04#3 | 九尾狐妖 | 你们说完了？ | 1.3 |
| E01-05#1 | 燕溪山 | 我燕溪山绝不求饶！ | 2 |
| E01-05#1 | 徐今朝 | 我才不怕死！ | 1.3 |
| E01-05#2 | 燕溪山 | 要杀就杀我，放过我师妹！ | 2.7 |
| E01-05#3 | 九尾狐妖 | 这么弱，还敢这么狂？ | 2.2 |
| E01-06#1 | 奶娃们 | 新来的，陪我们睡！ | 2 |
| E01-06#2 | 徐今朝 | 我们是来除妖的，不是陪睡的！ | 3.1 |
| E01-06#3 | 徐今朝 | 呀！你走开！ | 1.3 |
| E01-07#1 | 九尾狐妖 | 既然来了，就别想闲着。 | 2.4 |
| E01-07#1 | 燕溪山 | 我们是剑宗弟子，不是你的佣人！ | 3.3 |
| E01-07#2 | 九尾狐妖 | 现在你们是了。 | 1.6 |
| E01-08#1 | 奶娃们 | 哥哥，抱抱！ | 1.3 |
| E01-08#2 | 燕溪山 | 你先别哭。 | 1.1 |
| E01-08#3 | 徐今朝 | 师兄，你怎么先投降了？ | 2.4 |
| E01-08#3 | 燕溪山 | 我没投降，我先稳住敌情。 | 2.7 |
| E01-09#1 | 徐今朝 | 这些孩子，都是村民扔下来的？ | 3.1 |
| E01-09#2 | 九尾狐妖 | 不然呢？我还能自己生一百个？ | 3.1 |
| E01-10#1 | 奶娃们 | 娘亲，饿。 | 1.1 |
| E01-10#1 | 九尾狐妖 | 新来的，去把米糊端来。 | 2.4 |
| E01-10#2 | 徐今朝 | 我们凭什么听你的？ | 2 |
| E01-10#2 | 九尾狐妖 | 凭你们打不过我。 | 1.8 |
| E01-10#3 | 燕溪山 | 师妹，先救孩子，再问罪。 | 2.7 |
| E01-11#1 | 奶娃们 | 哥哥，不扔我。 | 1.6 |
| E01-11#2 | 燕溪山 | 谁也不会扔你。 | 1.6 |
| E01-12#1 | 燕溪山 | 你在看什么？ | 1.3 |
| E01-12#1 | 九尾狐妖 | 村民又送东西下来了。 | 2.2 |

