# E02-09 · H3 提示词

首帧 = **f1.png**。图片按 Picture 序号挂载：

- Picture 1 = f1.png（**首帧**，钉 0.00 秒）
- Picture 2 = f2.png（钉 5.00 秒）
- Picture 3 = f3.png（钉 9.00 秒）

---

参考图与目标视频的对齐——图 1（来自镜头 1）对齐目标视频 0.00 秒处；图 2（来自镜头 2）对齐目标视频 5.00 秒处；图 3（来自镜头 3）对齐目标视频 9.00 秒处。

整体视听描述：
[镜头 1] 按 <Picture 1> 的构图锚定殿门石壁，跟拍镜头从背后跟随，狐耳女子大步走向殿门，裙摆扫过地面；手掌贴上石面，墙壁发出摩擦声。 <d>[Chinese] 不许提。</d>
[镜头 2] 于 00:05.000， 镜头切到 <Picture 2>：缓推，一名狐耳女子（S1）贴着石面，低声说：<d>[Chinese] 原来你们当年……到底怕什么。</d> <d>[Chinese] 饿的往左，尿的往右。</d>
[镜头 3] 于 00:09.000， 镜头切到 <Picture 3>：缓推，石缝渗出暗红雾气，苍白手骨缓缓探出；狐耳女子僵住，尾巴绒毛竖起，喉间滚出低哑呜咽。 <d>[Chinese] 抱稳。掉了我就吃了你。</d>

整体音景：
环境声与动作声自然呈现。

非叙事配乐：
[Shot 2] At 00:05.000, The camera holds on the referenced composition as the action continues. The camera uses a push in. <d>[Chinese] 饿的往左，尿的往右。</d>
[Shot 3] At 00:09.000, The camera holds on the referenced composition as the action continues. The camera uses a push in. <d>[Chinese] 抱稳。掉了我就吃了你。</d>
overall_soundscape:
Natural ambient and action sounds accompany the scene.
non_diegetic_music:
N/A
